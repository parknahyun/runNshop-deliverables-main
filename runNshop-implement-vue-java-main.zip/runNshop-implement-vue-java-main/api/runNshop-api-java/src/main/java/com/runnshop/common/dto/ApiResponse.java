package com.runnshop.common.dto;

/**
 * 공통 성공 응답 — C6 §6.1 {@code {"code": "SUCCESS", "data": ...}}.
 * 목록은 data에 {@code items}/{@code pagination}을 담는다(C6 §6.2). 에러 응답은 예외처리 결정 후 별도.
 */
public record ApiResponse<T>(String code, T data) {

    public static <T> ApiResponse<T> ok(T data) {
        return new ApiResponse<>("SUCCESS", data);
    }
}
