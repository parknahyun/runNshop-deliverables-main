package com.runnshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * runNshop API 서버(Java 포트) 진입점.
 * 패키지 구조는 java-guide.md 기준 — controller/service/dto/mapper(master|slave)/port.
 * DB 접근은 MyBatis 전용(JPA 미사용).
 */
@SpringBootApplication
public class RunNshopApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(RunNshopApiApplication.class, args);
    }
}
