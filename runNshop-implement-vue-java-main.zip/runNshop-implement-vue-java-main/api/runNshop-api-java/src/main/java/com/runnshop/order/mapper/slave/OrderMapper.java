package com.runnshop.order.mapper.slave;

import com.runnshop.order.dto.OrderRow;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/** 주문(ord_order) 조회 — slave(runnshop_ro). SQL: resources/mapper/slave/order/OrderMapper.xml */
public interface OrderMapper {

    /** 주문 목록 (최신순) */
    List<OrderRow> selectList(@Param("offset") int offset, @Param("limit") int limit);

    /** 주문 건수 */
    long count();
}
