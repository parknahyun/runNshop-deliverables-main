package com.runnshop.order.controller;

import com.runnshop.common.dto.ApiResponse;
import com.runnshop.common.dto.PageResponse;
import com.runnshop.order.dto.OrderRow;
import com.runnshop.order.service.OrderService;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/admin/v1/orders")
@RequiredArgsConstructor
public class OrderController {

    private final OrderService orderService;

    /** 주문 목록. page 1부터, size 최대 100(기본 20) — C6 §6.2 */
    @GetMapping
    public ApiResponse<PageResponse<OrderRow>> getAdminOrders(
            @RequestParam(defaultValue = "1") @Min(1) int page,
            @RequestParam(defaultValue = "20") @Min(1) @Max(100) int size) {
        return ApiResponse.ok(orderService.getAdminOrders(page, size));
    }
}
