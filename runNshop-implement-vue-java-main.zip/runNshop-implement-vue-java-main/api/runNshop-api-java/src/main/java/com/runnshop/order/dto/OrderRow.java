package com.runnshop.order.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;

import java.time.LocalDateTime;

/** 주문 목록 1행 (OrderMapper.selectList 결과). 판매자명 등 타 도메인 표시값은 담지 않는다 — 원시 ID만. */
@Getter
public class OrderRow {

    private String orderId;
    private String platformOrderId;
    private String vendorId;
    private String status;
    private int totalAmount;
    private int shippingFee;

    /** 목록 표시용 일시 (C6 §8.1) */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
    private LocalDateTime createdAt;
}
