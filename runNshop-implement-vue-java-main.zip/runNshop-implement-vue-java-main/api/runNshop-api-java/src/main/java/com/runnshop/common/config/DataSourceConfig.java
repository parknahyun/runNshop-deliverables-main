package com.runnshop.common.config;

import com.zaxxer.hikari.HikariDataSource;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.FullyQualifiedAnnotationBeanNameGenerator;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import javax.sql.DataSource;

/**
 * master/slave 데이터소스 2개와 MyBatis 연결.
 * <ul>
 *   <li>master(runnshop_rw): 저장·수정·삭제, 최신값이 필요한 조회. 트랜잭션(@Transactional)은 master에만 걸린다.</li>
 *   <li>slave(runnshop_ro): 읽기 전용 목록·건수·집계 조회.</li>
 * </ul>
 * Mapper 인터페이스는 패키지로 연결된다 — {@code com.runnshop.{domain}.mapper.master} / {@code .mapper.slave},
 * SQL XML은 {@code resources/mapper/master/**} / {@code resources/mapper/slave/**}.
 */
@Configuration
@MapperScan(basePackages = "com.runnshop.**.mapper.master", sqlSessionFactoryRef = "masterSqlSessionFactory",
        nameGenerator = FullyQualifiedAnnotationBeanNameGenerator.class) // master/slave·도메인 간 같은 이름 Mapper 허용 (빈 이름 = 전체 클래스명)
@MapperScan(basePackages = "com.runnshop.**.mapper.slave", sqlSessionFactoryRef = "slaveSqlSessionFactory",
        nameGenerator = FullyQualifiedAnnotationBeanNameGenerator.class)
public class DataSourceConfig {

    // ── master ──

    @Bean
    @Primary
    @ConfigurationProperties("app.datasource.master")
    public HikariDataSource masterDataSource() {
        return new HikariDataSource();
    }

    @Bean
    @Primary
    public SqlSessionFactory masterSqlSessionFactory(@Qualifier("masterDataSource") DataSource dataSource) throws Exception {
        return sqlSessionFactory(dataSource, "classpath*:mapper/master/**/*.xml");
    }

    @Bean
    @Primary
    public DataSourceTransactionManager transactionManager(@Qualifier("masterDataSource") DataSource dataSource) {
        return new DataSourceTransactionManager(dataSource);
    }

    // ── slave ──

    @Bean
    @ConfigurationProperties("app.datasource.slave")
    public HikariDataSource slaveDataSource() {
        return new HikariDataSource();
    }

    @Bean
    public SqlSessionFactory slaveSqlSessionFactory(@Qualifier("slaveDataSource") DataSource dataSource) throws Exception {
        return sqlSessionFactory(dataSource, "classpath*:mapper/slave/**/*.xml");
    }

    private static SqlSessionFactory sqlSessionFactory(DataSource dataSource, String mapperLocations) throws Exception {
        var configuration = new org.apache.ibatis.session.Configuration();
        configuration.setMapUnderscoreToCamelCase(true);
        configuration.setLogPrefix("mybatis."); // SQL 로그 로거 이름을 mybatis.{매퍼 FQN}으로 통일 — logback.xml의 mybatis 로거로 일괄 제어

        var factory = new SqlSessionFactoryBean();
        factory.setDataSource(dataSource);
        factory.setConfiguration(configuration);
        factory.setMapperLocations(new PathMatchingResourcePatternResolver().getResources(mapperLocations));
        return factory.getObject();
    }
}
