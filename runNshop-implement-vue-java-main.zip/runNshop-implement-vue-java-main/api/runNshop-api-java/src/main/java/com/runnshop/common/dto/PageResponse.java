package com.runnshop.common.dto;

import java.util.List;

/** 공통 목록 응답 — C6 §6.2 {@code {"items": [...], "pagination": {page, size, totalCount, totalPages}}}. page는 1부터. */
public record PageResponse<T>(List<T> items, Pagination pagination) {

    public record Pagination(int page, int size, long totalCount, int totalPages) {
    }

    public static <T> PageResponse<T> of(List<T> items, int page, int size, long totalCount) {
        int totalPages = (int) ((totalCount + size - 1) / size);
        return new PageResponse<>(items, new Pagination(page, size, totalCount, totalPages));
    }
}
