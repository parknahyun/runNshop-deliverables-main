package com.runnshop.order.service;

import com.runnshop.common.dto.PageResponse;
import com.runnshop.order.dto.OrderRow;
import com.runnshop.order.mapper.slave.OrderMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

/** 주문 조회. */
@Service
@RequiredArgsConstructor
public class OrderService {

    /**
     * d
     */
    private final OrderMapper orderMapper;

    /** admin 주문 목록 — 최신순. page는 1부터. */
    public PageResponse<OrderRow> getAdminOrders(int page, int size) {

        List<OrderRow> items = orderMapper.selectList((page - 1) * size, size);

        long totalCount = orderMapper.count();

        return PageResponse.of(items, page, size, totalCount);
    }
}
