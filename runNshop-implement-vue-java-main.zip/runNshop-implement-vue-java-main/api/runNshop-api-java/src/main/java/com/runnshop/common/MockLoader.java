package com.runnshop.common;

import tools.jackson.databind.ObjectMapper;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Kotlin 구현(runNshop-api)의 {@code common.MockLoader}를 Java로 포팅한 동등 구현.
 * mock-data-rules.md(공통, docs submodule) 규칙을 그대로 따른다 — 경로/파일명 규칙은 언어와
 * 무관하다.
 */
@Component
public class MockLoader {

    private final ObjectMapper objectMapper;

    public MockLoader(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    /**
     * Mock JSON 파일을 로드하여 Map으로 반환한다.
     *
     * @param domain   Mock 파일이 속한 도메인 폴더명 (order, catalog, member, ...)
     * @param filename 채널 접두사(admin__/partner__/mobile__)가 포함된 파일명
     *                 (예: mobile__GET_products_{product_id}.json)
     */
    @SuppressWarnings("unchecked")
    public Map<String, Object> load(String domain, String filename) {
        ClassPathResource resource = new ClassPathResource("mock/" + domain + "/" + filename);
        if (!resource.exists()) {
            Map<String, Object> notFound = new LinkedHashMap<>();
            notFound.put("code", "NOT_FOUND");
            notFound.put("message", "Mock 파일을 찾을 수 없습니다: mock/" + domain + "/" + filename);
            return notFound;
        }
        try (InputStream in = resource.getInputStream()) {
            return objectMapper.readValue(in, Map.class);
        } catch (IOException e) {
            throw new IllegalStateException("Mock 파일 로딩 실패: mock/" + domain + "/" + filename, e);
        }
    }
}
