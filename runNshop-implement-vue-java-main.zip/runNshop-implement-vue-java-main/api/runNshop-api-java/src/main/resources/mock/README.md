# Mock 데이터

규칙은 `docs/.kiro/steering/mock-data-rules.md`(공통, submodule) 참조.
도메인별 하위 폴더(order/, catalog/, member/, ...)를 도메인 코드 포팅 시 추가한다.
