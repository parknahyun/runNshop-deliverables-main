package com.runnshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/** 스프링 컨텍스트(데이터소스·MyBatis·CORS 설정 포함)가 뜨는지 확인한다. */
@SpringBootTest
class RunNshopApiApplicationTests {

    @Test
    void contextLoads() {
    }
}
