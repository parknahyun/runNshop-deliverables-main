plugins {
    java
    id("org.springframework.boot") version "4.1.1"
    id("io.spring.dependency-management") version "1.1.7"
}

group = "com.runnshop"
version = "0.0.1-SNAPSHOT"

java {
    toolchain {
        languageVersion = JavaLanguageVersion.of(25)
    }
}

repositories {
    mavenCentral()
}

dependencies {
    implementation("org.springframework.boot:spring-boot-starter-web")
    // 요청 DTO 검증(@Valid, @NotBlank 등) — C1 "모든 검증은 서버에서", C6 VALIDATION_FAILED
    implementation("org.springframework.boot:spring-boot-starter-validation")
    compileOnly("org.projectlombok:lombok:1.18.44")
    annotationProcessor("org.projectlombok:lombok:1.18.44")
    // DB 접근은 MyBatis만 사용 — master(runnshop_rw)/slave(runnshop_ro) 2개 데이터소스. common/config/DataSourceConfig 참고.
    implementation("org.mybatis.spring.boot:mybatis-spring-boot-starter:4.1.0")
    runtimeOnly("org.postgresql:postgresql:42.7.10")
    testImplementation("org.springframework.boot:spring-boot-starter-test")
    testRuntimeOnly("org.junit.platform:junit-platform-launcher")
}

tasks.withType<Test> {
    useJUnitPlatform()
}
