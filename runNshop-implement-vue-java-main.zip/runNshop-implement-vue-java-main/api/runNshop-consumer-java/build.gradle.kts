plugins {
    java
    id("org.springframework.boot") version "4.1.1"
    id("io.spring.dependency-management") version "1.1.7"
}

group = "com.runnshop"
version = "0.0.1-SNAPSHOT"

java {
    toolchain {
        languageVersion = JavaLanguageVersion.of(25)
    }
}

repositories {
    mavenCentral()
}

// 컨슈머/배치 앱: 스케줄 + 이벤트 테이블 조회·상태 관리(JDBC) + 업무 처리는 API 서버 내부 API 호출(RestClient)
dependencies {
    implementation("org.springframework.boot:spring-boot-starter-web") // RestClient 용도 — 웹 서버는 띄우지 않는다(application.yml)
    implementation("org.springframework.boot:spring-boot-starter-jdbc")
    compileOnly("org.projectlombok:lombok:1.18.44")
    annotationProcessor("org.projectlombok:lombok:1.18.44")
    runtimeOnly("org.postgresql:postgresql:42.7.10")
    testImplementation("org.springframework.boot:spring-boot-starter-test")
}

tasks.withType<Test> {
    useJUnitPlatform()
}
