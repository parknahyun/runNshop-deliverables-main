package com.runnshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 컨슈머/배치 앱(Java 포트) 진입점. 웹 서버는 띄우지 않는다(application.yml,
 * kotlin-guide.md의 runNshop-consumer와 동일한 아키텍처 — 스케줄+이벤트조회는 이 앱이,
 * 업무 처리는 API 서버의 /api/internal/v1/** 호출로 위임).
 */
@SpringBootApplication
public class RunNshopConsumerApplication {

    public static void main(String[] args) {
        SpringApplication.run(RunNshopConsumerApplication.class, args);
    }
}
