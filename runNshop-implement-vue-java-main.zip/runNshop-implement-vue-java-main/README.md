# runNshop-implement-vue-java

runNshop의 Vue 3(admin) + Nuxt 4(mobile) + Java/Spring Boot 구현. `runNshop-react-kotlin`의 파생 프로젝트.

## 구성
- `apps/runNshop-admin-vue` — 플랫폼 어드민(Vue 3 + Vite + TypeScript, SPA, MDI 탭)
- `apps/runNshop-mobile-vue` — 고객웹(Vue 3 + Nuxt 4 + TypeScript, SSR)
- `api/runNshop-api-java`, `api/runNshop-consumer-java` — 백엔드(Java 25 + Spring Boot 4.1.1 +
  Gradle 9.7.1), 컨슈머/배치
- `docs/` — `runNshop-deliverables` 레포의 git submodule (공통 설계 문서 + 공통 steering/skill 원본)

## 처음 받기
`docs/`는 설계 문서 레포(runNshop-deliverables)를 서브모듈로 연결한 폴더입니다.
`git clone <URL>`만 하면 `docs/`가 비어 있으니, 반드시 아래 명령으로 받으세요.

```bash
git clone --recurse-submodules https://github.com/3top-fepest/runNshop-implement-vue-java.git
```

이미 받았는데 `docs/`가 비어 있다면 레포 루트에서 아래 명령을 실행하세요.
```bash
git submodule update --init --recursive
```

**`docs/`는 읽기 전용입니다.** 수정하지 않도록 아래처럼 막아 두었습니다.
- VS Code: `docs/`가 탐색기에 항상 보이고, 파일은 읽기 전용으로 열립니다(`.vscode/settings.json`).
- Claude Code: `docs/` 아래 파일은 수정할 수 없습니다(`.claude/settings.json`).
- 다른 IDE(IntelliJ 등)는 별도 설정이 없습니다. `docs/`가 보이는지, 실수로 수정되지 않는지 직접 확인하세요.

문서 수정은 [runNshop-deliverables](https://github.com/3top-fepest/runNshop-deliverables) 레포에서 하세요.

---
---

## 스킬 목록

| 스킬 | 도구 | 하는 일 | 부르는 법 |
|---|---|---|---|
| `pull-docs` | Claude Code | 코드 pull, `docs/`를 팀 공유 버전으로 맞추기, docs 최신 버전 확인·올리기 | `/pull-docs`, "pull 받아줘" |
| `doc-viewer` | Claude Code | 문서 뷰어(http://127.0.0.1:8001) 띄우기·끄기 | `/doc-viewer`, "문서 뷰어 띄워줘" |

- 위치: `.claude/skills/`
---
#### 최신 내용 받기: `/pull-docs`
`git pull`만으로는 `docs/` 내용이 바뀌지 않습니다.
Claude Code에서 `/pull-docs`(또는 "pull 받아줘")를 실행하면 아래 순서로 진행합니다.

1. 코드를 pull하고 `docs/`를 **팀 공유 버전**으로 맞춥니다. docs 연결 주소가 바뀌었으면 자동으로 갱신합니다.
2. 더 새로운 **docs 최신 버전**이 있으면 받을지 묻습니다.
3. 받았다면 **팀 공유 버전으로 올릴지** 묻습니다. 올리면 커밋과 push까지 합니다.

용어
- **팀 공유 버전:** 이 레포에 커밋되어 팀 전체가 똑같이 쓰는 docs 버전
- **docs 최신 버전:** runNshop-deliverables의 `main`에 올라온 가장 새로운 버전

Claude Code 없이 직접 받으려면:
```bash
git pull
git submodule sync --recursive
git submodule update --init --recursive
```
---
#### 문서 보기: `/doc-viewer`
`doc/`(이 레포 문서)와 `docs/`(설계 문서 허브)를 한 화면에서 보는 웹 뷰어입니다.
Claude Code에서 `/doc-viewer`(또는 "문서 뷰어 띄워줘")를 실행하면 서버를 띄우고 http://127.0.0.1:8001 주소를 알려 줍니다.

- 처음 실행할 때 필요한 설치를 자동으로 합니다. Python 3이 필요하고, 다이어그램을 보려면 Java도 필요합니다.
- Claude Code로 띄운 서버는 세션을 닫으면 같이 꺼집니다. 계속 켜 두려면 터미널에서 직접 실행하세요.
  - Windows: `tools\doc-viewer\run.cmd`
  - Mac/Linux: `./tools/doc-viewer/run.sh`
- 자세한 내용은 [tools/doc-viewer/README.md](tools/doc-viewer/README.md)를 참고하세요.

---
---
## 현재 상태
스캐폴드 단계 — 빌드 가능한 최소 구조(Application 클래스, MockLoader 포팅, build.gradle.kts)만
갖췄다. 도메인 코드(Controller/Service/Entity 등) 포팅은 범위를 정해 별도로 진행한다.
WBS 진행 트래킹은 0%(전체 미착수) 상태다.

- mobile-vue: 프레임워크 생성 완료(셸 + 17개 경로 "준비 중"), 화면 구현 전. 실행 방법은 `apps/runNshop-mobile-vue/README.md`
- admin-vue: 프레임워크 새로 생성(셸 + DE 메뉴 21개 "준비 중"), 화면 구현 전. 실행 방법은 `apps/runNshop-admin-vue/README.md`
- api-java: 기본 구조 완료(포트 8080, MyBatis master/slave, 공용 Supabase DB, 공통 응답 `ApiResponse`), 도메인 API 구현 전. 결정 대기 항목은 `doc/S4-구현/공통/프레임워크/api-java/결정사항.md`

## 빌드 확인
```bash
cd api/runNshop-api-java && ./gradlew compileJava
cd api/runNshop-consumer-java && ./gradlew compileJava
```
(JDK 25 toolchain을 자동 다운로드하도록 `settings.gradle.kts`에 foojay-resolver-convention 플러그인 적용됨)

## 관련 레포
- [runNshop-deliverables](https://github.com/3top-fepest/runNshop-deliverables) — 설계 문서 허브
- [runNshop-react-kotlin](https://github.com/3top-fepest/runNshop-react-kotlin) — 기존 React+Kotlin 구현

## 원본 레포
이 레포는 기존 `runNshop`(현재 아카이브) 레포에서 `apps/runNshop-admin-vue` 경로를 이력 보존하여
분리했고, Java 백엔드와 mobile-vue(Nuxt)는 이 레포에서 신규로 만들었다.
admin-vue는 2026-11-09에 기존 코드를 참고하지 않고 새로 만들었다(이전 코드는 git 이력에 남아 있다).
