# 주문결제 — Bolt1 (vue+java)

> 착수: 2026-11-10(월) | 구현 스택: vue+java(`implemet-vue-java`) 먼저, 완료 후 react+kotlin(`convert-react-kotlin`)으로 convert

## 구성

| 파일/폴더 | 내용 | 상태 |
|---|---|---|
| [DQ-프로그램목록.md](DQ-프로그램목록.md) | 기능 90건 목록 (react+kotlin Bolt1 설계를 포팅) | 준비됨 |
| [연관산출물/](연관산출물/index.md) | 프로그램 그룹별 S3 문서 매핑 (OKF 번들) | 준비됨 |
| 작업이력/ | `{날짜}-{개발자}-{작업}.md` — 실제 구현 시작 후 기록 | 착수 전 (비어있음) |
| 보완산출물.md | 이 Bolt 작업 중 부수 현행화된 타 문서 목록 | 착수 전 |

## 참고

- Bolt0(준비) 이전 react+kotlin의 역사적 구현 기록은 `S4-구현/주문결제/bolt0/`에 아카이브돼 있다
  (별도 작업으로 이동 예정).
- 담당 배정은 `DQ-프로그램목록.md` §8 참조 — react+kotlin 때 배정을 포팅했으며, vue+java 담당자가
  같은지는 휴먼 재확인 필요.
