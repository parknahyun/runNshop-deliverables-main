---
title: Bolt1(주문·결제) 연관산출물
version: 0.1.0
type: index
domain: 주문결제
bolt: bolt1
entries:
  - 장바구니.md
  - 주문서.md
  - 결제하기접수.md
  - 접수완료실패.md
  - 어드민주문.md
  - 타도메인연동.md
---

# Bolt1(주문·결제) 연관산출물

Bolt1의 프로그램 그룹별로 참조해야 할 S3 상세설계 문서를 매핑한 [OKF](https://okf.md/) 번들
(index + typed frontmatter + git-native, MIT 라이선스 스펙). 전체 기능 90건 목록은
[../DQ-프로그램목록.md](../DQ-프로그램목록.md) 참조.

| 그룹 | 기능 ID 범위 | 담당(포팅 참고, react+kotlin 기준) |
|---|---|---|
| [장바구니](장바구니.md) | B1-CART-01~13 | 개발자1 |
| [주문서](주문서.md) | B1-SHEET-01~19 | 개발자2 |
| [결제하기접수](결제하기접수.md) | B1-PAY-01~12 | 개발자2 |
| [접수완료실패](접수완료실패.md) | B1-DONE-01~08 | 개발자2 |
| [어드민주문](어드민주문.md) | B1-ALIST-*, B1-ADET-* | 개발자1 |
| [타도메인연동](타도메인연동.md) | B1-XDOM-01~06 | 개발자2 |

> 판매자 화면(B1-PART-*)·Consumer(B1-CSM-*)·Batch(B1-BAT-*)는 Bolt1 범위 밖(경계 확인용)이라
> 별도 연관산출물 파일을 두지 않았다 — `../DQ-프로그램목록.md` §2-3·4·5 참조.
