# C7 디자인 시스템 — Admin (runNshop-admin) (변경안)

> **변경안 — 작성 중** | 원본: `docs/deliverables/conventions/C7-디자인시스템/admin.md` | 복사 기준: 팀 공유 버전 `eff31a1`
> 변경 요약: 1장 Foundation 값에 CSS 변수 이름 추가(mobile과 같은 이름 체계), 스타일링·뷰포트 머리말을 결정 기준으로 갱신
> 반영 상태: 머리말·1장·근거 반영. 2~4장은 원본 그대로(이미 BEM) — 2장의 값은 1장 변수로 읽는다.
> 승인 전까지 이 레포에서는 이 파일이 원본보다 우선한다. 규칙은 [README](README.md) 참조.

> **스타일링**: 표준 CSS — 클래스는 BEM, 토큰은 `:root` CSS 변수(mobile과 같은 이름 체계), SCSS 미사용. 공통 스타일은 전역 CSS, 화면 전용은 `<style scoped>`
> **레이아웃**: NavBar + TabBar + TabContent (MDI 패턴) — Sidebar 여부는 PL 결정 대기([admin-vue 결정사항](../프레임워크/admin-vue/결정사항.md) #2)
> **뷰포트**: 데스크톱 전용 — 1280px 이상 기준 설계, 최소 폭 1024px(NFR-US-02), 반응형 미적용
> **수립 데드라인**: S3 화면레이아웃 작성 전 | **참고 대상**: DN 화면레이아웃, Vue 구현

---

## 1. Foundation

> 아래 변수는 전역 CSS의 `:root`에 정의한다. 화면·컴포넌트 CSS에서는 값을 직접 쓰지 않고 `var(--…)`로 참조한다.
> 이름은 [C7-mobile 변경안](C7-mobile-변경안.md) 1장과 같은 체계다. 같은 역할은 같은 이름, 레이아웃 크기만 앱별 이름이다. 척도에 없는 값은 용도 이름을 붙였다.

### Color

| 변수 | 값 | 용도 (원본 역할) |
|---|---|---|
| `--color-primary` | #0ea5e9 | Primary — 링크, CTA, NavBar 활성 하단 바 |
| `--color-secondary` | #1a1a2e | Body 텍스트 — 기본 텍스트 |
| `--color-success` | #22c55e | 완료 뱃지 |
| `--color-warning` | #f59e0b | 경고 뱃지, 대기 |
| `--color-error` | #ef4444 | 에러, 삭제 |
| `--color-white` | #ffffff | 카드 배경 — 카드, 테이블, 모달 |
| `--color-gray-50` | #f5f6fa | Body 배경 — 전체 배경 |
| `--color-gray-100` | #f1f5f9 | TabBar 배경, NavBar 텍스트 |
| `--color-gray-200` | #e2e8f0 | 구분선 — border 전반 |
| `--color-gray-400` | #94a3b8 | 보조 텍스트 — 부가정보 |
| `--color-gray-500` | #64748b | Tab 비활성 |
| `--color-gray-800` | #1e293b | NavBar 배경, Tab 활성 텍스트 |

- 회색 단계 번호는 원본의 slate 단계(100·200·400·500·800)를 따랐다. Body 배경 #f5f6fa는 slate에 없는 값이지만 mobile과 같은 역할(Body 배경)이라 `--color-gray-50`으로 두었다.

### Typography

| 변수 | 값 | 용도 (원본) |
|---|---|---|
| `--font-size-2xs` | 11px | `.badge`, 타임라인 시간 |
| `--font-size-xs` | 12px | `.table th`, `.tab`, 라벨 |
| `--font-size-nav` | 13px | `.nav-item__label`, 표 셀, 버튼 |
| `--font-size-sm` | 14px | 기본 |
| `--font-size-base` | 16px | 섹션 제목 |
| `--font-size-page-title` | 22px | `.page-title` |
| `--font-weight-regular` | 400 | 기본 |
| `--font-weight-medium` | 500 | `.table th`, `.badge`, 라벨 |
| `--font-weight-semibold` | 600 | 섹션 제목, 활성 탭 |
| `--font-weight-bold` | 700 | `.page-title`, 로고 |

- 시스템 폰트(`-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif`)는 전역 기본 스타일에서 지정한다.

### Spacing

| 변수 | 값 | 용도 (원본) |
|---|---|---|
| `--space-2` | 8px | 컴포넌트 gap(작게) |
| `--space-3` | 12px | 컴포넌트 gap(크게) |
| `--space-4` | 16px | 섹션 margin-bottom(작게), `.summary-card` 세로 패딩, `.filter-bar` 가로 패딩 |
| `--space-5` | 20px | `.summary-card` 가로 패딩 |
| `--space-6` | 24px | 섹션 margin-bottom(크게), `.page` 가로 패딩 |
| `--space-8` | 32px | `.page` 세로 패딩 |

- 이름 규칙은 mobile과 같다(`--space-N` = N × 4px). `.filter-bar` 세로 패딩 14px처럼 척도 밖 값은 2장 컴포넌트 정의를 따른다.

### Border & Radius

| 변수 | 값 | 용도 (원본) |
|---|---|---|
| `--radius-sm` | 4px | 뱃지 |
| `--radius-control` | 6px | 버튼, 입력, 탭 상단(`6px 6px 0 0`) |
| `--radius-md` | 8px | 카드, 필터, 모달 |
| `--radius-full` | 50% | 원형 |

### Layout 크기

| 변수 | 값 | 용도 (원본) |
|---|---|---|
| `--navbar-height` | 56px | NavBar 높이 |
| `--tabbar-height` | 40px | TabBar 높이 |
| `--page-max-width` | 1200px | `.page` 최대 폭 |
| `--layout-min-width` | 1024px | 화면 최소 폭(NFR-US-02, 원본에 없음) |

### Elevation

| 변수 | 값 | 요소 |
|---|---|---|
| (없음) | — | 대부분 그림자 없음 (border 구분) |
| `--shadow-modal` | `0 20px 60px rgba(0,0,0,0.3)` | 모달 |
| `--shadow-dropdown` | `0 4px 12px rgba(0,0,0,0.1)` | 드롭다운 |

---

## 2. Component (BEM 클래스)

> **원본 그대로.** 클래스 이름은 이미 BEM이다. 표 안의 값(#hex, px)은 1장 변수로 읽는다.

### Shell

| 클래스 | 역할 |
|---|---|
| `.shell` | `display:flex; flex-direction:column; height:100vh; overflow:hidden;` |
| `.navbar` | 상단 NavBar (h:56px, bg:#1e293b) |
| `.tabbar` | MDI 탭 바 (h:40px, bg:#f1f5f9) |
| `.tab-content` | 탭 콘텐츠 (flex:1, overflow:auto) |

### NavBar

| 클래스 | 역할 |
|---|---|
| `.nav-brand` | 로고 (16px, 700, color:#0ea5e9) |
| `.nav-menu` | 메뉴 목록 (flex, gap:4px) |
| `.nav-item` | 메뉴 항목 (13px, color:#94a3b8) |
| `.nav-item--active` | 활성 (color:#f1f5f9, border-bottom:2px #0ea5e9) |
| `.nav-item__badge` | 알림 수 뱃지 |
| `.nav-user` | 우측 사용자 |

### TabBar

| 클래스 | 역할 |
|---|---|
| `.tab` | 탭 (12px, color:#64748b, top:1px) |
| `.tab--active` | 활성 (bg:#fff, border, 600) |
| `.tab__label` | 제목 (ellipsis, max-width:200px) |
| `.tab__close` | [×] (16×16, 50%, hover:bg) |

### Page

| 클래스 | 역할 |
|---|---|
| `.page` | max-width:1200px, margin:auto, padding:32px 24px |
| `.page-title` | 22px/700, mb:24px |

### SummaryBar

| 클래스 | 역할 |
|---|---|
| `.summary-bar` | flex, gap:12px, mb:20px |
| `.summary-bar--compact` | 카드 다수(5+)일 때 — 카드를 가로 배치, 내용 크기 기반 폭 |
| `.summary-card` | flex:1, bg:#fff, border, radius:8px, padding:16px 20px |
| `.summary-card` (compact 내) | flex:initial, flex-direction:row, min-height:36px, padding:0 14px, gap:6px |
| `.summary-card__label` | 12px, color:#64748b (compact: mb:0) |
| `.summary-card__count` | 24px, 700 (compact: 13px, 700) |
| `.summary-card--warn` | border:#f59e0b, bg:#fffbeb, count:#d97706 |
| `.summary-card--info` | border:#60a5fa, bg:#eff6ff, count:#1d4ed8 |

#### SummaryBar + Toolbar 한 줄 패턴

SummaryBar 옆에 액션 버튼([엑셀 다운로드] 등)을 같은 행에 배치하는 패턴:

```
┌─ 한 줄 row (flex, align-items:center, gap:12px) ─────────────┐
│ [summary-bar--compact: 카드1 카드2 ... 카드N]  [엑셀 다운로드] │
│  ← flex:1                                    ← flex-shrink:0  │
└───────────────────────────────────────────────────────────────┘
```

- 래퍼: `display:flex; align-items:center; gap:12px; margin-bottom:16px;`
- SummaryBar: `flex:1; margin-bottom:0;`
- 버튼: `flex-shrink:0;`

### FilterBar

| 클래스 | 역할 |
|---|---|
| `.filter-bar` | flex, gap:8px, bg:#fff, border, radius:8px, padding:14px 16px, mb:16px |
| `.filter-bar__input` | h:32px, border, radius:6px, min-width:180px |
| `.filter-bar__select` | h:32px, border, radius:6px |
| `.filter-bar__btn` | h:32px, bg:#0ea5e9, color:#fff, radius:6px |

### Table

| 클래스 | 역할 |
|---|---|
| `.table-wrap` | bg:#fff, border, radius:8px, overflow:hidden |
| `.table` | width:100%, collapse |
| `.table th` | 12px, uppercase, bg:#f8fafc, border-bottom |
| `.table td` | 13px, border-bottom:#f1f5f9 |
| `.table tr:hover td` | bg:#f8fafc |
| `.table__link` | color:#0ea5e9, underline on hover |

### Badge

| 클래스 | 스타일 |
|---|---|
| `.badge` | inline-flex, gap:4px, padding:2px 8px, radius:4px, 11px/500 |
| `.badge--blue` | bg:#eff6ff, color:#1d4ed8 |
| `.badge--green` | bg:#f0fdf4, color:#15803d |
| `.badge--yellow` | bg:#fffbeb, color:#b45309 |
| `.badge--red` | bg:#fef2f2, color:#dc2626 |
| `.badge--gray` | bg:#f1f5f9, color:#64748b |

### Modal

| 클래스 | 역할 |
|---|---|
| `.modal-overlay` | fixed, inset:0, bg:rgba(0,0,0,0.4), z:200 |
| `.modal` | max-width:640px, bg:#fff, radius:12px, shadow |
| `.modal__header` | flex, padding:20px 24px, border-bottom |
| `.modal__body` | padding:24px, overflow-y:auto |
| `.modal__footer` | flex, gap:8px, padding:16px 24px, border-top |
| `.modal--sm` | max-width:400px |

### Form

| 클래스 | 역할 |
|---|---|
| `.form-group` | mb:16px |
| `.form-group__label` | 12px/500, mb:6px |
| `.form-input` | h:36px, border, radius:6px, padding:0 12px |
| `.form-select` | 동일 |
| `.btn` | h:36px, radius:6px, padding:0 16px, 13px/500 |
| `.btn--primary` | bg:#0ea5e9, color:#fff |
| `.btn--danger` | bg:#ef4444, color:#fff |

### Timeline

| 클래스 | 역할 |
|---|---|
| `.timeline` | padding-left:20px, border-left:2px #e2e8f0 |
| `.timeline-item` | position:relative, mb:16px |
| `.timeline-item__dot` | absolute, left:-25px, w:10px, h:10px, radius:50% |
| `.timeline-item__content` | 13px |
| `.timeline-item__time` | 11px, color:#94a3b8 |

### Toast

| 클래스 | 스타일 |
|---|---|
| `.toast` | fixed, bottom:24px, left:50%, transform, padding:10px 20px, radius:8px, z:9999, shadow |
| `.toast--success` | bg:#22c55e, color:#fff |
| `.toast--error` | bg:#ef4444, color:#fff |
| `.toast--info` | bg:#1e293b, color:#fff |
| 동작 | 3초 후 fadeOut (opacity transition 0.3s) |

### Skeleton

| 클래스 | 스타일 |
|---|---|
| `.skeleton` | bg:#e2e8f0, radius:6px, animation:pulse 1.5s infinite |
| `.skeleton--line` | height:14px, mb:8px |
| `.skeleton--card` | height:80px, mb:12px |

### Pagination

| 클래스 | 역할 |
|---|---|
| `.pagination` | flex, center, gap:4px, padding:16px |
| `.pagination__btn` | 32×32, border, radius:6px, 13px |
| `.pagination__btn--active` | bg:#0ea5e9, color:#fff |

---

## 3. Layout — MDI 쉘

```
┌────────────────────────────────────────────────────────────────┐
│ .navbar (h:56px, bg:#1e293b)                                    │
│  [nav-brand] [nav-menu: 홈|상품|주문|회원|...] [nav-user]      │
├────────────────────────────────────────────────────────────────┤
│ .tabbar (h:40px, bg:#f1f5f9, border-bottom)                    │
│  [tab--active: 주문현황 ×] [tab: 클레임관리 ×]                  │
├────────────────────────────────────────────────────────────────┤
│ .tab-content (flex:1, overflow:auto, bg:#f5f6fa)               │
│   .page (max-width:1200px, padding:32px 24px)                  │
│     [page-title] + [summary-bar] + [filter-bar] + [table-wrap] │
└────────────────────────────────────────────────────────────────┘
```

---

## 4. Template → Page 매핑

| Template | 구성 | 해당 페이지 |
|---|---|---|
| T-DASHBOARD | SummaryCards + TrendChart + PendingItems + SystemAlerts | 홈 |
| T-LIST | PageTitle + SummaryBar + FilterBar + Table + Pagination | 주문현황, 클레임관리, 회원, 상품 |
| T-DETAIL-MDI | PageTitle + InnerTabs(탭별 콘텐츠) | 주문상세, 클레임상세 |
| T-FORM-MODAL | Modal(Header + Form + Footer) | 생성/수정 |
| T-TREE | PageTitle + TreeView + Detail Panel | 카테고리 |

---

## 근거

| 항목 | 출처 |
|---|---|
| BEM 클래스 전체 | 원본 React 구현 `apps/runNshop-admin/src/app/globals.css` (1800+ lines) 기준 |
| 레이아웃 | 원본 React 구현 `app/layout.tsx` 기준 |
| 테마 색상 | NavBar #1e293b, Primary #0ea5e9 |
| 변수 이름 | [admin-vue 결정사항](../프레임워크/admin-vue/결정사항.md) #9, [C7-mobile 변경안](C7-mobile-변경안.md) 1장 |
| 뷰포트 | [[S1-범위정의/D8-NFR]] NFR-US-02 |
| 스타일링 규칙 | [mobile-vue 결정사항](../프레임워크/mobile-vue/결정사항.md) 스타일링·CSS 클래스 이름 규칙·스타일 위치 |
