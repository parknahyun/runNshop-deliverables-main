# C7 디자인 시스템 — Mobile (runNshop-mobile) (변경안)

> **변경안 — 작성 중** | 원본: `docs/deliverables/conventions/C7-디자인시스템/mobile.md` | 복사 기준: 팀 공유 버전 `eff31a1`
> 변경 요약: Tailwind 기준 → 표준 CSS 기준(토큰은 CSS 변수), 주문서 경로 /orders/new → /checkout, 뷰포트 360px → 320~428px
> 반영 상태: 머리말·1장(Foundation)·3장 높이·4장 경로 반영. **2장(Component) 클래스는 아직 원본(Tailwind) 표기** — 화면 구현 때 BEM 클래스로 바꾼다.
> 승인 전까지 이 레포에서는 이 파일이 원본보다 우선한다. 규칙은 [README](README.md) 참조.

> **스타일링**: 표준 CSS — 클래스는 BEM, 토큰은 `:root` CSS 변수, SCSS 미사용. 공통 스타일은 전역 CSS, 화면 전용은 `<style scoped>`
> **레이아웃**: Header + Content + BottomNav (Nuxt `layouts/`)
> **뷰포트**: 320~428px 대응(NFR-US-01), 콘텐츠 최대 폭 428px 가운데 정렬, 모바일 전용
> **수립 데드라인**: S3 화면레이아웃 작성 전 | **참고 대상**: DN 화면레이아웃, Vue(Nuxt) 구현

---

## 1. Foundation

> 아래 변수는 전역 CSS의 `:root`에 정의한다. 화면·컴포넌트 CSS에서는 값을 직접 쓰지 않고 `var(--…)`로 참조한다.
> 원본의 Tailwind 클래스는 비교용으로 "원본" 열에 남긴다.

### Color

| 변수 | 값 | 용도 | 원본 |
|---|---|---|---|
| `--color-primary` | #FF4D00 | CTA, 강조, SALE 뱃지 | `primary` |
| `--color-secondary` | #1A1A1A | 제목, 주요 텍스트, NEW 뱃지 | `secondary` |
| `--color-success` | #00C853 | 성공 상태, 완료 뱃지 | `success` |
| `--color-warning` | #FF9800 | 경고, 대기 상태 | `warning` |
| `--color-error` | #F44336 | 에러, 실패, 취소 | `error` |
| `--color-gray-50` | #F9FAFB | Body 배경 | `gray-50` |
| `--color-gray-200` | #E5E7EB | 구분선, 카드 border, Skeleton | `gray-200` |
| `--color-gray-300` | #D1D5DB | 입력·보조 버튼 border | `gray-300` |
| `--color-gray-400` | #9CA3AF | 비활성 텍스트, BottomNav 비활성 | `gray-400` |
| `--color-gray-500` | #6B7280 | 태그 텍스트, 품절 오버레이 | `gray-500` |
| `--color-gray-600` | #4B5563 | 보조 텍스트 | `gray-600` |
| `--color-gray-900` | #111827 | BottomNav 배경 | `gray-900` |
| `--color-white` | #FFFFFF | 헤더·카드 배경 | `white` |

- 회색 값: 원본은 "Tailwind 기본"으로만 적혀 있어 Tailwind v3 기본 gray 팔레트 값을 옮겼다. 300·500은 원본 2장 컴포넌트에서 쓰여 추가.

### Typography

| 변수 | 값 |
|---|---|
| `--font-size-xs` | 12px |
| `--font-size-sm` | 14px |
| `--font-size-base` | 16px |
| `--font-weight-regular` | 400 |
| `--font-weight-bold` | 700 |

| 용도 | 크기 | 굵기 | 색 | 원본 |
|---|---|---|---|---|
| 브랜드 로고 | `--font-size-sm` | bold | `--color-secondary` | `font-bold text-sm text-secondary` |
| 섹션 타이틀 | `--font-size-base` | bold | `--color-secondary` | `text-base font-bold text-secondary` |
| 본문 | `--font-size-sm` | regular | `--color-secondary` | `text-sm text-secondary` |
| 보조/캡션 | `--font-size-xs` | regular | `--color-gray-600` | `text-xs text-gray-600` |
| 카테고리 GNB | `--font-size-xs` | regular | `--color-gray-600`, 줄바꿈 없음 | `text-xs text-gray-600 whitespace-nowrap` |
| BottomNav 활성 | `--font-size-xs` | bold | `--color-white` | `text-xs font-bold text-white` |
| BottomNav 비활성 | `--font-size-xs` | regular | `--color-gray-400` | `text-xs text-gray-400` |
| 가격 (할인 전) | `--font-size-xs` | regular | `--color-gray-400`, 취소선 | `text-xs text-gray-400 line-through` |
| 가격 (판매가) | `--font-size-sm` | bold | `--color-secondary` | `text-sm font-bold text-secondary` |

### Spacing

| 변수 | 값 | 용도 | 원본 |
|---|---|---|---|
| `--space-3` | 12px | 좌우 Safe Area, 섹션 간 간격, 카드 내부 패딩, 컴포넌트 간 gap | `px-3`, `space-y-3`, `p-3`, `gap-3` |
| `--space-4` | 16px | 컴포넌트 간 gap(넓게) | `gap-4` |

### Border & Radius

| 변수 | 값 | 용도 | 원본 |
|---|---|---|---|
| `--radius-sm` | 4px | 버튼 | `rounded` |
| `--radius-md` | 8px | 카드 (border 1px `--color-gray-200`) | `rounded-lg border border-gray-200` |
| `--radius-lg` | 16px | 팝업 상단 | `rounded-t-2xl` |
| `--radius-full` | 9999px | 원형 | `rounded-full` |

### Layout 크기

| 변수 | 값 | 용도 | 원본 |
|---|---|---|---|
| `--layout-max-width` | 428px | 콘텐츠 최대 폭(320~428px 대응) | `max-w-[360px]` |
| `--header-height` | 48px | Header | `h-12` |
| `--gnb-height` | 32px | GNB | `h-8` |
| `--bottom-nav-height` | 48px | BottomNav | `h-12` |

### Elevation

| 변수 | 값 | 요소 | 처리 | 원본 |
|---|---|---|---|---|
| `--z-gnb` | 10 | GNB | sticky, top `--header-height` | `sticky top-12 z-10` |
| `--z-header` | 20 | 헤더 | sticky, top 0 | `sticky top-0 z-20` |
| `--z-sticky-bottom` | 20 | StickyBottom CTA | fixed, bottom `--bottom-nav-height`, 위쪽 border | `fixed bottom-12 z-20 border-t` |
| `--z-bottom-nav` | 30 | BottomNav | fixed, bottom 0 | `fixed bottom-0 z-30` |
| `--z-overlay` | 40 | LayerPopup Overlay | fixed, 화면 전체 | `z-40` |
| `--z-popup` | 50 | LayerPopup Sheet, Toast | fixed | `z-50` |
| `--shadow-lg` | `0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1)` | Toast | | `shadow-lg` |

---

## 2. Component

> **아직 원본(Tailwind) 표기.** 화면 구현 때 BEM 클래스(예: `.button--primary`)와 1장 변수로 바꾼다. 클래스 열의 `max-w-[360px]`은 `--layout-max-width`(428px)로 읽는다.

### Button

| 변형 | 클래스 | 용도 |
|---|---|---|
| Primary | `bg-primary text-white px-4 py-3 rounded font-bold text-sm` | 구매, 결제, 신청 |
| Secondary | `border border-gray-300 text-secondary px-4 py-3 rounded text-sm` | 취소, 닫기 |
| Text | `text-primary text-xs` / `text-sm` | 더보기, 링크, [옵션변경] |
| Disabled | `bg-gray-200 text-gray-400 cursor-not-allowed` | 미동의, 재고부족 |
| Small | `border border-primary text-primary rounded px-2 py-1 text-xs` | [전액사용] 등 |

### Badge

| 변형 | 클래스 | 용도 |
|---|---|---|
| NEW | `bg-secondary text-white text-xs px-1` | 신상품 |
| SALE | `bg-primary text-white text-xs px-1` | 할인 |
| 품절 | `absolute inset-0 bg-gray-500/70 rounded` + 중앙 텍스트 | 품절 오버레이 |
| 상태 | `bg-{success/warning/error} text-white text-xs rounded px-2` | 주문/클레임 상태 |
| 기본배송지 | `border border-gray-300 rounded text-xs text-gray-500 px-1` | 태그 |

### Input

| 변형 | 클래스 | 용도 |
|---|---|---|
| Text | `border border-gray-300 rounded px-2 py-1 text-sm` | 일반 입력 |
| Number | 위와 동일 + `type="number"` | 포인트, 수량 |
| Checkbox | `w-4 h-4` | 약관 동의 |
| Stepper | `w-6 h-6 border border-gray-300 rounded text-xs` 버튼 + 가운데 수량 | 수량 +/- |

### Card

| 변형 | 구조 | 용도 |
|---|---|---|
| ProductCard | 이미지(1:1) + 뱃지 + 상품명 + 가격 | 상품 목록 |
| CartItem | 이미지(w-16 h-16) + 상품명/옵션/가격/수량/삭제 | 장바구니 |
| OrderCard | 주문번호 + 상태뱃지 + 상품요약 + 금액 | 주문 목록 |
| ClaimCard | 클레임번호 + 유형 + 상태 + 타임라인 | 클레임 목록 |
| VendorGroup | `bg-white rounded-lg border border-gray-200 p-3` 안에 아이템 목록 | 판매자별 그룹 |

### Section (폼 섹션 카드)

> 주문서·클레임신청 등 L-FORM 화면에서 사용하는 정보 섹션 단위.
> 모든 섹션은 동일한 **섹션 헤더 패턴**을 따른다.

**섹션 컨테이너**: `bg-white rounded-lg border border-gray-200 p-3`

**섹션 헤더 패턴** (통일 규칙):

```
┌─────────────────────────────────────┐
│ [라벨]                   [우측 액션] │
│  text-sm font-bold        text-xs   │
│  text-secondary          text-primary│
└─────────────────────────────────────┘
```

| 요소 | 클래스 | 설명 |
|---|---|---|
| 래퍼 | `flex items-center justify-between mb-1` | 헤더 행 |
| 라벨 | `text-sm font-bold text-secondary` | 섹션 제목 (배송지, 쿠폰, 포인트, 결제수단) |
| 우측 액션 | `text-xs text-primary` | [변경], 사용 가능 N장 [>], 보유 N P 등 |
| 우측 보조값 | `text-xs text-gray-400` | 보유 포인트 등 비강조 정보 |

**적용 예시**:

| 섹션 | 라벨 | 우측 |
|---|---|---|
| 배송지 | "배송지" | `[변경]` (text-primary) |
| 쿠폰 | "쿠폰" | `사용 가능 2장 [>]` (text-primary) |
| 포인트 | "포인트" | `보유 5,200P` (text-gray-400) |
| 결제 수단 | "결제 수단" | — |
| 결제 금액 | "결제 금액" (font-bold) | — |

### Toast

| 변형 | 클래스 |
|---|---|
| Success | `fixed bottom-16 left-1/2 -translate-x-1/2 bg-secondary text-white px-4 py-2 rounded-lg text-xs shadow-lg z-50` |
| Error | 위와 동일 + `bg-error` |
| 동작 | 2초 후 opacity 0 → 제거 (transition-opacity duration-300) |

### LayerPopup (BottomSheet)

| 요소 | 클래스 |
|---|---|
| Overlay | `fixed inset-0 bg-black/50 z-40` (클릭 시 닫기) |
| Sheet | `fixed bottom-0 left-0 right-0 max-w-[360px] mx-auto bg-white rounded-t-2xl z-50 max-h-[80vh] overflow-y-auto` |
| Header | `flex items-center justify-between px-4 py-3 border-b border-gray-200` (타이틀 + [✕]) |
| Body | `px-4 py-3` |
| Footer | `px-4 py-3 border-t border-gray-200` (CTA 버튼) |
| 용도 | 옵션 변경, 쿠폰 적용, 배송지 선택, 배송비 결제 |

### Skeleton (로딩)

| 요소 | 클래스 |
|---|---|
| Block | `bg-gray-200 rounded-lg animate-pulse h-{20~24}` |
| Line | `h-3 bg-gray-200 rounded animate-pulse` |
| 사용법 | `count` prop으로 반복, API 응답 후 교체 |

---

## 3. Layout

| Layout | 구조 | 사용 페이지 |
|---|---|---|
| **L-MAIN** | Header(48px, sticky) + GNB(32px, sticky) + Content(scroll, 아래 여백 48px) + BottomNav(48px, fixed) | 홈, 목록, 마이페이지 |
| **L-DETAIL** | BackHeader + Content(scroll) + StickyBottom(fixed, bottom 48px) | 상품상세, 주문상세, 클레임상세 |
| **L-FORM** | BackHeader + Content(scroll, 아래 여백 96px) + StickyBottom(CTA) | 주문서, 클레임신청, 배송비결제 |

---

## 4. Template → Page 매핑

| Template | Layout | 페이지 경로 |
|---|---|---|
| T-HOME | L-MAIN | `/` |
| T-LIST | L-MAIN | `/category/{code}`, `/search` |
| T-DETAIL | L-DETAIL | `/products/{id}` |
| T-CART | L-FORM | `/cart` |
| T-ORDER | L-FORM | `/checkout` (원본 `/orders/new`, DE 기준으로 변경) |
| T-MY | L-MAIN | `/my` |
| T-MY-ORDERS | L-MAIN | `/my/orders` |
| T-MY-CLAIMS | L-MAIN | `/my/claims` |
| T-CLAIM-DETAIL | L-DETAIL | `/my/claims/{id}` |
| T-CLAIM-REQUEST | L-FORM | `/my/orders/{id}/claim` |

---

## 근거

| 항목 | 출처 |
|---|---|
| 컬러 토큰 | 원본 값(`apps/runNshop-mobile/tailwind.config.ts`) 그대로, 회색은 Tailwind v3 기본 팔레트 |
| 레이아웃 구조 | 원본 React 구현(`components/layout/Header.tsx`, `BottomNav.tsx`, `GNB.tsx`) 기준 |
| 뷰포트 | [[S1-범위정의/D8-NFR]] NFR-US-01 (320~428px) — 원본 `app/layout.tsx`의 360px 대신 |
| 주문서 경로 | [[DE-메뉴구조도/mobile]] |
| 스타일링 규칙 | [mobile-vue 결정사항](../프레임워크/mobile-vue/결정사항.md) 스타일링·CSS 클래스 이름 규칙·스타일 위치 |
