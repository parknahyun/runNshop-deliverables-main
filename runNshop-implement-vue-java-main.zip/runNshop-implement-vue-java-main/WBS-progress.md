# WBS 진행 트래킹 (runNshop-implement-vue-java)

> 템플릿(L0~L3 레벨, Bolt 분해 방식)은 공통이며 `docs/weekly-report/tmp/WBS_*.md`(초안
> 단계) 및 `docs/reference/.ai-methodology/methodology/파생프로젝트-가이드.md` §5 참조. 이 문서는 **이 레포만의
> 진행 상태**를 기록한다 — 허브(docs)에는 진행률을 남기지 않는다.

## 현재 상태: 0% (전체 미착수)

스캐폴드만 완료된 상태다 — Java 백엔드 빌드 구조, Vue 프론트 기존 코드(admin-vue) 연결, docs
submodule 연결까지 끝났고, 실제 도메인(Bolt) 포팅은 아직 시작하지 않았다.

| 단계(L1) | 상태 | 비고 |
|---|---|---|
| 구조설계 | 완료(docs 참조) | Kotlin 구현과 공유 — 재작업 불필요 |
| Bolt 상세설계+구현 | 미착수 | 포팅 우선순위·범위는 별도 확정 필요 |
| 테스트 | 미착수 | |
| 안정화 | 미착수 | |

도메인/Bolt별 세부 진행은 포팅 범위가 확정되는 시점에 L2~L3 표로 추가한다.
