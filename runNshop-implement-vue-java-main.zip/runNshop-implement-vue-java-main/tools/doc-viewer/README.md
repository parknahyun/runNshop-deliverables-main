# 문서 웹 뷰어 (doc + docs)

이 레포의 `doc/**`와 설계 문서 허브(`docs/` 서브모듈)를 **한 서버**에서 봅니다.
폴더 트리 메뉴, 전체 검색, 위키링크, PlantUML 다이어그램, 문서 수정 시 자동 새로고침을 지원합니다.

## 실행
| OS | 명령 (레포 루트에서) |
|---|---|
| Windows | `tools\doc-viewer\run.cmd` |
| Mac/Linux | `./tools/doc-viewer/run.sh` |

브라우저에서 http://127.0.0.1:8001 을 엽니다. 종료는 `Ctrl+C`입니다.

처음 실행할 때 `.venv` 생성, 패키지 설치, PlantUML jar 다운로드를 자동으로 합니다.
필요한 것: Python 3, Java(PlantUML 다이어그램용, 없으면 다이어그램만 안 그려짐).

## 메뉴 구성
- **doc/**: 이 레포의 `doc/` (단, `doc/deliverables`는 허브와 중복이라 제외)
- **docs/**: 허브 문서 (`docs/docs/**`, 허브가 평탄화되면 `docs/**`를 자동으로 사용)

## 동작 방식
- MkDocs는 폴더 하나만 읽기 때문에, `hooks.py`가 두 폴더의 파일을 한 사이트로 합칩니다.
  symlink나 복사를 쓰지 않아 Windows에서도 동작합니다.
- 위키링크 변환과 메뉴 스타일은 허브 뷰어(`docs/docs-viewer` 또는 `docs/deliverables-viewer`)의
  `hooks.py`, `extra.css`를 그대로 불러 씁니다. `docs/`는 수정하지 않습니다.
- 허브 뷰어(포트 8000)와 동시에 띄울 수 있도록 포트 8001을 씁니다.
