# Doc viewer (Windows): doc/** + docs hub on one server -> http://127.0.0.1:8001
# Usage: tools\doc-viewer\run.cmd   (first run installs .venv and PlantUML jar automatically)
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

$venvPy = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
$jar = Join-Path $PSScriptRoot '.venv\plantuml.jar'
$jarUrl = 'https://repo1.maven.org/maven2/net/sourceforge/plantuml/plantuml/1.2024.7/plantuml-1.2024.7.jar'

if (-not (Test-Path $venvPy)) {
    Write-Host '[doc-viewer] First run: creating .venv and installing packages...'
    if (Get-Command py -ErrorAction SilentlyContinue) {
        & py -3 -m venv .venv
    } else {
        & python -m venv .venv
    }
    if (-not (Test-Path $venvPy)) { throw 'Python 3 not found. Install Python 3 and try again.' }
    & $venvPy -m pip install --disable-pip-version-check -q -r requirements.txt
    if ($LASTEXITCODE -ne 0) { throw 'pip install failed.' }
}

if (-not (Test-Path $jar)) {
    Write-Host '[doc-viewer] Downloading PlantUML jar...'
    Invoke-WebRequest -Uri $jarUrl -OutFile $jar -UseBasicParsing
}

if (-not (Get-Command java -ErrorAction SilentlyContinue)) {
    Write-Host '[doc-viewer] WARNING: java not found. PlantUML diagrams will not render.'
}

Write-Host '[doc-viewer] http://127.0.0.1:8001  (Ctrl+C to stop)'
& $venvPy -m mkdocs serve -a 127.0.0.1:8001
