# -*- coding: utf-8 -*-
"""MkDocs 훅: 이 레포의 doc/** 와 허브(docs 서브모듈)의 문서를 한 사이트로 합친다.

MkDocs는 docs_dir 하나만 읽으므로, symlink나 복사 없이 두 폴더의 파일을 직접 목록에 붙인다.
  - doc/**   → 사이트의 doc/   (단, doc/deliverables 는 허브와 중복이라 제외)
  - 허브 문서 → 사이트의 docs/  (docs/docs/** 또는 평탄화 이후의 docs/**)
  - 루트 README.md → 사이트의 README.html
위키링크 변환·메뉴 스타일은 허브 뷰어(docs-viewer 또는 deliverables-viewer)의 hooks.py를 불러 쓴다.
"""
import importlib.util
import os
import sys

from mkdocs.structure.files import File

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.normpath(os.path.join(HERE, "..", ".."))
HUB = os.path.join(REPO, "docs")
HUB_VIEWER_NAMES = ("deliverables-viewer", "docs-viewer")

EXCLUDE_EXT = (".pptx",)
EXCLUDE_NAMES = (".DS_Store",)


def _hub_content_dir():
    """허브 문서 위치. 평탄화 전에는 docs/docs, 평탄화 후에는 docs 자체."""
    nested = os.path.join(HUB, "docs")
    return nested if os.path.isdir(nested) else HUB


def _hub_viewer_dir():
    for name in HUB_VIEWER_NAMES:
        d = os.path.join(HUB, name)
        if os.path.isfile(os.path.join(d, "hooks.py")):
            return d
    return None


def _load_hub_hooks():
    d = _hub_viewer_dir()
    if not d:
        return None
    spec = importlib.util.spec_from_file_location("hub_viewer_hooks", os.path.join(d, "hooks.py"))
    mod = importlib.util.module_from_spec(spec)
    # docs/ 안에 __pycache__가 생기지 않도록 이 import 동안만 바이트코드 저장을 끈다.
    prev = sys.dont_write_bytecode
    sys.dont_write_bytecode = True
    try:
        spec.loader.exec_module(mod)
    finally:
        sys.dont_write_bytecode = prev
    return mod


_hub = _load_hub_hooks()


def _mounts():
    """(마운트할 폴더, 그 폴더 바로 아래에서 제외할 이름들)"""
    hub_dir = _hub_content_dir()
    hub_skip = set(HUB_VIEWER_NAMES) if hub_dir == HUB else set()
    return [
        (os.path.join(REPO, "doc"), {"deliverables"}),
        (hub_dir, hub_skip),
    ]


def _walk(root, top_skip):
    for dirpath, dirnames, filenames in os.walk(root):
        rel_dir = os.path.relpath(dirpath, root)
        dirnames[:] = sorted(
            d for d in dirnames
            if not d.startswith(".") and not (rel_dir == "." and d in top_skip)
        )
        for name in sorted(filenames):
            if name.startswith(".") or name in EXCLUDE_NAMES or name.endswith(EXCLUDE_EXT):
                continue
            if rel_dir == "." and name in top_skip:
                continue
            yield os.path.join(dirpath, name)


def on_config(config):
    # PlantUML 래퍼를 지금 실행 중인 파이썬(가상환경)으로 부른다 — OS마다 python/python3 이름이 달라서.
    for name, opts in config["mdx_configs"].items():
        if name == "plantuml_markdown":
            wrapper = os.path.join(HERE, "plantuml-wrapper.py").replace("\\", "/")
            opts["plantuml_cmd"] = f"{sys.executable.replace(chr(92), '/')} {wrapper}"
    return config


def on_files(files, config):
    # 루트 README.md → 사이트의 README.html (메뉴 맨 위).
    # MkDocs는 README.md를 index.html로 바꾸는데, 첫 화면(home/index.md)과 겹치므로 출력 경로를 직접 지정한다.
    if os.path.isfile(os.path.join(REPO, "README.md")):
        files.append(File("README.md", REPO, config["site_dir"], config["use_directory_urls"],
                          dest_uri="README.html"))
    for root, top_skip in _mounts():
        if not os.path.isdir(root):
            continue
        # 사이트 경로 접두어 = 폴더 이름(doc / docs). src_dir을 상위 폴더로 두면 경로에 그대로 붙는다.
        src_dir = os.path.dirname(root)
        for abs_path in _walk(root, top_skip):
            rel = os.path.relpath(abs_path, src_dir).replace(os.sep, "/")
            files.append(File(rel, src_dir, config["site_dir"], config["use_directory_urls"]))
    if _hub and hasattr(_hub, "on_files"):
        files = _hub.on_files(files, config) or files
    return files


def on_page_markdown(markdown, page, config, files):
    if _hub and hasattr(_hub, "on_page_markdown"):
        return _hub.on_page_markdown(markdown, page, config, files)
    return markdown


def on_post_build(config):
    if _hub and hasattr(_hub, "on_post_build"):
        _hub.on_post_build(config)
