#!/bin/sh
# 문서 웹 뷰어 (Mac/Linux): doc/** + docs 허브를 한 서버로 → http://127.0.0.1:8001
# 최초 실행 시 .venv와 PlantUML jar를 자동으로 설치한다.
set -e
cd "$(dirname "$0")"

JAR_URL=https://repo1.maven.org/maven2/net/sourceforge/plantuml/plantuml/1.2024.7/plantuml-1.2024.7.jar

if [ -x .venv/bin/python ]; then PY=.venv/bin/python
elif [ -x .venv/Scripts/python.exe ]; then PY=.venv/Scripts/python.exe
else
  echo "[doc-viewer] 최초 설치: .venv 생성 + 패키지 설치"
  python3 -m venv .venv 2>/dev/null || python -m venv .venv
  if [ -x .venv/bin/python ]; then PY=.venv/bin/python; else PY=.venv/Scripts/python.exe; fi
  "$PY" -m pip install --disable-pip-version-check -q -r requirements.txt
fi

[ -f .venv/plantuml.jar ] || { echo "[doc-viewer] PlantUML jar 다운로드"; curl -sSL -o .venv/plantuml.jar "$JAR_URL"; }
command -v java >/dev/null 2>&1 || echo "[doc-viewer] 경고: java가 없어 PlantUML 다이어그램은 그려지지 않는다."

echo "[doc-viewer] http://127.0.0.1:8001  (종료: Ctrl+C)"
exec "$PY" -m mkdocs serve -a 127.0.0.1:8001
