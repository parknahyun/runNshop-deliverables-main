@echo off
rem Doc viewer (Windows) -> http://127.0.0.1:8001
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
