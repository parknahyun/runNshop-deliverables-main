---
inclusion: manual
---
# Steering 파일 가이드 (runNshop-implement-vue-java)

이 레포는 `runNshop-deliverables`를 git submodule로 `docs/`에 연결해 공통(표준) 규칙을 참조한다.

## Steering 파일 목록

| 파일 | 분류 | 비고 |
|------|------|------|
| work-scope.md | 공통(stub) | 원본: `docs/.kiro/steering/work-scope.md` |
| api-design-rules.md | 공통(stub) | 원본: `docs/.kiro/steering/api-design-rules.md` |
| mock-data-rules.md | 공통(stub) | 원본: `docs/.kiro/steering/mock-data-rules.md` |
| coding-standards.md | 공통(stub) | 원본: `docs/.kiro/steering/coding-standards.md` |
| screen-definition.md | 공통(stub) | 원본: `docs/.kiro/steering/screen-definition.md` |
| admin-ux-pattern.md | 공통(stub) | 원본: `docs/.kiro/steering/admin-ux-pattern.md` (React+Vue 공통 패턴 중 Vue만 적용) |
| java-guide.md | 언어별(Java) | 이 레포 고유 |
| vue-guide.md | 언어별(Vue) | 이 레포 고유, admin-vue에만 적용(mobile-vue는 별도 Nuxt 가이드) |

## 관련 Skill (`.kiro/skills/`)

| Skill | 분류 | 비고 |
|---|---|---|
| design-doc-to-code | 공통(stub) | 원본: `docs/.kiro/skills/design-doc-to-code/SKILL.md` |
| backend-service-pattern | 공통(stub) | 원본: `docs/.kiro/skills/backend-service-pattern/SKILL.md` (Java로 적용) |
| screen-to-vue-code | 언어별(Vue) | 이 레포 고유, design-doc-to-code의 절차 5 이후를 담당 |
