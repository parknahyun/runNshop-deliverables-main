---
inclusion: fileMatch
fileMatchPattern: "**/runNshop-admin-vue/**/*.vue,**/runNshop-admin-vue/**/*.ts"
---
# Vue 개발 가이드

> **적용 대상: `apps/runNshop-admin-vue`만.** mobile-vue(Nuxt 4)는 이 가이드를 쓰지 않는다
> (`doc/S4-구현/공통/프레임워크/mobile-vue/결정사항.md` "mobile용 Vue 가이드").

> Next.js 구현(`runNshop-react-kotlin`)의 `nextjs-guide.md`에 대응하는 언어별 가이드.
> 데이터 흐름 원칙(필터→API 호출→state 갱신→서버 응답 그대로 렌더)은 공통 skill
> `design-doc-to-code`를 그대로 따른다 — 이 파일은 Vue 문법/구조 차이만 다룬다.

## 기술 스택
- Vue 3.5 (Composition API) + Vite 8 + TypeScript 6 — SPA. 결정 근거는
  `doc/S4-구현/공통/프레임워크/admin-vue/결정사항.md`
- 라우터 없음: 화면 전환은 MDI 탭 상태(Pinia `useTabsStore`)로만 한다. 주소는 항상 `/`
- 상태관리: Pinia
- 자동 import: `ref`·`computed` 같은 Vue·Pinia 함수, `src/stores`의 스토어, `src/components`의
  컴포넌트는 import 없이 쓴다(mobile과 같은 방식). 컴포넌트 이름은 폴더 이름이 앞에 붙는다
  (`components/common/ComingSoon.vue` → `<CommonComingSoon>`)
- 스타일: 표준 CSS(BEM), 색·크기는 `src/assets/css/tokens.css`의 변수(`var(--…)`)만 쓴다.
  공통 스타일은 `src/assets/css/`(전역), 한 화면 전용은 그 화면의 `<style scoped>`. Tailwind·SCSS 쓰지 않음
- API 호출: `/api/...` 상대 경로. 개발 서버가 백엔드(8080)로 프록시한다

## 현재 구조 (admin-vue)
```
src/
├── main.ts / App.vue  ← 셸: NavBar + TabBar + TabContent (MDI) — admin-ux-pattern.md(공통) Shell 구조
├── assets/css/        ← tokens(:root 변수) → base → layout(셸·공통 BEM)
├── components/
│   ├── layout/        ← AppNavBar(1depth + 2depth 드롭다운), AppTabBar, AppTabContent
│   └── common/        ← ComingSoon(준비 중)
├── config/
│   ├── menus.ts       ← DE admin 메뉴 정의(메뉴 ID·위치·화면 ID·도메인)
│   └── screens.ts     ← 메뉴 ID → 화면 컴포넌트. 등록 안 된 메뉴는 "준비 중"
└── stores/tabs.ts     ← 열린 탭·활성 탭(최대 8개, 대시보드 고정)
```

## React → Vue 대응 패턴
| React(Next.js) | Vue 3 |
|---|---|
| `useState`/`useEffect` | `ref`/`reactive` + `onMounted`/`watch` (Composition API) |
| JSX | `<template>` (SFC) |
| Server Component (기본) | 없음 — SPA라 전부 클라이언트 컴포넌트, 최초 로딩 시 API 호출 |
| `lib/api.ts`의 `api<T>()` fetch 함수 | 동일 패턴 그대로 포팅 가능(순수 TS라 프레임워크 무관 — `design-doc-to-code` skill의 "프레임워크 독립성" 참고) |
| Props | `defineProps<T>()` |
| 라우팅(App Router 디렉토리) | 없음 — 메뉴 ID를 `config/screens.ts`에 등록하고 `useTabsStore().open(메뉴 ID)`로 탭을 연다 |

## 화면 유형/파일 구조
화면 유형(Dashboard/Table/Detail Modal), Shell 구조, spec.md 규칙은
`docs/.kiro/steering/admin-ux-pattern.md`(공통, submodule)를 그대로 따른다. 파일 구조는:
```
src/{domain}/{screen-name}/
  {ScreenName}.vue          ← 현황 화면
  {ScreenName}Detail.vue    ← 상세 모달
  types.ts                  ← 타입 + 상태→라벨 매핑 (React 쪽 types.ts와 동일 역할)
  tabs/
```
만든 화면은 `config/screens.ts`에 메뉴 ID(`config/menus.ts`)로 등록한다.

## 컴포넌트 작성 규칙
- 데이터는 전부 API 호출 모듈을 통해 fetch (하드코딩 금지) — `design-doc-to-code`
  skill의 데이터 흐름 원칙을 그대로 따른다. API 호출 모듈은 첫 화면 구현 때 `src/lib/api.ts`로 만든다.
- `<script setup lang="ts">` 사용, Composition API로 통일(Options API 혼용하지 않음)
- 공통 BEM 클래스는 `C7-admin-변경안`(`doc/S4-구현/공통/표준-변경안/`) 2장을 따른다
