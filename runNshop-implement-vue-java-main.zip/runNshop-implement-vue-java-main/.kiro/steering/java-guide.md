---
inclusion: fileMatch
fileMatchPattern: "**/*.java"
---
# Java 개발 가이드

> Kotlin 구현(`runNshop-react-kotlin`)의 `kotlin-guide.md`를 Java로 포팅한 언어별 가이드.
> 패키지 구조·레이어 경계·DataSource 이원화 등 아키텍처 규칙은 동일하다(공통 skill
> `backend-service-pattern` 참조) — 이 파일은 Java 문법 차이만 다룬다.

## 기술 스택
- Java 25 (LTS) + Spring Boot 4.1.1
- Gradle 9.7.1 (Kotlin DSL 빌드스크립트, 애플리케이션 코드는 Java)
- Lombok (보일러플레이트 제거 — `@Getter`/`@Builder`/`@RequiredArgsConstructor` 등)

## 패키지 구조 — MyBatis 전용 (Kotlin과 다름)
> 이 레포는 JPA를 쓰지 않고 **MyBatis만** 쓴다(master/slave 모두). 공통 skill `backend-service-pattern`의
> "JPA(master)/MyBatis(slave)" 규칙 대신 아래를 따른다. 결정 근거: `doc/S4-구현/공통/프레임워크/api-java/결정사항.md`.

```
com.runnshop.{domain}/
├── controller/     ← REST Controller (URL path로 앱 구분)
├── service/        ← 비즈니스 로직. @Transactional은 master에만 걸린다
├── dto/            ← 요청/응답 DTO, Mapper Row DTO (record 권장)
├── mapper/
│   ├── master/     ← runnshop_rw — 저장·수정·삭제, 최신값이 필요한 조회
│   └── slave/      ← runnshop_ro(읽기 전용) — 목록·건수·집계 조회
└── port/           ← 타 도메인 호출 계약 인터페이스

resources/mapper/{master|slave}/{domain}/{MapperName}.xml   ← SQL (namespace로 인터페이스 연결, @Mapper 불필요)
```
- Mapper가 어느 DB에 붙을지는 **패키지 위치로만** 정해진다(`common/config/DataSourceConfig`).
  빈 이름이 전체 클래스명이라 master/slave에 같은 이름(`OrderMapper`)을 둬도 된다. 예시: `order/` (admin 주문 목록).
- 쓰기 직후 다시 읽어야 하는 조회는 master Mapper에 둔다(slave로 읽지 않는다).
- 컬럼 snake_case → 필드 camelCase 자동 매핑. 페이징은 SQL에서 `LIMIT`/`OFFSET`.

## Kotlin → Java 문법 치환 가이드
| Kotlin | Java |
|---|---|
| `data class Foo(val a: String)` | `record Foo(String a) {}` 또는 Lombok `@Value class Foo { String a; }` |
| `val`/`var` | `final` 지역변수 / 일반 필드 |
| 생성자 주입(`class X(private val y: Y)`) | Lombok `@RequiredArgsConstructor` + `private final Y y;` |
| `require(cond) { "msg" }` | `if (!cond) throw new BadRequestException("msg");` |
| null-safety(`?`, `?:`) | `Optional<T>` 또는 명시적 null 체크 (`@Nullable`/`@NonNull` 애노테이션 권장) |
| 확장 함수 | 정적 유틸 메서드(`XxxUtils.foo(x)`) |

## ObjectMapper — Jackson 3 네임스페이스 주의
Spring Boot 4.x는 Jackson 3를 쓴다. import는 `tools.jackson.databind.ObjectMapper`(구 Jackson2의
`com.fasterxml.jackson.databind`가 아니다) — `common/MockLoader.java` 참고.

## 공용 인프라 — DataSource 이원화, 12개 업무도메인, Controller/Service 분리 기준
Kotlin 구현과 완전히 동일한 규칙이다. `docs/.kiro/skills/backend-service-pattern/SKILL.md`(공통)와
`docs/.kiro/steering/api-design-rules.md`(공통)의 "Controller/Service 분리 단위" 절을 그대로 따른다
— 이 구현에서 처음 시도하는 도메인이라도 Kotlin 쪽에서 이미 결정된 서브도메인 구조
(`DP-클래스설계/{domain}.md`)가 있으면 그 결정을 그대로 재사용한다(새로 판단하지 않음).

## 프로토타입 단계 Controller 패턴
```java
@RestController
@RequestMapping("/api/mobile/v1/products")
@RequiredArgsConstructor
public class CustomerProductController {

    private final MockLoader mockLoader;

    /** 상품 상세 조회 (DL §x) */
    @GetMapping("/{productId}")
    public ResponseEntity<Object> getProduct(@PathVariable Long productId) {
        var data = mockLoader.load("catalog", "mobile__GET_products_{product_id}.json");
        return ResponseEntity.ok(data);
    }
}
```

## 코멘트 규칙
Kotlin의 KDoc 규칙과 동일하게 Javadoc(`/** ... */`)을 모든 Controller/Service 메서드에 작성한다.
섹션 구분 주석(`// ── ... ──`)으로 채널(mobile/admin/partner)별 메서드를 묶는 규칙도 동일하다.
