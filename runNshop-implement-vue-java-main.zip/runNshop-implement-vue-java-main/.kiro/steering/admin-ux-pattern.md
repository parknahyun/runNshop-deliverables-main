---
inclusion: fileMatch
fileMatchPattern: "**/runNshop-admin-vue/**/*.vue,**/runNshop-admin-vue/**/*.ts"
---
# 어드민 화면 UX 패턴 (공통 — docs 허브 참조)

> 이 파일은 stub이다. 원본은 `runNshop-deliverables`(git submodule, `docs/`)에 있다. (원본은 React+Vue
> 공통 패턴을 다루지만, 이 레포엔 Vue 쪽만 적용된다.)

#[[file:docs/.kiro/steering/admin-ux-pattern.md]]
