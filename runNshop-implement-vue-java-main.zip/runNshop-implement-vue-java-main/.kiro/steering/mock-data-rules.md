---
inclusion: always
---
# Mock 데이터 규칙 (공통 — docs 허브 참조)

> 이 파일은 stub이다. 원본은 `runNshop-deliverables`(git submodule, `docs/`)에 있다. 이 레포의 실제 mock
> 루트는 `api/runNshop-api-java/src/main/resources/mock/`이다.

#[[file:docs/.kiro/steering/mock-data-rules.md]]
