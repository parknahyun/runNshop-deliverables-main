---
inclusion: always
---
# 코딩 표준 (공통 — docs 허브 참조)

> 이 파일은 stub이다. 원본은 `runNshop-deliverables`(git submodule, `docs/`)에 있다.

#[[file:docs/.kiro/steering/coding-standards.md]]
