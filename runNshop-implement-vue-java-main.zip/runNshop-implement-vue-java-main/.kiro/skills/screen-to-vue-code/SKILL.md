---
name: screen-to-vue-code
description: DN-화면레이아웃 설계 문서를 읽고 runNshop admin Vue 3 코드로 변환한다. 화면 구현, 화면 코드 생성, 또는 기존 화면의 하드코딩된 mock 데이터를 백엔드 API 연동 구조로 전환할 때 사용. 문서 파싱·네이밍·API확인 등 프레임워크 공통 절차는 design-doc-to-code skill을 먼저 따른다.
---

> **분류: 언어/프레임워크별(Vue 3)** — 절차 1~4(문서 파싱, camelCase 네이밍, 화면 유형 판별,
> API/Mock 확인)는 `docs/.kiro/skills/design-doc-to-code/SKILL.md`(공통, submodule)를 그대로
> 따른다. 이 skill은 그 이후 **Vue 3 전용 파일 생성·구현**만 다룬다. React 포트(`runNshop-react-kotlin`
> 레포의 `screen-to-fe-code`)와 절차 1~4를 공유하고 절차 5 이후만 다르다.

# 화면설계 → Vue 3 코드 변환

## 선행 절차
`design-doc-to-code`(공통) skill의 절차 1~4를 먼저 수행한다. 화면 유형 판별은
`.kiro/steering/admin-ux-pattern.md`(공통) 기준, Vue 파일 구조/문법은 `.kiro/steering/vue-guide.md`
(이 레포 전용) 기준.

## 절차 5 — Vue 파일 생성/수정
```
src/{domain}/{screen-name}/
  {ScreenName}.vue          ← 현황 화면 (<script setup lang="ts">)
  {ScreenName}Detail.vue    ← 상세 모달/탭
  types.ts                  ← 타입 + 상태→라벨 매핑
  tabs/
```
- 데이터는 `lib/api.ts`(React 쪽과 동일한 순수 fetch 함수, 포팅 가능)를 통해서만 가져온다
- 필터/페이지/페이지크기 변경 시마다 서버 재요청(클라이언트 재가공 금지) — `design-doc-to-code`
  데이터 흐름 원칙 그대로
- Composition API(`ref`/`reactive`/`onMounted`/`watch`)로 상태 관리, Options API 금지
- 목록→상세 이동 시 ID만 라우트 파라미터(또는 props)로 전달, 상세는 자체적으로 API 재호출

## 절차 6 — 검증
```bash
cd api/runNshop-api-java && ./gradlew build -x test   # API 변경 시
cd apps/runNshop-admin-vue && npm run build            # vue-tsc + vite build
```

## 참고 steering/skill
- `design-doc-to-code`(공통, submodule) — 이 skill의 전제
- `.kiro/steering/admin-ux-pattern.md`(공통, submodule) — 화면 유형/Shell구조
- `.kiro/steering/vue-guide.md` — Vue 문법/파일구조
- `.kiro/steering/java-guide.md` — 백엔드 Controller/Service 패키지 구조
- `backend-service-pattern`(공통, submodule) — 레이어 경계
