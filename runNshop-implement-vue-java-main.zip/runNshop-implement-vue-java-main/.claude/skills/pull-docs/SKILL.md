---
name: pull-docs
description: runNshop-implement-vue-java 저장소를 pull하고 docs 서브모듈(runNshop-deliverables)을 팀 공유 버전으로 맞춘 뒤, 더 새로운 docs 최신 버전이 있는지 확인해 받을지 물어본다. 사용자가 원하면 docs 최신 버전을 팀 공유 버전으로 올린다(포인터 갱신 커밋+push). 사용자가 "pull 받아줘", "최신으로 받아줘", "docs 동기화", "서브모듈 업데이트", "docs 팀 공유 버전 올려줘"를 요청하거나 /pull-docs를 입력했을 때 사용.
---

# pull-docs — 메인 저장소 + docs 동기화

## 용어

이 저장소(runNshop-implement-vue-java)는 `docs/` 폴더에 runNshop-deliverables 저장소를 서브모듈로 연결해 두었다. 사용자에게 설명할 때는 아래 두 용어만 쓴다. "포인터", "메인 저장소가 지정한 버전" 같은 표현은 꼭 필요할 때만 덧붙인다.

- **팀 공유 버전**: runNshop-implement-vue-java에 커밋돼서 팀원 모두가 똑같이 쓰는 docs 버전. `git ls-tree HEAD docs`로 확인한다.
- **docs 최신 버전**: runNshop-deliverables의 `origin/main`에 push된 가장 새로운 버전. 팀 공유 버전보다 앞서 있을 수 있다.

`git pull`만 하면 팀 공유 버전 정보만 바뀌고 `docs/` 폴더 내용은 그대로 남는다. 그래서 이 스킬은 pull 뒤에 docs까지 맞춘다.

모든 명령은 저장소 루트에서 실행한다. 사용자에게 보고할 때는 한국어로, git을 잘 모르는 사람도 이해할 수 있게 쉽게 설명한다.

## 실패 시 규칙 (가장 중요)

어느 단계든 명령이 실패하거나 예상과 다른 상태가 나오면 **즉시 멈춘다. 스스로 고치지 않는다.**
충돌, 인증 오류, 로컬 변경 때문에 막힌 경우, 거부된 push, 네트워크 오류 등이 모두 해당한다.

1. 실패한 명령과 오류 메시지를 그대로 보여 준다.
2. 원인을 쉬운 말로 설명한다.
3. 해결 계획을 제시한다. 실행할 명령을 순서대로 적고, 각 명령이 무엇을 바꾸는지와 되돌릴 수 있는지를 함께 적는다. 방법이 여러 개면 추천안을 먼저 적고 나머지를 나열한다.
4. **사용자가 승인할 때까지 아무 명령도 실행하지 않는다.** 상태를 조회하는 명령(`git status`, `git log`, `git diff`, `git fetch` 등)으로 원인을 파악하는 것만 허용한다.
5. 승인을 받으면 승인된 계획만 실행한다. 실행 중에 계획과 다른 상황이 생기면 다시 1번부터 반복한다.

## 절차

### 1. 사전 확인

```bash
git status --short
git -C docs status --short
git submodule status
```

- 메인 저장소에 커밋하지 않은 변경이 있으면 목록을 보여 준다. pull이 충돌할 수 있다고 알리고, 계속할지 묻는다.
- `docs/` 안에 수정된 파일이 있으면 동기화하면서 덮어쓰거나 실패할 수 있다. 목록을 보여 주고 계속할지 묻는다.
- `git submodule status`에서 앞에 `-`가 붙어 있으면 아직 초기화되지 않은 상태다. 2단계의 `--init`이 처리하니 그대로 진행한다.

이전 docs 커밋을 기록해 둔다(마지막 보고에 쓴다).

```bash
git -C docs rev-parse --short HEAD 2>/dev/null
```

### 2. pull 후 팀 공유 버전으로 맞추기

```bash
git pull
```

**docs 연결 주소 확인.** 레포 이름이 바뀌면 `.gitmodules`의 URL은 pull로 갱신되지만,
내 PC에 저장된 URL은 그대로 남는다. 그래서 submodule update 전에 세 값을 비교한다.

```bash
git config -f .gitmodules --get submodule.docs.url   # 팀이 정한 URL (커밋된 값)
git config --get submodule.docs.url                  # 내 PC에 저장된 URL
git -C docs remote get-url origin                    # docs 폴더가 실제로 연결된 URL
```

- 셋이 모두 같으면 그대로 진행한다.
- 아래 두 값이 비어 있으면(아직 서브모듈 초기화 전) 그대로 진행한다. 다음 `--init`이 `.gitmodules` 값을 쓴다.
- 값이 다르면 묻지 않고 바로 맞춘다. 이 명령은 내 PC의 git 설정에 적힌 주소만 바꾸고,
  파일과 커밋은 건드리지 않는다. 바뀌기 전 URL과 바뀐 후 URL은 5단계 보고에 쓰도록 기록해 둔다.

  ```bash
  git submodule sync --recursive
  ```

```bash
git submodule update --init --recursive
```

실패하면 **실패 시 규칙**을 따른다. 다음 단계로 넘어가지 않는다.

### 3. docs 최신 버전 확인 (받지는 않음)

```bash
git -C docs fetch origin
git -C docs log --oneline HEAD..origin/main
```

- **결과가 비어 있으면**: 팀 공유 버전이 곧 최신이다. 5단계(보고)로 간다.
- **커밋이 있으면**: 먼저 폴더 이동·이름 변경이 있는지 확인한다. 아래 명령은 옮겨진 파일마다 옛 경로와 새 경로의 같은 뒷부분을 빼고, 바뀐 폴더만 묶어서 보여 준다(예: `162 docs/ -> (루트)/`).

  ```bash
  git -C docs -c core.quotepath=false diff --name-status -M HEAD origin/main \
    | awk -F'\t' '/^R/{n=split($2,a,"/"); m=split($3,b,"/");
        while(n>0 && m>0 && a[n]==b[m]){n--; m--}
        o=""; for(i=1;i<=n;i++) o=o a[i] "/"; w=""; for(i=1;i<=m;i++) w=w b[i] "/";
        if(o=="") o="(루트)/"; if(w=="") w="(루트)/"; print o " -> " w}' \
    | sort | uniq -c | sort -rn
  ```

  결과가 비어 있으면 폴더 이동이 없는 것이다.

  그다음 받을지 묻는다(AskUserQuestion 사용).
  - "팀 공유 버전보다 새 커밋이 N개 있어요" + 커밋 목록
  - 폴더 이동이 있으면 옮겨진 폴더(`옛 경로 -> 새 경로`)를 적고, "이 레포에서 그 경로를 쓰는 곳(링크·문서 뷰어 등)이 깨질 수 있다"고 알린다.
  - 선택지: **받지 않음 (팀 공유 버전 유지)** / **docs 최신 버전 받기**
  - 받으면 내 PC의 docs만 팀과 다른 버전이 된다는 점을 설명에 적는다.

### 4. docs 최신 버전 받기 (사용자가 선택한 경우만)

```bash
git submodule update --init --recursive --remote
git status --short
```

`git status`에 `docs`가 변경됨으로 표시되는 건 정상이다. 내 docs는 최신이지만 팀 공유 버전은 아직 옛날이라서 그렇다.

**깨지는 경로 찾기.** 3단계에서 폴더 이동이 있었으면, 이 레포(`docs/` 밖)에서 옛 경로를 쓰는 곳을 찾는다.

```bash
git grep -n -e "docs/<옛 경로>" -- . ':!docs'   # 옮겨진 옛 경로마다 실행
git ls-files -s | grep '^120000'                # docs를 가리키는 symlink (예: doc/deliverables)
```

- symlink는 가리키는 경로(`git cat-file -p HEAD:<경로>`)가 지금 docs에 있는지 확인한다.
- 찾은 곳을 `파일:행 / 지금 경로 / 새 경로` 표로 보여 준다. 날짜가 있는 작업이력처럼 당시 경로를 기록한 문서는 "기록이라 유지"로 따로 표시한다.
- 고치는 건 사용자가 승인한 뒤에만 한다. `docs/` 안은 고치지 않는다.

이어서 **팀 공유 버전으로 올릴지** 묻는다(AskUserQuestion 사용).
- 선택지: **나만 쓰기 (올리지 않음)** / **팀 공유 버전으로 올리기** / **팀 공유 버전으로 되돌리기**
- "나만 쓰기"를 고르면, 다른 커밋을 할 때 `docs`가 실수로 섞이지 않게 조심하라고 안내한다(`git add .` 대신 파일을 지정해서 add).
- "팀 공유 버전으로 올리기"를 고르면 6단계로 간다.
- "팀 공유 버전으로 되돌리기"를 고르면 4-1로 간다.

### 4-1. 팀 공유 버전으로 되돌리기 (사용자가 선택한 경우만)

```bash
git submodule update --init --recursive
git -C docs status --short
```

- docs가 팀 공유 버전으로 돌아간다. 다시 최신으로 받는 것도 언제든 가능하다.
- 최신 버전에만 있던 하위 저장소(예: `reference/.ai-methodology`)는 git이 내용이 있는 폴더를 지우지 않아서 `??`로 남는다. 쓰이지 않는 폴더라 동작에는 문제가 없다고 설명한다.
- 남은 폴더 목록을 보여 주고 지울지 묻는다. 사용자가 승인한 폴더만 지운다.

### 5. 결과 보고

**문서 뷰어 재시작.** 이번 실행에서 docs 버전이 바뀌었으면(2·4·4-1단계), 8001 문서 뷰어가 켜져 있는지 확인한다.
켜져 있던 뷰어는 docs가 바뀐 뒤 응답하지 않을 수 있어서, 켜져 있으면 묻지 않고 재시작한다.

```powershell
# 대상: mkdocs serve 127.0.0.1:8001 프로세스만. 다른 프로그램은 건드리지 않는다.
Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*mkdocs*serve*127.0.0.1:8001*' } |
  Select-Object ProcessId, ParentProcessId, CreationDate
```

1. 찾은 프로세스를 모두 끈다(`taskkill /PID <id> /T /F`). Windows는 같은 포트에 서버가 여러 개 붙을 수 있어서, 옛 서버가 하나라도 남으면 요청이 그쪽으로 간다.
2. `Get-NetTCPConnection -LocalPort 8001 -State Listen`이 비었는지 확인한다.
3. `/doc-viewer` 스킬의 "띄우기" 절차로 다시 띄우고 `200` 응답을 확인한다.
4. 켜져 있지 않았으면 아무것도 하지 않는다.

```bash
git -C docs rev-parse --short HEAD
git -C docs log --oneline -5
git status --short
```

사용자에게 다음을 짧게 보고한다.

1. 메인 저장소가 업데이트됐는지(새 커밋 몇 개, 이미 최신인지)
2. docs 버전 변화: `이전 커밋 → 새 커밋`, 바뀌지 않았다면 "docs는 변화 없음"
3. 지금 docs가 **팀 공유 버전**인지 **docs 최신 버전(팀과 다름)**인지
4. docs가 바뀌었다면 최근 docs 커밋 메시지 몇 개
5. 2단계에서 docs 연결 주소를 맞췄다면 "docs 연결 주소가 `<이전 URL>` → `<새 URL>`로 바뀌어서 맞췄어요"
6. 문서 뷰어를 재시작했다면 그 사실과 주소(http://127.0.0.1:8001)

### 6. 팀 공유 버전 올리기

사용자가 4단계에서 고른 경우, 또는 "docs 팀 공유 버전 올려줘"처럼 직접 요청한 경우에만 실행한다.

**6-1. 확인**

```bash
git status --short
git diff --cached --name-only
git submodule summary
```

- 이미 스테이징된 다른 파일이 있으면 멈추고 보여 준다. 이 커밋에는 `docs`만 들어가야 한다.
- 직접 요청받아 4단계를 거치지 않았다면, 먼저 2~4단계(pull → 최신 확인 → 최신 받기)를 진행한다.
- `git submodule summary`로 팀 공유 버전 대비 어떤 docs 커밋이 추가되는지 보여 준다.
- 4단계에서 깨지는 경로를 찾았으면, 그 경로를 먼저 고친다(사용자 승인 후). 그다음 **docs 버전 커밋과 경로 수정 커밋을 함께 푸시**한다. docs 버전만 먼저 푸시하면 경로를 고치기 전까지 원격 main이 깨진 상태가 되고, 그 사이에 pull한 팀원도 깨진 상태를 받는다. 사용자가 경로 수정 없이 올리려 하면 이 점을 경고하고 다시 확인한다.

**6-2. 커밋 메시지 확인**

커밋 메시지 초안을 보여 주고 승인을 받는다. 제목에는 docs의 이전 해시와 새 해시(짧은 7자리)를, 본문에는 추가되는 docs 커밋 목록을 넣는다.

해시와 목록은 아래 명령으로 구한다.

```bash
git ls-tree HEAD docs | awk '{print substr($3,1,7)}'   # 이전 해시 (현재 팀 공유 버전)
git -C docs rev-parse --short=7 HEAD                    # 새 해시
git -C docs log --oneline <이전 해시>..HEAD               # 추가되는 docs 커밋 목록
```

형식:

```
chore(docs): submodule 포인터 갱신 <이전 해시> → <새 해시> — <변경 요약>

runNshop-deliverables 추가 커밋:
- <해시> <커밋 메시지>
- <해시> <커밋 메시지>
```

예시:

```
chore(docs): submodule 포인터 갱신 eff31a1 → 8a4f523 — methodology 분리, archive 폐기

runNshop-deliverables 추가 커밋:
- 8a4f523 chore: .DS_Store 추적 제거 + .gitignore 추가
- 8492696 deliverables/methodology 분리 완료 — methodology 경로 제거 + README 갱신
- 93bb5e5 deliverables/methodology 분리 준비: docs/archive 폐기, onboarding.md 현행화
```

본문이 여러 줄이므로 커밋할 때 `-m`을 두 번 쓰거나 heredoc을 사용한다.

**6-3. 커밋과 push**

```bash
git add docs
git commit -m "<승인받은 메시지>"
# 경로 수정 커밋이 있으면 여기서 함께 커밋한다(수정한 파일만 지정해서 add)
git push
```

push가 거부되면(다른 사람이 먼저 push한 경우 등) **실패 시 규칙**을 따른다. 임의로 pull, rebase, force push 하지 않는다.

**6-4. 보고**

push가 끝나면 팀원은 `/pull-docs`(또는 `git pull` + `git submodule update --init --recursive`)로 같은 docs 버전을 받을 수 있다고 안내한다.

## 하지 말 것

- 실패 상황에서 계획 설명과 사용자 승인 없이 해결을 시도하지 않는다(재시도, 충돌 해결, 파일 수정 모두 포함).
- 사용자 확인 없이 `git reset --hard`, `git stash`, `git checkout -- .`, `git clean`처럼 로컬 변경을 지우는 명령을 실행하지 않는다.
- 사용자가 고르지 않았는데 docs 최신 버전을 받거나 팀 공유 버전을 올리지 않는다.
- force push 하지 않는다.
- `docs/` 안에서 파일을 수정하거나 runNshop-deliverables에 직접 commit, push 하지 않는다(이 스킬은 동기화만 한다).
