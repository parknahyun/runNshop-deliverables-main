// @ts-check
// Nuxt 권장 규칙(@nuxt/eslint) + Prettier와 겹치는 서식 규칙 끄기
import withNuxt from './.nuxt/eslint.config.mjs'
import prettier from 'eslint-config-prettier'

export default withNuxt(prettier)
