# runNshop-mobile-vue

runNshop 고객웹(mobile). Nuxt 4 + Vue 3 + TypeScript, SSR.

- 결정사항: `doc/S4-구현/공통/프레임워크/mobile-vue/결정사항.md`
- 디자인 토큰·레이아웃: `doc/S4-구현/공통/표준-변경안/C7-mobile-변경안.md` (PM 승인 전까지 허브 C7 mobile보다 우선)
- 화면 경로: 허브 DE-메뉴구조도 mobile

## 실행

Node `^22.22.3 || ^24.15.0 || >=26.0.0` 필요.

```bash
npm install
npm run dev        # http://localhost:3000
```

| 명령                                | 하는 일                    |
| ----------------------------------- | -------------------------- |
| `npm run dev`                       | 개발 서버 (포트 3000)      |
| `npm run build` / `npm run preview` | 운영 빌드 / 빌드 결과 실행 |
| `npm run lint` / `npm run lint:fix` | ESLint 검사 / 자동 수정    |
| `npm run format`                    | Prettier로 서식 맞춤       |

- `/api/**` 요청은 백엔드(`http://localhost:8080`)로 프록시된다(`nuxt.config.ts` `routeRules`). 백엔드가 꺼져 있으면 502.

## 폴더 구조

```
app/
├── app.vue
├── assets/css/        ← 전역 CSS: tokens(:root 변수) → base → layout(셸·공통 컴포넌트)
├── layouts/default.vue← Header + Content + BottomNav
├── components/        ← 자동 import, 폴더 이름이 앞에 붙음 (layout/AppHeader.vue → <LayoutAppHeader>)
│   ├── layout/        ← AppHeader, AppBottomNav
│   └── common/        ← ComingSoon(준비 중 표시)
└── pages/             ← 파일 기반 라우팅. 현재 17개 경로 모두 "준비 중"
```

## 스타일 규칙

- 표준 CSS만 쓴다(SCSS·Tailwind 없음). 클래스 이름은 BEM(`.block__element--modifier`).
- 색·크기·간격은 값을 직접 쓰지 않고 `var(--color-primary)`처럼 `tokens.css` 변수로 쓴다.
- 여러 화면에서 쓰는 공통 스타일은 `assets/css/`(전역), 한 화면에서만 쓰는 스타일은 그 화면의 `<style scoped>`.
