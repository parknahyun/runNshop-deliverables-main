// runNshop 고객웹(mobile) — 결정사항: doc/S4-구현/공통/프레임워크/mobile-vue/결정사항.md
export default defineNuxtConfig({
  compatibilityDate: '2026-11-01',
  devtools: { enabled: true },

  modules: ['@pinia/nuxt', '@nuxt/eslint'],

  // 전역 CSS: 토큰(:root 변수)·기본 스타일·공통 컴포넌트. 화면 전용 스타일은 각 화면의 <style scoped>
  css: ['~/assets/css/main.css'],

  app: {
    head: {
      htmlAttrs: { lang: 'ko' },
      title: 'runNshop',
      meta: [{ name: 'viewport', content: 'width=device-width, initial-scale=1' }],
    },
  },

  devServer: { port: 3000 },

  // 백엔드(api-java, 8080)로 프록시 — 같은 출처로 호출하므로 백엔드 CORS 설정이 필요 없다
  routeRules: {
    '/api/**': { proxy: 'http://localhost:8080/api/**' },
  },
})
