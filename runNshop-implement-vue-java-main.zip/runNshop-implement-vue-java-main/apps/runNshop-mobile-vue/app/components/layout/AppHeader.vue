<!-- 공통 Header. 스타일은 assets/css/layout.css (.app-header) -->
<template>
  <header class="app-header">
    <NuxtLink to="/" class="app-header__logo">runNshop</NuxtLink>
    <NuxtLink to="/cart" class="app-header__action">장바구니</NuxtLink>
  </header>
</template>
