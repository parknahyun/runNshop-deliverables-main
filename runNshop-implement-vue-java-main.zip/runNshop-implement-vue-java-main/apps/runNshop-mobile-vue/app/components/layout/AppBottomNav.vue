<!--
  공통 BottomNav. 항목은 DN 화면레이아웃 기준 홈/기획전/검색/MY (결정사항 "BottomNav 항목").
  기획전은 DE 메뉴구조도에 경로가 없어 탭만 두고 "준비 중"으로 표시한다.
  스타일은 assets/css/layout.css (.bottom-nav)
-->
<script setup lang="ts">
interface NavItem {
  label: string
  to: string | null
  /** 이 경로로 시작하면 활성 표시 (홈은 정확히 일치할 때만) */
  match?: string
}

const items: NavItem[] = [
  { label: '홈', to: '/' },
  { label: '기획전', to: null },
  { label: '검색', to: '/search', match: '/search' },
  { label: 'MY', to: '/my', match: '/my' },
]

const route = useRoute()

function isActive(item: NavItem): boolean {
  if (item.to === '/') return route.path === '/'
  return !!item.match && (route.path === item.match || route.path.startsWith(`${item.match}/`))
}
</script>

<template>
  <nav class="bottom-nav" aria-label="하단 메뉴">
    <template v-for="item in items" :key="item.label">
      <NuxtLink
        v-if="item.to"
        :to="item.to"
        class="bottom-nav__item"
        :class="{ 'bottom-nav__item--active': isActive(item) }"
      >
        {{ item.label }}
      </NuxtLink>
      <span v-else class="bottom-nav__item bottom-nav__item--disabled" aria-disabled="true">
        {{ item.label }}
        <span class="bottom-nav__note">준비 중</span>
      </span>
    </template>
  </nav>
</template>
