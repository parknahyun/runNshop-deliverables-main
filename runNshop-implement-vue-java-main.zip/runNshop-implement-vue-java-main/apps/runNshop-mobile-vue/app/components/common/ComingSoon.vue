<!--
  화면 구현 전 자리 표시. 위치(경로)·도메인은 DE 메뉴구조도(mobile), 화면 ID는 DN 화면레이아웃 기준.
  값이 없으면 '-'. 스타일은 assets/css/layout.css (.coming-soon)
-->
<script setup lang="ts">
const props = defineProps<{
  title: string
  domain: string
  screenId?: string
}>()

const route = useRoute()

useHead({ title: `${props.title} | runNshop` })
</script>

<template>
  <section class="coming-soon">
    <h1 class="coming-soon__title">{{ title }}</h1>
    <p class="coming-soon__status">준비 중</p>
    <ul class="coming-soon__meta">
      <li>위치: {{ route.path }}</li>
      <li>화면 ID: {{ screenId ?? '-' }}</li>
      <li>도메인: {{ domain }}</li>
    </ul>
  </section>
</template>
