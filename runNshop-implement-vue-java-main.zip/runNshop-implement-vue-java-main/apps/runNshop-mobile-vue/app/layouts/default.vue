<!-- L-MAIN: Header + Content + BottomNav (C7-mobile 변경안 3장). 스타일은 assets/css/layout.css -->
<template>
  <div class="layout">
    <LayoutAppHeader />
    <main class="layout__content">
      <slot />
    </main>
    <LayoutAppBottomNav />
  </div>
</template>
