<template>
  <CommonComingSoon title="쿠폰함" domain="Promotion" />
</template>
