<template>
  <CommonComingSoon title="내 리뷰" domain="Community" />
</template>
