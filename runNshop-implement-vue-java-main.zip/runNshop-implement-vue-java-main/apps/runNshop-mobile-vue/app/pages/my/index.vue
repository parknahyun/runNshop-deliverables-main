<template>
  <CommonComingSoon title="마이페이지" domain="Member" screen-id="SCR-M-005" />
</template>
