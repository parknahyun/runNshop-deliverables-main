<template>
  <CommonComingSoon title="포인트내역" domain="Member" />
</template>
