<template>
  <CommonComingSoon title="설정" domain="Member" />
</template>
