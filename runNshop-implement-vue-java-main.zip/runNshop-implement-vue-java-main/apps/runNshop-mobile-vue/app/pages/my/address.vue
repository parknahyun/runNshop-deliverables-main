<template>
  <CommonComingSoon title="배송지관리" domain="Member" />
</template>
