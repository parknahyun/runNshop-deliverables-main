<template>
  <CommonComingSoon title="결제수단관리" domain="Payment" />
</template>
