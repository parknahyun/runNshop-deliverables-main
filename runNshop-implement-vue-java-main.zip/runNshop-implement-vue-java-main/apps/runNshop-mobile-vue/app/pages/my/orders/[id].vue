<template>
  <CommonComingSoon title="주문상세" domain="Order" screen-id="SCR-M-007" />
</template>
