<template>
  <CommonComingSoon title="주문내역" domain="Order" screen-id="SCR-M-006" />
</template>
