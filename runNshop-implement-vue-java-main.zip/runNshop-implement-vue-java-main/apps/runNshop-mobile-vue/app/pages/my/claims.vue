<template>
  <CommonComingSoon title="클레임내역" domain="Order" screen-id="SCR-M-010" />
</template>
