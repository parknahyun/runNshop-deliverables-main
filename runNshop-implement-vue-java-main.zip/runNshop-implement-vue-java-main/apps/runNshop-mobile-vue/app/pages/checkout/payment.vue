<template>
  <CommonComingSoon title="결제 진행" domain="Payment" />
</template>
