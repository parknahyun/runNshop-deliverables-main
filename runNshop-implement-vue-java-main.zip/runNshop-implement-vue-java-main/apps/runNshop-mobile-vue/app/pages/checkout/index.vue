<template>
  <CommonComingSoon title="주문서" domain="Order" screen-id="SCR-M-002" />
</template>
