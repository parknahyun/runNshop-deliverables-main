<template>
  <CommonComingSoon title="홈" domain="Catalog(Display)" screen-id="SCR-M-C04" />
</template>
