<template>
  <CommonComingSoon title="상품상세" domain="Catalog" screen-id="SCR-M-C03" />
</template>
