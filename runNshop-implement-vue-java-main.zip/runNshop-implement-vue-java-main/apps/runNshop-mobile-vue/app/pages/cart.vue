<template>
  <CommonComingSoon title="장바구니" domain="Order" screen-id="SCR-M-001" />
</template>
