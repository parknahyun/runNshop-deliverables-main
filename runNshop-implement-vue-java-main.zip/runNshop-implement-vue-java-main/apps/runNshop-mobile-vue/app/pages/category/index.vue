<template>
  <CommonComingSoon title="카테고리 · 상품목록" domain="Catalog" screen-id="SCR-M-C01" />
</template>
