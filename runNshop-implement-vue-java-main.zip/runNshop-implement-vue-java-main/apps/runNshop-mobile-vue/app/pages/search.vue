<template>
  <CommonComingSoon title="검색결과" domain="Catalog" screen-id="SCR-M-C02" />
</template>
