# runNshop-admin-vue

runNshop 플랫폼 어드민. Vue 3 + Vite + TypeScript, SPA(라우터 없이 MDI 탭).

- 결정사항: `doc/S4-구현/공통/프레임워크/admin-vue/결정사항.md`
- 디자인 토큰·BEM 클래스: `doc/S4-구현/공통/표준-변경안/C7-admin-변경안.md` (PM 승인 전까지 허브 C7 admin보다 우선)
- 메뉴: 허브 DE-메뉴구조도 admin
- 작성 가이드: `.kiro/steering/vue-guide.md`

## 실행

Node `^22.22.3 || ^24.15.0 || >=26.0.0` 필요.

```bash
npm install
npm run dev        # http://localhost:3001
```

| 명령                                | 하는 일                                |
| ----------------------------------- | -------------------------------------- |
| `npm run dev`                       | 개발 서버 (포트 3001)                  |
| `npm run build` / `npm run preview` | 타입 검사 + 운영 빌드 / 빌드 결과 실행 |
| `npm run typecheck`                 | 타입 검사(vue-tsc)                     |
| `npm run lint` / `npm run lint:fix` | ESLint 검사 / 자동 수정                |
| `npm run format`                    | Prettier로 서식 맞춤                   |

- `/api/**` 요청은 개발 서버가 백엔드(기본 `http://localhost:8080`)로 프록시한다. 백엔드가 꺼져 있으면 502.
  대상을 바꾸려면 `.env.example`을 `.env.local`로 복사해 `API_PROXY_TARGET`을 수정한다.
- 운영 환경의 API 연결 방식(리버스 프록시 / CORS)은 아직 정하지 않았다(배포 구성 때 결정).
- `auto-imports.d.ts`, `components.d.ts`, `.eslintrc-auto-import.json`은 개발 서버·빌드 때 자동으로 다시 만들어진다. 커밋 대상이다.

## 폴더 구조

```
src/
├── main.ts / App.vue  ← 셸: NavBar + TabBar + TabContent
├── assets/css/        ← 전역 CSS: tokens(:root 변수) → base → layout(셸·공통 컴포넌트)
├── components/        ← 자동 import, 폴더 이름이 앞에 붙음 (layout/AppNavBar.vue → <LayoutAppNavBar>)
│   ├── layout/        ← AppNavBar, AppTabBar, AppTabContent
│   └── common/        ← ComingSoon(준비 중 표시)
├── config/
│   ├── menus.ts       ← 메뉴 정의 21개
│   └── screens.ts     ← 메뉴 ID → 화면 컴포넌트 (지금은 비어 있어 모두 "준비 중")
└── stores/tabs.ts     ← 탭 상태: 최대 8개, 대시보드 고정, 초과 시 안내
```

## 스타일 규칙

- 표준 CSS만 쓴다(SCSS·Tailwind 없음). 클래스 이름은 BEM(`.block__element--modifier`).
- 색·크기·간격은 값을 직접 쓰지 않고 `tokens.css` 변수로 쓴다.
- 여러 화면에서 쓰는 공통 스타일은 `assets/css/`(전역), 한 화면에서만 쓰는 스타일은 그 화면의 `<style scoped>`.
- 화면 폭: 1280px 이상 기준, 최소 1024px(더 좁으면 가로 스크롤).
