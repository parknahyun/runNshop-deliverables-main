// Vue 권장 규칙(eslint-plugin-vue) + TypeScript(typescript-eslint) + Prettier와 겹치는 서식 규칙 끄기 — mobile과 같은 규칙(#10)
import pluginVue from 'eslint-plugin-vue'
import { defineConfigWithVueTs, vueTsConfigs } from '@vue/eslint-config-typescript'
import prettier from 'eslint-config-prettier'
// 자동 import(#6)된 이름을 정의된 전역으로 인식 — vite 실행 시 자동 생성된다
import autoImport from './.eslintrc-auto-import.json' with { type: 'json' }

export default defineConfigWithVueTs(
  { ignores: ['dist/**', 'node_modules/**', 'auto-imports.d.ts', 'components.d.ts'] },
  pluginVue.configs['flat/recommended'],
  vueTsConfigs.recommended,
  { languageOptions: { globals: autoImport.globals } },
  prettier,
)
