// runNshop 플랫폼 어드민 — 결정사항: doc/S4-구현/공통/프레임워크/admin-vue/결정사항.md
import { fileURLToPath, URL } from 'node:url'
import { defineConfig, loadEnv } from 'vite'
import vue from '@vitejs/plugin-vue'
import AutoImport from 'unplugin-auto-import/vite'
import Components from 'unplugin-vue-components/vite'

export default defineConfig(({ mode }) => {
  // API_PROXY_TARGET: 각자 .env.local에서 덮어쓸 수 있다(클라이언트에 노출되지 않는 이름)
  const env = loadEnv(mode, process.cwd(), '')
  const apiTarget = env.API_PROXY_TARGET || 'http://localhost:8080'

  return {
    plugins: [
      vue(),
      // 자동 import(#6): Vue·Pinia 함수와 src/stores의 스토어
      AutoImport({
        imports: ['vue', 'pinia'],
        dirs: ['src/stores'],
        vueTemplate: true,
        dts: 'auto-imports.d.ts',
        eslintrc: {
          enabled: true,
          filepath: './.eslintrc-auto-import.json',
          globalsPropValue: true,
        },
      }),
      // 컴포넌트 자동 import: 폴더 이름이 앞에 붙는다(components/layout/AppNavBar.vue → <LayoutAppNavBar>)
      Components({
        dirs: ['src/components'],
        directoryAsNamespace: true,
        dts: 'components.d.ts',
      }),
    ],
    resolve: {
      alias: { '@': fileURLToPath(new URL('./src', import.meta.url)) },
    },
    server: {
      port: 3001,
      // 개발 서버 전용 프록시(#7). 운영 연결 방식(리버스 프록시 / CORS)은 배포 구성 때 정한다
      proxy: {
        '/api': { target: apiTarget, changeOrigin: true },
      },
    },
    preview: { port: 3001 },
  }
})
