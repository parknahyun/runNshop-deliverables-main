import { DASHBOARD_ID, menuById } from '@/config/menus'

/** 동시에 열 수 있는 탭 수(대시보드 포함) — 허브 admin-ux-pattern */
export const MAX_TABS = 8

/**
 * MDI 탭 상태(#4·#5). 라우터 없이 열린 탭과 활성 탭만 관리한다.
 * - 대시보드 탭은 항상 열려 있고 닫을 수 없다.
 * - 이미 열린 메뉴를 다시 열면 그 탭으로 이동한다.
 * - 8개가 찼으면 안내만 하고 열지 않는다(#14).
 */
export const useTabsStore = defineStore('tabs', () => {
  const openIds = ref<string[]>([DASHBOARD_ID])
  const activeId = ref(DASHBOARD_ID)
  const notice = ref<string | null>(null)

  const tabs = computed(() => openIds.value.map((id) => menuById[id]!))

  function open(id: string) {
    if (!menuById[id]) return
    if (openIds.value.includes(id)) {
      activeId.value = id
      return
    }
    if (openIds.value.length >= MAX_TABS) {
      notice.value = `탭은 최대 ${MAX_TABS}개까지 열 수 있습니다. 사용하지 않는 탭을 닫아 주세요.`
      return
    }
    openIds.value.push(id)
    activeId.value = id
  }

  function close(id: string) {
    if (id === DASHBOARD_ID) return
    const index = openIds.value.indexOf(id)
    if (index < 0) return
    openIds.value.splice(index, 1)
    // 활성 탭을 닫으면 바로 왼쪽 탭으로 이동한다
    if (activeId.value === id) activeId.value = openIds.value[index - 1] ?? DASHBOARD_ID
  }

  function activate(id: string) {
    if (openIds.value.includes(id)) activeId.value = id
  }

  function dismissNotice() {
    notice.value = null
  }

  return { openIds, activeId, notice, tabs, open, close, activate, dismissNotice }
})
