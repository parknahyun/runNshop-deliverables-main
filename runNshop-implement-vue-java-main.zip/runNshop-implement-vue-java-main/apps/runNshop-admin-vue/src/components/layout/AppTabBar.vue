<!-- 공통 TabBar: 열린 탭, 대시보드 고정(닫기 없음). 스타일은 assets/css/layout.css (.tabbar) -->
<script setup lang="ts">
import { DASHBOARD_ID } from '@/config/menus'

const tabs = useTabsStore()
</script>

<template>
  <div class="tabbar" role="tablist">
    <div
      v-for="tab in tabs.tabs"
      :key="tab.id"
      class="tab"
      :class="{ 'tab--active': tab.id === tabs.activeId }"
      role="tab"
      :aria-selected="tab.id === tabs.activeId"
      @click="tabs.activate(tab.id)"
    >
      <span class="tab__label">{{ tab.label }}</span>
      <button
        v-if="tab.id !== DASHBOARD_ID"
        type="button"
        class="tab__close"
        :aria-label="`${tab.label} 탭 닫기`"
        @click.stop="tabs.close(tab.id)"
      >
        ×
      </button>
    </div>
  </div>
</template>
