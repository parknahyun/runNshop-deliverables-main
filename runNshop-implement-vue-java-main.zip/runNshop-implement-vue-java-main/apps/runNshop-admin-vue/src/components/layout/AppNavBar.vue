<!--
  공통 NavBar: 1depth 메뉴 + 2depth 드롭다운(#2 — Sidebar는 PL 결정 대기).
  사용자 영역(.nav-user)은 비워 둔다(#15). 스타일은 assets/css/layout.css (.navbar)
-->
<script setup lang="ts">
import { navEntries, type NavEntry } from '@/config/menus'

const tabs = useTabsStore()
const openLabel = ref<string | null>(null)

// 활성 탭이 속한 1depth를 강조한다
function isActive(entry: NavEntry): boolean {
  const ids = entry.item ? [entry.item.id] : (entry.children ?? []).map((m) => m.id)
  return ids.includes(tabs.activeId)
}

function onEntryClick(entry: NavEntry) {
  if (entry.item) {
    tabs.open(entry.item.id)
    openLabel.value = null
    return
  }
  openLabel.value = openLabel.value === entry.label ? null : entry.label
}

function openMenu(id: string) {
  tabs.open(id)
  openLabel.value = null
}

// 드롭다운 밖을 누르거나 Esc를 누르면 닫는다
const navRef = ref<HTMLElement | null>(null)
function onDocumentClick(event: MouseEvent) {
  if (navRef.value && !navRef.value.contains(event.target as Node)) openLabel.value = null
}
function onKeydown(event: KeyboardEvent) {
  if (event.key === 'Escape') openLabel.value = null
}
onMounted(() => {
  document.addEventListener('click', onDocumentClick)
  document.addEventListener('keydown', onKeydown)
})
onBeforeUnmount(() => {
  document.removeEventListener('click', onDocumentClick)
  document.removeEventListener('keydown', onKeydown)
})
</script>

<template>
  <header ref="navRef" class="navbar">
    <div class="nav-brand">runNshop Admin</div>
    <nav class="nav-menu" aria-label="주 메뉴">
      <div v-for="entry in navEntries" :key="entry.label" class="nav-menu__entry">
        <button
          type="button"
          class="nav-item"
          :class="{
            'nav-item--active': isActive(entry),
            'nav-item--open': openLabel === entry.label,
          }"
          :aria-expanded="entry.children ? openLabel === entry.label : undefined"
          @click="onEntryClick(entry)"
        >
          {{ entry.label }}
        </button>
        <div v-if="entry.children && openLabel === entry.label" class="nav-dropdown">
          <button
            v-for="menu in entry.children"
            :key="menu.id"
            type="button"
            class="nav-dropdown__item"
            @click="openMenu(menu.id)"
          >
            {{ menu.label }}
          </button>
        </div>
      </div>
    </nav>
    <div class="nav-user"></div>
  </header>
</template>
