<!--
  공통 TabContent: 열린 탭 화면을 모두 유지하고 활성 탭만 보여 준다(탭을 오가도 화면 상태 유지).
  화면은 config/screens.ts에 등록된 컴포넌트, 없으면 "준비 중". 스타일은 assets/css/layout.css (.tab-content)
-->
<script setup lang="ts">
import { screens } from '@/config/screens'

const tabs = useTabsStore()
</script>

<template>
  <main class="tab-content">
    <div v-for="tab in tabs.tabs" v-show="tab.id === tabs.activeId" :key="tab.id" role="tabpanel">
      <component :is="screens[tab.id]" v-if="screens[tab.id]" />
      <CommonComingSoon v-else :menu="tab" />
    </div>
  </main>
</template>
