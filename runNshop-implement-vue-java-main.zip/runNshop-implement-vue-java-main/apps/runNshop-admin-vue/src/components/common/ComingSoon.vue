<!--
  화면 구현 전 자리 표시. 위치·도메인은 DE-메뉴구조도/admin, 화면 ID는 DN 화면레이아웃 기준.
  값이 없으면 '-'.
  스타일은 assets/css/layout.css (.page, .coming-soon)
-->
<script setup lang="ts">
import type { MenuItem } from '@/config/menus'

defineProps<{ menu: MenuItem }>()
</script>

<template>
  <section class="page">
    <h1 class="page-title">{{ menu.label }}</h1>
    <div class="coming-soon">
      <p class="coming-soon__status">준비 중</p>
      <ul class="coming-soon__meta">
        <li>위치: {{ menu.path }}</li>
        <li>화면 ID: {{ menu.screenId ?? '-' }}</li>
        <li>도메인: {{ menu.domain }}</li>
      </ul>
    </div>
  </section>
</template>
