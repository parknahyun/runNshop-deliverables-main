<!-- 셸: NavBar + TabBar + TabContent (MDI). 스타일은 assets/css/layout.css -->
<script setup lang="ts">
const tabs = useTabsStore()

// 탭 8개 초과 안내(#14)는 3초 뒤 사라진다(C7 Toast)
let timer: ReturnType<typeof setTimeout> | undefined
watch(
  () => tabs.notice,
  (message) => {
    clearTimeout(timer)
    if (message) timer = setTimeout(() => tabs.dismissNotice(), 3000)
  },
)
</script>

<template>
  <div class="shell">
    <LayoutAppNavBar />
    <LayoutAppTabBar />
    <LayoutAppTabContent />
    <div v-if="tabs.notice" class="toast toast--info" role="status">{{ tabs.notice }}</div>
  </div>
</template>
