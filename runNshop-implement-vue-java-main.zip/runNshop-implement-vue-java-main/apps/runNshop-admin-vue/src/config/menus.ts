/**
 * admin 메뉴 정의 — 허브 DE-메뉴구조도/admin.md 기준(#12), 화면 ID는 DN 화면레이아웃 기준.
 * 1depth는 NavBar, 2depth는 드롭다운. 각 메뉴는 탭 하나로 열린다.
 */
export interface MenuItem {
  /** 탭·화면을 구분하는 고유 ID */
  id: string
  /** 탭·드롭다운에 보이는 이름(2depth, 2depth가 없으면 1depth) */
  label: string
  /** 메뉴 위치 (예: 주문관리 > 주문내역) */
  path: string
  /** DN 화면 ID. 여러 개면 ' · '로 잇고, DN에 없으면 생략 */
  screenId?: string
  domain: string
}

export interface NavEntry {
  /** 1depth 이름 */
  label: string
  /** 2depth가 없는 1depth(홈·가이드) */
  item?: MenuItem
  /** 2depth 메뉴 */
  children?: MenuItem[]
}

export const DASHBOARD_ID = 'dashboard'

const group = (label: string, items: Omit<MenuItem, 'path'>[]): NavEntry => ({
  label,
  children: items.map((item) => ({ ...item, path: `${label} > ${item.label}` })),
})

export const navEntries: NavEntry[] = [
  {
    label: '홈',
    item: { id: DASHBOARD_ID, label: '대시보드', path: '홈', domain: '공통' },
  },
  group('주문관리', [
    { id: 'order-list', label: '주문내역', screenId: 'SCR-A-001 · SCR-A-002', domain: 'Order' },
    { id: 'claim', label: '클레임관리', screenId: 'SCR-A-003 · SCR-A-004', domain: 'Order' },
  ]),
  group('결제관리', [
    { id: 'payment-list', label: '결제내역', domain: 'Payment' },
    { id: 'refund', label: '환불관리', domain: 'Payment' },
  ]),
  group('상품관리', [
    { id: 'direct-product', label: '직매입 등록', screenId: 'SCR-A-C01', domain: 'Catalog' },
    { id: 'product-review', label: '상품심사', screenId: 'SCR-A-C02', domain: 'Catalog' },
    {
      id: 'product-list',
      label: '상품목록',
      screenId: 'SCR-A-C03 · SCR-A-C04',
      domain: 'Catalog',
    },
    { id: 'display-priority', label: '노출우선순위', screenId: 'SCR-A-C06', domain: 'Catalog' },
    { id: 'taxonomy', label: '분류체계관리', screenId: 'SCR-A-C05', domain: 'Catalog' },
  ]),
  group('회원관리', [
    { id: 'member-list', label: '회원목록', domain: 'Member' },
    { id: 'member-grade', label: '등급관리', domain: 'Member' },
  ]),
  group('프로모션', [
    { id: 'coupon', label: '쿠폰', domain: 'Promotion' },
    { id: 'cart-discount', label: '장바구니할인', domain: 'Promotion' },
  ]),
  group('전시관리', [
    {
      id: 'display-page',
      label: '페이지',
      screenId: 'SCR-A-C07 · SCR-A-C08',
      domain: 'Catalog(Display)',
    },
  ]),
  group('정산', [{ id: 'settlement', label: '정산내역', domain: 'Settlement' }]),
  group('커뮤니티', [
    { id: 'review', label: '리뷰관리', domain: 'Community' },
    { id: 'qna', label: 'Q&A관리', domain: 'Community' },
  ]),
  group('설정', [
    { id: 'policy', label: '운영정책', domain: 'Platform' },
    { id: 'terms', label: '약관관리', domain: 'Platform' },
  ]),
  {
    label: '가이드',
    item: { id: 'guide', label: '가이드', path: '가이드', domain: '공통' },
  },
]

/** 모든 메뉴(21개)를 ID로 찾는다 */
export const menuById: Record<string, MenuItem> = Object.fromEntries(
  navEntries
    .flatMap((entry) => (entry.item ? [entry.item] : (entry.children ?? [])))
    .map((m) => [m.id, m]),
)
