import type { Component } from 'vue'

/**
 * 메뉴 ID → 화면 컴포넌트.
 * 화면을 구현하면 여기에 등록한다. 등록되지 않은 메뉴는 "준비 중"(ComingSoon)으로 열린다.
 */
export const screens: Partial<Record<string, Component>> = {}
