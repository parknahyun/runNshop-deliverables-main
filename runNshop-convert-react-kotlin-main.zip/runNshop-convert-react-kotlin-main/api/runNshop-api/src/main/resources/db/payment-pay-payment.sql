-- pay_payment 신설 (모바일 주문생성 시 실제 결제 저장, payment-persist-mobile-order)
-- 근거: .agents/tasks/payment-persist-mobile-order/design.md §1(결정 1-6), §4
-- ERD(runNshop_erd_v1_0.md §9 Payment 도메인, pay_payment, 1910-1939행) 그대로.
-- 이 라운드는 pay_payment 1개 테이블만 생성한다 — pay_payment_cancel/pay_extra_payment/
-- pay_payment_log/pay_fds_log는 범위 밖(design.md §7)이라 이 파일에 포함하지 않는다.

CREATE TABLE pay_payment (
    id                  BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    payment_no          VARCHAR(50)     NOT NULL UNIQUE,
    platform_order_id   BIGINT          NOT NULL,
    member_id           BIGINT          NOT NULL,
    payment_amount      DECIMAL(15,2)   NOT NULL,
    approved_amount     DECIMAL(15,2),
    payment_method      VARCHAR(20)     NOT NULL DEFAULT 'CARD',
    pay_group_no        INT             NOT NULL DEFAULT 1,
    pg_provider         VARCHAR(50),
    pg_transaction_id   VARCHAR(200),
    pg_approval_no      VARCHAR(100),
    pg_approved_at      TIMESTAMP,
    status              VARCHAR(20)     NOT NULL DEFAULT 'PENDING',
    failed_reason       VARCHAR(300),
    retry_count         INT             NOT NULL DEFAULT 0,
    created_at          TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    is_deleted          BOOLEAN         NOT NULL DEFAULT FALSE,
    deleted_at          TIMESTAMP,
    deleted_by          VARCHAR(50)
);

CREATE INDEX idx_pay_payment_platform_order ON pay_payment (platform_order_id, pay_group_no);

-- 2026-10-27 복합결제: 결제수단별 1행. platform_order_id UNIQUE 해제(주문당 여러 행), point_amount/card_amount 제거,
-- pay_group_no(결제 시도 번호) 추가. payment_no = 'Y'+플랫폼 주문번호 본문+행 순번(예: Y261026-00001-01, 주문당 99행 한도).
-- 기존 DB 마이그레이션: ALTER TABLE pay_payment DROP CONSTRAINT pay_payment_platform_order_id_key;
--   ALTER TABLE pay_payment DROP COLUMN point_amount, DROP COLUMN card_amount, ADD COLUMN pay_group_no INT NOT NULL DEFAULT 1;

-- 레거시 시드 호환(order-platform-order.sql의 ord_platform_order id=1~8과 동일한 이유 — design.md §1 결정 6).
-- amount/member_id는 ord_platform_order 시드 행(payment-amount 동일)과 짝을 맞춤. 전부 COMPLETED(결정 4).
-- platform_order_id=7(ord_platform_order 시드에서 이미 status='CANCELLED')의 결제도 COMPLETED로
-- 단순화해 시딩함 — pay_payment.status 전이 로직이 없고(결정 4) PaymentInfo DTO가 status를 노출하지
-- 않아 현재 관찰 가능한 영향은 없다. 취소 테이블 작업(§7 범위 밖) 착수 시 재검토(design.md §12 Finding 2).
INSERT INTO pay_payment (payment_no, platform_order_id, member_id, payment_amount, approved_amount, payment_method, pay_group_no, pg_provider, pg_transaction_id, pg_approval_no, pg_approved_at, status, created_at, updated_at)
VALUES
    ('Y260626-00001-01', 1, 1, 152000.00, 152000.00, 'CARD', 1, 'MOCK_PG', 'TXN-SEED-1', 'APV-SEED-1', '2026-06-26 09:15', 'COMPLETED', '2026-06-26 09:15', '2026-06-26 09:15'),
    ('Y260626-00002-01', 2, 2, 199000.00, 199000.00, 'CARD', 1, 'MOCK_PG', 'TXN-SEED-2', 'APV-SEED-2', '2026-06-26 10:30', 'COMPLETED', '2026-06-26 10:30', '2026-06-26 10:30'),
    ('Y260625-00001-01', 3, 3, 169000.00, 169000.00, 'CARD', 1, 'MOCK_PG', 'TXN-SEED-3', 'APV-SEED-3', '2026-06-25 14:22', 'COMPLETED', '2026-06-25 14:22', '2026-06-25 14:22'),
    ('Y260625-00002-01', 4, 4, 219000.00, 219000.00, 'CARD', 1, 'MOCK_PG', 'TXN-SEED-4', 'APV-SEED-4', '2026-06-25 11:45', 'COMPLETED', '2026-06-25 11:45', '2026-06-26 09:00'),
    ('Y260624-00001-01', 5, 5, 209000.00, 209000.00, 'CARD', 1, 'MOCK_PG', 'TXN-SEED-5', 'APV-SEED-5', '2026-06-24 16:00', 'COMPLETED', '2026-06-24 16:00', '2026-06-25 18:00'),
    ('Y260624-00002-01', 6, 6, 189000.00, 189000.00, 'CARD', 1, 'MOCK_PG', 'TXN-SEED-6', 'APV-SEED-6', '2026-06-24 13:20', 'COMPLETED', '2026-06-24 13:20', '2026-06-27 00:00'),
    ('Y260623-00001-01', 7, 7, 349000.00, 349000.00, 'CARD', 1, 'MOCK_PG', 'TXN-SEED-7', 'APV-SEED-7', '2026-06-23 09:45', 'COMPLETED', '2026-06-23 09:45', '2026-06-23 11:00'),
    ('Y260623-00002-01', 8, 8, 229000.00, 229000.00, 'CARD', 1, 'MOCK_PG', 'TXN-SEED-8', 'APV-SEED-8', '2026-06-23 08:10', 'COMPLETED', '2026-06-23 08:10', '2026-06-23 08:10');

-- slave 계정 SELECT 권한은 ALTER DEFAULT PRIVILEGES로 자동 부여됨(order-admin-erd-redesign.sql 선례와 동일 전제).
-- 혹시 안 걸려 있으면 수동 보강: GRANT SELECT ON pay_payment TO runnshop_slave;
