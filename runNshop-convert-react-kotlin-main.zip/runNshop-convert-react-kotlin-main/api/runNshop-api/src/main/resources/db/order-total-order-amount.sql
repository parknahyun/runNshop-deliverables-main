-- ord_platform_order.total_order_amount(주문금액) 신설 — 2026-10-29 금액 용어 개편(DBA order.md 3.7.5)
-- 주문금액 = 상품금액(total_item_amount) − 할인금액(total_discount_amount) + 배송비(total_shipping_amount) − 배송비 할인금액
--          = 포인트(point_used_amount) + 결제금액(payment_amount)
-- 현행 payment_amount는 값 의미가 결제금액(주문금액 − 포인트, PG 결제분)과 같아 컬럼명을 바꾸지 않는다.
-- 배송비 할인금액 컬럼은 아직 없다(현재 배송비 0, 배송비 쿠폰 미구현) — 도입 시 이 식에 반영한다.
-- 이 프로젝트는 Flyway/Liquibase가 없고 스키마는 수동 SQL로 관리한다 — order-platform-order.sql 적용 후 실행.
--
-- 2026-11-03 결정(H11):
--   1) DEFAULT 0.00 유지 — 컬럼을 채우지 않는 INSERT는 주문금액 0으로 저장된다(위험 감수).
--   2) 불변식(주문금액 = 포인트 + 결제금액)이 깨진 주문(상품금액 − 할인금액 + 배송비 ≠ 결제금액 + 포인트)은 데이터를 삭제한다.
--   3) 전체를 하나의 트랜잭션으로 실행한다.
--   4) 배포 순서: 이 SQL 먼저 실행 → 그다음 신버전 앱 배포(SQL 적용 전 신버전 앱 기동은 실패한다).
--
-- ※ 아래 DELETE는 되돌릴 수 없다. 실행 전 0)의 SELECT로 대상 건수·내용을 확인하고 필요하면 백업한다.
--   삭제 대상 주문의 재고 차감(cat_stock_deduction)·PG 결제는 복원·취소하지 않는다(개발 데이터 전제).
--   종속 테이블은 db/*.sql 기준이다. 실제 DB에 다른 종속 테이블이 있으면 DELETE 목록에 추가한다.

-- 0) 실행 전 점검: 불일치 주문 확인
SELECT id, platform_order_no, status, total_item_amount, total_discount_amount, total_shipping_amount,
       point_used_amount, payment_amount
  FROM ord_platform_order
 WHERE total_item_amount - total_discount_amount + total_shipping_amount
       <> payment_amount + point_used_amount;

BEGIN;

CREATE TEMP TABLE tmp_invalid_platform_order ON COMMIT DROP AS
SELECT id
  FROM ord_platform_order
 WHERE total_item_amount - total_discount_amount + total_shipping_amount
       <> payment_amount + point_used_amount;

-- 1) 불일치 주문의 종속 데이터 삭제 (자식 → 부모 순서)
DELETE FROM ord_claim
 WHERE order_id IN (SELECT id FROM ord_order
                     WHERE platform_order_id IN (SELECT id FROM tmp_invalid_platform_order));
DELETE FROM ord_delivery
 WHERE order_id IN (SELECT id FROM ord_order
                     WHERE platform_order_id IN (SELECT id FROM tmp_invalid_platform_order));
DELETE FROM ord_order_item        WHERE platform_order_id IN (SELECT id FROM tmp_invalid_platform_order);
DELETE FROM ord_order             WHERE platform_order_id IN (SELECT id FROM tmp_invalid_platform_order);
DELETE FROM ord_platform_order_discount WHERE platform_order_id IN (SELECT id FROM tmp_invalid_platform_order);
DELETE FROM ord_status_history    WHERE platform_order_id IN (SELECT id FROM tmp_invalid_platform_order);
DELETE FROM ord_outbox_event      WHERE platform_order_id IN (SELECT id FROM tmp_invalid_platform_order);
DELETE FROM pay_payment           WHERE platform_order_id IN (SELECT id FROM tmp_invalid_platform_order);
DELETE FROM ord_platform_order    WHERE id IN (SELECT id FROM tmp_invalid_platform_order);

-- 2) 컬럼 추가 및 백필 (남은 행은 모두 불변식을 만족한다)
ALTER TABLE ord_platform_order ADD COLUMN IF NOT EXISTS total_order_amount DECIMAL(15,2);

UPDATE ord_platform_order
   SET total_order_amount = total_item_amount - total_discount_amount + total_shipping_amount
 WHERE total_order_amount IS NULL;

ALTER TABLE ord_platform_order ALTER COLUMN total_order_amount SET NOT NULL;
ALTER TABLE ord_platform_order ALTER COLUMN total_order_amount SET DEFAULT 0.00;

COMMIT;
