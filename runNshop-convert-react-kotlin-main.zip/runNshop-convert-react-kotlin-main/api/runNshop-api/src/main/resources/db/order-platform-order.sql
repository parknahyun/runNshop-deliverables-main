-- ord_platform_order / ord_platform_order_discount 신설 (mobile 주문생성/결제확정 API, order-create-mobile-api)
-- 근거: .agents/tasks/order-create-mobile-api/design.md §3-1, design-02-entity.md §2-1/§2-2
-- ERD(runNshop_erd_v1_0.md §8)의 ord_platform_order(25컬럼)/ord_platform_order_discount(14컬럼+coupon_code 비정규화 1개=15컬럼) 그대로.
-- 이 프로젝트는 Flyway/Liquibase가 없고 스키마는 수동 SQL로 관리한다 — 기존 order-admin-erd-redesign.sql과 별개의 신규 파일.

-- 1) ord_platform_order (25개 컬럼, ERD 그대로)
CREATE TABLE ord_platform_order (
    id                      BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    platform_order_no       VARCHAR(50)     NOT NULL UNIQUE,
    member_id               BIGINT          NOT NULL,
    status                  VARCHAR(30)     NOT NULL DEFAULT 'TEMP',
    total_item_amount       DECIMAL(15,2)   NOT NULL,
    total_discount_amount   DECIMAL(15,2)   NOT NULL DEFAULT 0.00,
    total_shipping_amount   DECIMAL(12,2)   NOT NULL DEFAULT 0.00,
    point_used_amount       INT             NOT NULL DEFAULT 0,
    payment_amount          DECIMAL(15,2)   NOT NULL,
    receiver_name           VARCHAR(50)     NOT NULL,
    receiver_phone          VARCHAR(20)     NOT NULL,
    zipcode                 VARCHAR(10)     NOT NULL,
    address1                VARCHAR(200)    NOT NULL,
    address2                VARCHAR(200),
    delivery_memo           VARCHAR(300),
    ordered_at              TIMESTAMP       NOT NULL,
    created_at              TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at              TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    carted_at               TIMESTAMP       NOT NULL,
    last_validated_at       TIMESTAMP,
    price_snapshot          DECIMAL(12,2),
    event_price_id          BIGINT,
    is_deleted              BOOLEAN         NOT NULL DEFAULT FALSE,
    deleted_at              TIMESTAMP,
    deleted_by              VARCHAR(50)
);

-- 2) ord_platform_order_discount (ERD 14개 컬럼 + 비정규화 coupon_code 1개 = 15개 컬럼)
-- coupon_code: ERD 범위 밖 비정규화 컬럼(design.md §3-1 Finding 5) — promotion_id(BIGINT)와 요청 바디 쿠폰코드(String)
-- 타입 불일치를 닫기 위해 추가. promotion_id는 TODO로 null 유지, coupon_code에 쿠폰 코드 원문을 보관한다.
CREATE TABLE ord_platform_order_discount (
    id                      BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    platform_order_id       BIGINT          NOT NULL REFERENCES ord_platform_order(id),
    discount_type           VARCHAR(30)     NOT NULL,
    promotion_id            BIGINT,
    coupon_code             VARCHAR(30),
    discount_amount         DECIMAL(12,2)   NOT NULL,
    platform_share          DECIMAL(12,2)   NOT NULL DEFAULT 0.00,
    vendor_share            DECIMAL(12,2)   NOT NULL DEFAULT 0.00,
    partial_cancel_policy   VARCHAR(20)     NOT NULL DEFAULT 'KEEP',
    is_revoked              BOOLEAN         NOT NULL DEFAULT FALSE,
    created_at              TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at              TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    is_deleted              BOOLEAN         NOT NULL DEFAULT FALSE,
    deleted_at              TIMESTAMP,
    deleted_by              VARCHAR(50)
);
CREATE INDEX idx_platform_order_discount_platform_order ON ord_platform_order_discount (platform_order_id);

-- 3) slave 계정 SELECT 권한은 ALTER DEFAULT PRIVILEGES로 runnshop_master 소유 신규 테이블에 자동 부여됨
--    (order-admin-erd-redesign.sql 6번과 동일 전제). 혹시 안 걸려 있으면 수동 보강:
-- GRANT SELECT ON ord_platform_order, ord_platform_order_discount TO runnshop_slave;

-- 4) 기존 ord_order seed 8건(id=1~8) 호환용 더미 시드 — ord_order.platform_order_id가 1~8을 그대로 참조하므로
--    (OrderMapper.xml customerCase/AdminCustomerName 1~8 매핑과 동일 키), 이 테이블에도 id=1~8 행을 채워
--    향후 JOIN 전환 시 매치가 깨지지 않도록 한다(design.md §3 Finding 2 (a), 2차 리뷰 Finding 2).
--    member_id는 매핑표 키(1~8)와 동일하게, 금액은 대응하는 ord_order 시드 행의 금액을 그대로 채움(order-admin-erd-redesign.sql 참고).
INSERT INTO ord_platform_order (platform_order_no, member_id, status, total_item_amount, total_discount_amount, total_shipping_amount, point_used_amount, payment_amount, receiver_name, receiver_phone, zipcode, address1, ordered_at, created_at, updated_at, carted_at)
VALUES
    ('P260626-00001-00', 1, 'PAYMENT_COMPLETED', 152000.00, 0.00, 0.00, 0, 152000.00, '홍길동', '010-1234-5678', '06234', '서울특별시 강남구 테헤란로 123', '2026-06-26 09:15', '2026-06-26 09:15', '2026-06-26 09:15', '2026-06-26 09:15'),
    ('P260626-00002-00', 2, 'PAYMENT_COMPLETED', 199000.00, 0.00, 0.00, 0, 199000.00, '홍길동', '010-1234-5678', '06234', '서울특별시 강남구 테헤란로 123', '2026-06-26 10:30', '2026-06-26 10:30', '2026-06-26 10:30', '2026-06-26 10:30'),
    ('P260625-00001-00', 3, 'PAYMENT_COMPLETED', 169000.00, 0.00, 0.00, 0, 169000.00, '홍길동', '010-1234-5678', '06234', '서울특별시 강남구 테헤란로 123', '2026-06-25 14:22', '2026-06-25 14:22', '2026-06-25 14:22', '2026-06-25 14:22'),
    ('P260625-00002-00', 4, 'PAYMENT_COMPLETED', 219000.00, 0.00, 0.00, 0, 219000.00, '홍길동', '010-1234-5678', '06234', '서울특별시 강남구 테헤란로 123', '2026-06-25 11:45', '2026-06-25 11:45', '2026-06-26 09:00', '2026-06-25 11:45'),
    ('P260624-00001-00', 5, 'PAYMENT_COMPLETED', 209000.00, 0.00, 0.00, 0, 209000.00, '홍길동', '010-1234-5678', '06234', '서울특별시 강남구 테헤란로 123', '2026-06-24 16:00', '2026-06-24 16:00', '2026-06-25 18:00', '2026-06-24 16:00'),
    ('P260624-00002-00', 6, 'PAYMENT_COMPLETED', 189000.00, 0.00, 0.00, 0, 189000.00, '홍길동', '010-1234-5678', '06234', '서울특별시 강남구 테헤란로 123', '2026-06-24 13:20', '2026-06-24 13:20', '2026-06-27 00:00', '2026-06-24 13:20'),
    ('P260623-00001-00', 7, 'CANCELLED', 349000.00, 0.00, 0.00, 0, 349000.00, '홍길동', '010-1234-5678', '06234', '서울특별시 강남구 테헤란로 123', '2026-06-23 09:45', '2026-06-23 09:45', '2026-06-23 11:00', '2026-06-23 09:45'),
    ('P260623-00002-00', 8, 'PAYMENT_COMPLETED', 229000.00, 0.00, 0.00, 0, 229000.00, '홍길동', '010-1234-5678', '06234', '서울특별시 강남구 테헤란로 123', '2026-06-23 08:10', '2026-06-23 08:10', '2026-06-23 08:10', '2026-06-23 08:10');
