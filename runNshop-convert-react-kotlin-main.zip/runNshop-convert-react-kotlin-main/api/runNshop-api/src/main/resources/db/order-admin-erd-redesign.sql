-- admin 주문현황/주문상세 ERD 기반 재설계
-- test_admin_orders(평면 테이블+detail_json)를 ERD 정규화 테이블(ord_order/ord_order_item/ord_delivery/ord_claim)로 교체.
-- 근거: .agents/tasks/order-admin-erd-redesign/plan.md §1(엔티티·키 구조), §2(DDL), §5(시드 데이터)
-- 이 프로젝트는 Flyway/Liquibase가 없고 스키마는 수동 SQL로 관리한다 — 이 파일이 최초의 커밋되는 DDL 스크립트.

-- 1) 기존 임시 테이블 제거
DROP TABLE IF EXISTS test_admin_orders;

-- 2) ord_order
CREATE TABLE ord_order (
    id                 BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    order_no           VARCHAR(50)   NOT NULL UNIQUE,
    platform_order_id  BIGINT        NOT NULL,
    vendor_id          BIGINT        NOT NULL,
    status             VARCHAR(30)   NOT NULL DEFAULT 'ORDER_RECEIVED',
    item_amount        DECIMAL(15,2) NOT NULL,
    discount_amount    DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    shipping_fee       DECIMAL(8,2)  NOT NULL DEFAULT 0.00,
    shipping_fee_payer VARCHAR(20)   NOT NULL DEFAULT 'CUSTOMER',
    payment_amount     DECIMAL(15,2) NOT NULL,
    claim_lock         BOOLEAN       NOT NULL DEFAULT FALSE,
    shipping_deadline  TIMESTAMP,
    confirmed_at       TIMESTAMP,
    created_at         TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at         TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    is_deleted         BOOLEAN       NOT NULL DEFAULT FALSE,
    deleted_at         TIMESTAMP,
    deleted_by         VARCHAR(50)
);
CREATE INDEX idx_order_vendor ON ord_order (vendor_id);
CREATE INDEX idx_order_status_date ON ord_order (status, created_at);

-- 3) ord_order_item
CREATE TABLE ord_order_item (
    id                 BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    platform_order_id  BIGINT        NOT NULL,
    order_id           BIGINT        NOT NULL REFERENCES ord_order(id),
    product_id         BIGINT        NOT NULL,
    sku_id             BIGINT        NOT NULL,
    product_name       VARCHAR(300)  NOT NULL,
    option1_type       VARCHAR(50),
    option1_value      VARCHAR(100),
    option2_type       VARCHAR(50),
    option2_value      VARCHAR(100),
    quantity           INT           NOT NULL,
    price_original     DECIMAL(12,2) NOT NULL,
    price_sale         DECIMAL(12,2) NOT NULL,
    price_supply       DECIMAL(12,2) NOT NULL,
    fee_rate           DECIMAL(5,2)  NOT NULL DEFAULT 0.00,
    status             VARCHAR(30)   NOT NULL DEFAULT 'ORDERED',
    review_written     BOOLEAN       NOT NULL DEFAULT FALSE,
    created_at         TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at         TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    is_deleted         BOOLEAN       NOT NULL DEFAULT FALSE,
    deleted_at         TIMESTAMP,
    deleted_by         VARCHAR(50)
);
CREATE INDEX idx_order_item_order ON ord_order_item (order_id);

-- 4) ord_delivery (1:1)
CREATE TABLE ord_delivery (
    id                   BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    order_id             BIGINT        NOT NULL UNIQUE REFERENCES ord_order(id),
    delivery_company_id  BIGINT,
    tracking_no          VARCHAR(100),
    shipping_fee         DECIMAL(8,2)  NOT NULL DEFAULT 0.00,
    shipping_fee_payer   VARCHAR(20)   NOT NULL DEFAULT 'CUSTOMER',
    status               VARCHAR(20)   NOT NULL DEFAULT 'READY',
    shipped_at           TIMESTAMP,
    delivered_at         TIMESTAMP,
    return_tracking_no   VARCHAR(100),
    created_at           TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at           TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    is_deleted           BOOLEAN       NOT NULL DEFAULT FALSE,
    deleted_at           TIMESTAMP,
    deleted_by           VARCHAR(50)
);

-- 5) ord_claim
CREATE TABLE ord_claim (
    id                   BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    order_id             BIGINT        NOT NULL REFERENCES ord_order(id),
    claim_no             VARCHAR(50)   NOT NULL UNIQUE,
    claim_type           VARCHAR(20)   NOT NULL,
    cancel_type          VARCHAR(20),
    status               VARCHAR(30)   NOT NULL DEFAULT 'REQUESTED',
    blame_type           VARCHAR(20),
    blame_evidence_urls  JSONB,
    reason               VARCHAR(500),
    channel              VARCHAR(20)   NOT NULL DEFAULT 'SELF',
    counselor_id         BIGINT,
    counselor_memo       VARCHAR(500),
    refund_amount        DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    extra_delivery_fee   DECIMAL(8,2)  NOT NULL DEFAULT 0.00,
    extra_payment_id     BIGINT,
    extra_payment_status VARCHAR(20),
    completed_at         TIMESTAMP,
    created_at           TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at           TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    is_deleted           BOOLEAN       NOT NULL DEFAULT FALSE,
    deleted_at           TIMESTAMP,
    deleted_by           VARCHAR(50)
);
CREATE INDEX idx_claim_order ON ord_claim (order_id);

-- 6) slave 계정 SELECT 권한은 ALTER DEFAULT PRIVILEGES로 runnshop_master 소유 신규 테이블에 이미 자동 부여됨
--    (사전 확인됨 — \ddp 결과 "runnshop_slave=r/runnshop_master"). 혹시 안 걸려 있으면 수동 보강:
-- GRANT SELECT ON ord_order, ord_order_item, ord_delivery, ord_claim TO runnshop_slave;

-- 7) 시드 데이터 (8건, 기존 test_admin_orders 8건의 비즈니스 의미를 그대로 이어감 — 괄호는 참고용 구(舊) orderId)
-- platform_order_id는 ord_platform_order 테이블이 이번 범위 밖이라 FK 없이 id와 동일한 정수를 placeholder로 사용.

-- id=1 (ord-001) ORDER_RECEIVED — 미출고, 클레임 없음
INSERT INTO ord_order (order_no, platform_order_id, vendor_id, status, item_amount, discount_amount, shipping_fee, payment_amount, created_at, updated_at)
VALUES ('V260626-00001-01', 1, 1, 'ORDER_RECEIVED', 152000.00, 0.00, 0.00, 152000.00, '2026-06-26 09:15', '2026-06-26 09:15');
INSERT INTO ord_order_item (platform_order_id, order_id, product_id, sku_id, product_name, option1_type, option1_value, option2_type, option2_value, quantity, price_original, price_sale, price_supply)
VALUES (1, 1, 101, 1001, '나이키 페가수스 41', '컬러', '블랙', '사이즈', '265', 1, 152000.00, 152000.00, 152000.00);

-- id=2 (ord-002) PAYMENT_COMPLETED — 미출고, 클레임 없음
INSERT INTO ord_order (order_no, platform_order_id, vendor_id, status, item_amount, discount_amount, shipping_fee, payment_amount, created_at, updated_at)
VALUES ('V260626-00002-01', 2, 2, 'PAYMENT_COMPLETED', 199000.00, 0.00, 0.00, 199000.00, '2026-06-26 10:30', '2026-06-26 10:30');
INSERT INTO ord_order_item (platform_order_id, order_id, product_id, sku_id, product_name, option1_type, option1_value, option2_type, option2_value, quantity, price_original, price_sale, price_supply)
VALUES (2, 2, 102, 1002, '아식스 젤카야노 31', '컬러', '화이트', '사이즈', '270', 1, 199000.00, 199000.00, 199000.00);

-- id=3 (ord-003) PREPARING — 배송 READY(송장 없음), 클레임 없음
INSERT INTO ord_order (order_no, platform_order_id, vendor_id, status, item_amount, discount_amount, shipping_fee, payment_amount, created_at, updated_at)
VALUES ('V260625-00001-01', 3, 3, 'PREPARING', 169000.00, 0.00, 0.00, 169000.00, '2026-06-25 14:22', '2026-06-25 14:22');
INSERT INTO ord_order_item (platform_order_id, order_id, product_id, sku_id, product_name, option1_type, option1_value, option2_type, option2_value, quantity, price_original, price_sale, price_supply)
VALUES (3, 3, 103, 1003, '호카 클리프턴 9', '컬러', '그레이', '사이즈', '260', 1, 169000.00, 169000.00, 169000.00);
INSERT INTO ord_delivery (order_id, status, created_at, updated_at)
VALUES (3, 'READY', '2026-06-25 14:22', '2026-06-25 14:22');

-- id=4 (ord-004) IN_DELIVERY — 배송중(CJ대한통운), 클레임 1건(RETURN/INSPECTING)
-- claim.status='INSPECTING'은 ERD §1.4 열거값(REQUESTED·PROCESSING·COMPLETED·REJECTED)에는 없으나
-- plan.md §5 시드 테이블과 기존 admin__GET_orders_{order_id}.json Mock이 그대로 쓰던 값이라 동일하게 유지한다
-- (status 컬럼은 CHECK 제약 없는 VARCHAR(30)이라 저장 가능 — §1.8과 동일하게 자유 문자열 허용 원칙).
INSERT INTO ord_order (order_no, platform_order_id, vendor_id, status, item_amount, discount_amount, shipping_fee, payment_amount, created_at, updated_at)
VALUES ('V260625-00002-01', 4, 4, 'IN_DELIVERY', 219000.00, 0.00, 0.00, 219000.00, '2026-06-25 11:45', '2026-06-26 09:00');
INSERT INTO ord_order_item (platform_order_id, order_id, product_id, sku_id, product_name, option1_type, option1_value, option2_type, option2_value, quantity, price_original, price_sale, price_supply)
VALUES (4, 4, 104, 1004, '뉴발란스 퓨얼셀 SC', '컬러', '그레이', '사이즈', '270', 1, 219000.00, 219000.00, 219000.00);
INSERT INTO ord_delivery (order_id, delivery_company_id, tracking_no, status, shipped_at, created_at, updated_at)
VALUES (4, 1, '1234567890', 'IN_DELIVERY', '2026-06-26 09:00', '2026-06-25 11:45', '2026-06-26 09:00');
INSERT INTO ord_claim (order_id, claim_no, claim_type, status, refund_amount, extra_delivery_fee, created_at, updated_at)
VALUES (4, 'CLM-20260628-001', 'RETURN', 'INSPECTING', 147000.00, 5000.00, '2026-06-28 10:30', '2026-06-28 10:30');

-- id=5 (ord-005) DELIVERED — 배송완료, 클레임 없음
INSERT INTO ord_order (order_no, platform_order_id, vendor_id, status, item_amount, discount_amount, shipping_fee, payment_amount, created_at, updated_at)
VALUES ('V260624-00001-01', 5, 5, 'DELIVERED', 209000.00, 0.00, 0.00, 209000.00, '2026-06-24 16:00', '2026-06-25 18:00');
INSERT INTO ord_order_item (platform_order_id, order_id, product_id, sku_id, product_name, option1_type, option1_value, option2_type, option2_value, quantity, price_original, price_sale, price_supply)
VALUES (5, 5, 105, 1005, '온 클라우드서퍼 2', '컬러', '블랙', '사이즈', '265', 1, 209000.00, 209000.00, 209000.00);
INSERT INTO ord_delivery (order_id, status, delivered_at, created_at, updated_at)
VALUES (5, 'DELIVERED', '2026-06-25 18:00', '2026-06-24 16:00', '2026-06-25 18:00');

-- id=6 (ord-006) CONFIRMED — 배송완료(구매확정), 클레임 없음
INSERT INTO ord_order (order_no, platform_order_id, vendor_id, status, item_amount, discount_amount, shipping_fee, payment_amount, confirmed_at, created_at, updated_at)
VALUES ('V260624-00002-01', 6, 6, 'CONFIRMED', 189000.00, 0.00, 0.00, 189000.00, '2026-06-27 00:00', '2026-06-24 13:20', '2026-06-27 00:00');
INSERT INTO ord_order_item (platform_order_id, order_id, product_id, sku_id, product_name, option1_type, option1_value, option2_type, option2_value, quantity, price_original, price_sale, price_supply)
VALUES (6, 6, 106, 1006, '아디다스 보스턴 13', '컬러', '네이비', '사이즈', '270', 1, 189000.00, 189000.00, 189000.00);
INSERT INTO ord_delivery (order_id, status, created_at, updated_at)
VALUES (6, 'DELIVERED', '2026-06-24 13:20', '2026-06-26 10:00');

-- id=7 (ord-007) CANCELLED — 미출고, 클레임 1건(CANCEL/COMPLETED)
INSERT INTO ord_order (order_no, platform_order_id, vendor_id, status, item_amount, discount_amount, shipping_fee, payment_amount, created_at, updated_at)
VALUES ('V260623-00001-01', 7, 7, 'CANCELLED', 349000.00, 0.00, 0.00, 349000.00, '2026-06-23 09:45', '2026-06-23 11:00');
INSERT INTO ord_order_item (platform_order_id, order_id, product_id, sku_id, product_name, option1_type, option1_value, option2_type, option2_value, quantity, price_original, price_sale, price_supply)
VALUES (7, 7, 107, 1007, '살로몬 S/LAB 울트라 4', '컬러', '블랙', '사이즈', '265', 1, 349000.00, 349000.00, 349000.00);
INSERT INTO ord_claim (order_id, claim_no, claim_type, status, refund_amount, completed_at, created_at, updated_at)
VALUES (7, 'CLM-20260623-002', 'CANCEL', 'COMPLETED', 349000.00, '2026-06-23 11:00', '2026-06-23 10:00', '2026-06-23 11:00');

-- id=8 (ord-008) PAYMENT_COMPLETED — 미출고, 클레임 없음
INSERT INTO ord_order (order_no, platform_order_id, vendor_id, status, item_amount, discount_amount, shipping_fee, payment_amount, created_at, updated_at)
VALUES ('V260623-00002-01', 8, 8, 'PAYMENT_COMPLETED', 229000.00, 0.00, 0.00, 229000.00, '2026-06-23 08:10', '2026-06-23 08:10');
INSERT INTO ord_order_item (platform_order_id, order_id, product_id, sku_id, product_name, option1_type, option1_value, option2_type, option2_value, quantity, price_original, price_sale, price_supply)
VALUES (8, 8, 108, 1008, '브룩스 글리세린 21', '컬러', '화이트', '사이즈', '270', 1, 229000.00, 229000.00, 229000.00);
