-- 주문 상태전이 이력(어드민 주문상세 > 변경이력 탭) 영속화
-- 기록 단위: 결제완료까지(주문상태·결제상태)는 플랫폼주문 단위(order_id=NULL), 이후 배송·클레임 전이는 vendor 주문 단위(order_id=ord_order.id).
-- 대상: 주문상태(ORDER) / 결제상태(PAYMENT) / 배송상태(DELIVERY) / 클레임상태(CLAIM) 전이만 기록한다.
-- 스키마는 수동 SQL로 관리한다(order-admin-erd-redesign.sql 참조). 이력은 append-only — 수정/삭제 컬럼 없음.

CREATE TABLE ord_status_history (
    id                 BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    platform_order_id  BIGINT        NOT NULL,
    order_id           BIGINT,
    target_type        VARCHAR(20)   NOT NULL,
    target_id          BIGINT,
    from_status        VARCHAR(30),
    to_status          VARCHAR(30)   NOT NULL,
    changed_by         VARCHAR(50)   NOT NULL DEFAULT 'SYSTEM',
    reason             VARCHAR(500),
    created_at         TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_status_history_platform_order ON ord_status_history (platform_order_id, created_at);
CREATE INDEX idx_status_history_target ON ord_status_history (target_type, target_id);

-- 시드: 레거시 시드 주문(platform_order_id=order_id=1~8)의 현재 상태에 이르는 대표 전이만 기록
INSERT INTO ord_status_history (platform_order_id, order_id, target_type, target_id, from_status, to_status, changed_by, created_at) VALUES
    (3, NULL, 'ORDER', 3, 'ORDER_RECEIVED',    'PAYMENT_COMPLETED', 'SYSTEM', '2026-06-25 14:22'),
    (3, 3, 'ORDER',    3, 'PAYMENT_COMPLETED', 'PREPARING',         'VENDOR', '2026-06-25 15:00'),
    (4, 4, 'ORDER',    4, 'PAYMENT_COMPLETED', 'PREPARING',         'VENDOR', '2026-06-25 15:00'),
    (4, 4, 'DELIVERY', 4, 'READY',             'IN_DELIVERY',       'VENDOR', '2026-06-26 09:00'),
    (4, 4, 'ORDER',    4, 'PREPARING',         'IN_DELIVERY',       'VENDOR', '2026-06-26 09:00'),
    (4, 4, 'CLAIM',    1, NULL,                'REQUESTED',         'CUSTOMER', '2026-06-28 10:30'),
    (5, 5, 'DELIVERY', 5, 'IN_DELIVERY',       'DELIVERED',         'SYSTEM', '2026-06-25 18:00'),
    (7, 7, 'CLAIM',    2, 'REQUESTED',         'COMPLETED',         'ADMIN',  '2026-06-23 11:00'),
    (7, 7, 'ORDER',    7, 'PAYMENT_COMPLETED', 'CANCELLED',         'ADMIN',  '2026-06-23 11:00');
