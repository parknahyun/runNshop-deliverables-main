-- 재고차감 비동기 처리: 주문 아웃박스(ord_outbox_event) + 상품(Catalog) SKU 재고(cat_sku_stock) / 차감 이력(cat_stock_deduction)
-- 흐름: placeOrder → 주문 STOCK_REQUESTED + 아웃박스 STOCK_DEDUCT_REQUESTED(같은 트랜잭션) → 컨슈머(폴링)가 상품 API(CatalogApi.deductStock)로 차감
--       → 성공: STOCK_DEDUCTED + 아웃박스 PAYMENT_REQUESTED → 컨슈머가 PG 요청(PaymentApi.requestPayment) → DEPOSIT_PENDING / 실패: STOCK_FAILED
-- 스키마는 수동 SQL로 관리한다(order-admin-erd-redesign.sql 참조).

CREATE TABLE ord_outbox_event (
    id                 BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    event_type         VARCHAR(40)   NOT NULL,                 -- STOCK_DEDUCT_REQUESTED / PAYMENT_REQUESTED
    platform_order_id  BIGINT        NOT NULL,
    payload            TEXT,                                   -- JSON (예: {"paymentMethodType":"VIRTUAL_ACCOUNT"})
    status             VARCHAR(20)   NOT NULL DEFAULT 'PENDING', -- PENDING / PROCESSING(컨슈머 점유 중) / DONE / FAILED
    retry_count        INT           NOT NULL DEFAULT 0,
    last_error         VARCHAR(500),
    created_at         TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    processed_at       TIMESTAMP,
    next_attempt_at    TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP, -- 재시도 백오프: 이 시각 이후에만 다시 점유 대상
    locked_at          TIMESTAMP,                              -- 컨슈머가 점유한 시각(임대 만료 판단용)
    locked_by          VARCHAR(100)                            -- 점유한 컨슈머 인스턴스 ID(관측용)
);
-- 컨슈머 다중 실행: PENDING 이벤트를 FOR UPDATE SKIP LOCKED로 점유하고, 점유 후 임대 시간 내 끝나지 않으면 PENDING으로 되돌린다.
CREATE INDEX idx_outbox_event_pending ON ord_outbox_event (status, next_attempt_at, id);

CREATE TABLE cat_sku_stock (
    sku_id      BIGINT       PRIMARY KEY,
    stock_qty   INT          NOT NULL CHECK (stock_qty >= 0),
    updated_at  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 차감 이력 겸 멱등 키: 같은 request_id(=platformOrderNo)로 재호출되면 이미 차감된 것으로 보고 성공 반환한다.
CREATE TABLE cat_stock_deduction (
    id          BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    request_id  VARCHAR(50)  NOT NULL,
    sku_id      BIGINT       NOT NULL,
    quantity    INT          NOT NULL,
    created_at  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (request_id, sku_id)
);

-- 시드: 목 상품/장바구니가 쓰는 상품ID(장바구니→주문서 흐름에서 skuId=productId로 전달됨)와 SKU ID
INSERT INTO cat_sku_stock (sku_id, stock_qty) VALUES
    (101,100),(102,100),(103,100),(104,100),(105,100),(106,100),(107,100),(108,100),
    (201,100),(202,100),(203,100),(301,100),
    (1001,100),(1002,100),(1003,100),(1004,100),(1005,100),(1006,100),(1007,100),(1008,100),(1009,100),(1010,100);

-- 권한: 애플리케이션 master 계정 소유로 두고 slave는 조회만(다른 테이블과 동일). 슈퍼유저로 실행했다면 아래를 수행한다.
ALTER TABLE ord_outbox_event OWNER TO runnshop_master;
ALTER TABLE cat_sku_stock OWNER TO runnshop_master;
ALTER TABLE cat_stock_deduction OWNER TO runnshop_master;
GRANT SELECT ON ord_outbox_event, cat_sku_stock, cat_stock_deduction TO runnshop_slave;

-- [기존 DB 마이그레이션] 위 컬럼 추가 전에 만든 테이블에는 아래를 실행한다(2026-10-26 컨슈머 다중 실행 지원).
-- ALTER TABLE ord_outbox_event ADD COLUMN next_attempt_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, ADD COLUMN locked_at TIMESTAMP, ADD COLUMN locked_by VARCHAR(100);
-- DROP INDEX idx_outbox_event_pending; CREATE INDEX idx_outbox_event_pending ON ord_outbox_event (status, next_attempt_at, id);
