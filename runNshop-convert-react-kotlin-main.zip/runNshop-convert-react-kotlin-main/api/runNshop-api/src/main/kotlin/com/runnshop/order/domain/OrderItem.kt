package com.runnshop.order.domain

import jakarta.persistence.Column
import jakarta.persistence.Entity
import jakarta.persistence.FetchType
import jakarta.persistence.GeneratedValue
import jakarta.persistence.GenerationType
import jakarta.persistence.Id
import jakarta.persistence.JoinColumn
import jakarta.persistence.ManyToOne
import jakarta.persistence.Table
import java.math.BigDecimal
import java.time.LocalDateTime

/**
 * ord_order_item — 주문 상품(스냅샷) Entity (ERD §8 원문 컬럼 그대로, plan.md §1.2).
 * Order 1건당 N개, `order`에 종속된 소유 관계(cascade=ALL, orphanRemoval=true) — 주문과 독립적으로
 * 생성/삭제되지 않는 스냅샷 성격이라 자체 Repository를 두지 않는다(Order 애그리거트를 통해서만 접근).
 */
@Entity
@Table(name = "ord_order_item")
class OrderItem(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    val id: Long = 0,

    /** ord_order.id와 동일 값의 비정규화 컬럼(ERD 원문 그대로 유지). */
    @Column(name = "platform_order_id")
    val platformOrderId: Long,

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "order_id")
    val order: Order,

    @Column(name = "product_id")
    val productId: Long,

    @Column(name = "sku_id")
    val skuId: Long,

    @Column(name = "product_name")
    val productName: String,

    @Column(name = "option1_type")
    val option1Type: String?,

    @Column(name = "option1_value")
    val option1Value: String?,

    @Column(name = "option2_type")
    val option2Type: String?,

    @Column(name = "option2_value")
    val option2Value: String?,

    @Column(name = "quantity")
    val quantity: Int,

    @Column(name = "price_original")
    val priceOriginal: BigDecimal,

    @Column(name = "price_sale")
    val priceSale: BigDecimal,

    @Column(name = "price_supply")
    val priceSupply: BigDecimal,

    @Column(name = "fee_rate")
    val feeRate: BigDecimal,

    @Column(name = "status")
    var status: String,

    @Column(name = "review_written")
    val reviewWritten: Boolean,

    @Column(name = "created_at")
    val createdAt: LocalDateTime,

    @Column(name = "updated_at")
    val updatedAt: LocalDateTime,

    @Column(name = "is_deleted")
    val isDeleted: Boolean,

    @Column(name = "deleted_at")
    val deletedAt: LocalDateTime?,

    @Column(name = "deleted_by")
    val deletedBy: String?
) {
    // JPA 기본 생성자 요구사항 — Hibernate가 리플렉션으로 인스턴스를 만들 때 사용
    constructor() : this(
        platformOrderId = 0, order = Order(), productId = 0, skuId = 0, productName = "",
        option1Type = null, option1Value = null, option2Type = null, option2Value = null,
        quantity = 0, priceOriginal = BigDecimal.ZERO, priceSale = BigDecimal.ZERO, priceSupply = BigDecimal.ZERO,
        feeRate = BigDecimal.ZERO, status = "", reviewWritten = false,
        createdAt = LocalDateTime.now(), updatedAt = LocalDateTime.now(), isDeleted = false,
        deletedAt = null, deletedBy = null
    )
}
