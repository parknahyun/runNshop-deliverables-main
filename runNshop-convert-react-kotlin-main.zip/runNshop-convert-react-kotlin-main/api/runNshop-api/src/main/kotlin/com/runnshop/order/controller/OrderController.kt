package com.runnshop.order.controller

import com.runnshop.order.dto.OrderSheetDiscountRequest
import com.runnshop.order.dto.OrderSheetRequest
import com.runnshop.order.dto.PayRequest
import com.runnshop.order.service.AdminOrderFilter
import com.runnshop.order.service.OrderService
import com.runnshop.order.service.PartnerOrderFilter
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController

/**
 * order/ 서브도메인 통합 Controller.
 * 앱(FE)별로 Controller를 나누지 않고, 메서드 + URL 매핑으로만 구분한다.
 * (DM-시퀀스/readme.md §1 v3, DP-클래스설계/order.md §1 참조)
 * Controller는 요청/응답만 처리하고 가공 로직은 전부 OrderService가 담당한다 — MockLoader는 직접 주입받지 않는다.
 */
@RestController
class OrderController(private val orderService: OrderService) {

    // ── 회원(mobile) ──

    /** 장바구니 선택 상품으로 주문서를 생성한다. 배송지·쿠폰·포인트·결제수단 정보를 반환한다. (DL §5) */
    @PostMapping("/api/mobile/v1/my/orders/sheet")
    fun createOrderSheet(@RequestBody request: OrderSheetRequest): ResponseEntity<Any> {
        val memberId = 1L // placeOrder()와 동일한 인증 연동 전 placeholder
        val data = orderService.createOrderSheet(memberId, request)
        return ResponseEntity.ok(data)
    }

    /** 진입 시 저장된 주문서(임시주문)를 다시 조회한다 — 새로고침/재진입용. */
    @GetMapping("/api/mobile/v1/my/orders/sheet/{orderSheetId}")
    fun getOrderSheet(@PathVariable orderSheetId: String): ResponseEntity<Any> {
        val memberId = 1L
        val data = orderService.getOrderSheet(memberId, orderSheetId)
        return ResponseEntity.ok(data)
    }

    /** 주문서의 쿠폰/포인트 적용(해제 포함)을 임시주문에 영속하고 갱신된 주문서를 반환한다. */
    @PutMapping("/api/mobile/v1/my/orders/sheet/{orderSheetId}/discount")
    fun applyOrderSheetDiscount(@PathVariable orderSheetId: String, @RequestBody request: OrderSheetDiscountRequest): ResponseEntity<Any> {
        val memberId = 1L
        val data = orderService.applyOrderSheetDiscount(memberId, orderSheetId, request)
        return ResponseEntity.ok(data)
    }

    /**
     * 주문서(orderSheetId)의 결제를 확정한다. (DL §6)
     * memberId는 실 인증 연동 전 placeholder — 추후 Authorization 헤더 파싱으로 교체, PlatformOrder.memberId(Long)와
     * 타입을 맞추기 위해 String이 아닌 Long 고정값 사용(design.md §4-2 0단계, §5 사용자 결정 3).
     */
    @PostMapping("/api/mobile/v1/my/orders/{orderSheetId}/pay")
    fun placeOrder(@PathVariable orderSheetId: String, @RequestBody request: PayRequest): ResponseEntity<Any> {
        val memberId = 1L
        val data = orderService.placeOrder(memberId, orderSheetId, request)
        return ResponseEntity.ok(mapOf("code" to "SUCCESS", "data" to data))
    }

    /** 로그인한 본인(me)의 주문 목록을 조회한다. (DL §11) */
    @GetMapping("/api/mobile/v1/my/orders")
    fun getMyOrders(): ResponseEntity<Any> {
        // TODO: 실 인증 연동 전 placeholder — placeOrder()와 동일 패턴
        val memberId = 1L
        val data = orderService.getMyOrders(memberId)
        return ResponseEntity.ok(data)
    }

    /** 로그인한 본인(me)의 주문 상세를 조회한다. 판매자별 상품·결제정보·배송정보·주문이력을 포함한다. (DL §30) */
    @GetMapping("/api/mobile/v1/my/orders/{orderId}")
    fun getMyOrderDetail(@PathVariable orderId: String): ResponseEntity<Any> {
        // TODO: 실 인증 연동 전 placeholder — placeOrder()/getMyOrders()와 동일 패턴
        val memberId = 1L
        val data = orderService.getMyOrderDetail(memberId, orderId)
        return ResponseEntity.ok(data)
    }

    // ── 관리자(admin) ──

    /** 어드민(CS)이 전체 회원 주문을 키워드·상태·기간으로 검색한다. (DL §15) */
    @GetMapping("/api/admin/v1/orders")
    fun getAdminOrders(
        @RequestParam(required = false) keyword: String?,
        @RequestParam(required = false, defaultValue = "ALL") status: String?,
        @RequestParam(required = false) from: String?,
        @RequestParam(required = false) to: String?,
        @RequestParam(required = false, defaultValue = "1") page: Int?,
        @RequestParam(required = false, defaultValue = "10") size: Int?
    ): ResponseEntity<Any> {
        val data = orderService.getAdminOrders(
            AdminOrderFilter(keyword = keyword, status = status, from = from, to = to, page = page ?: 1, size = size ?: 10)
        )
        return ResponseEntity.ok(mapOf("code" to "SUCCESS", "data" to data))
    }

    /** 어드민(CS)이 특정 주문의 상세(상품/결제/배송/클레임/문의/변경이력)를 조회한다. (DL §16) */
    @GetMapping("/api/admin/v1/orders/{orderId}")
    fun getAdminOrderDetail(@PathVariable orderId: String): ResponseEntity<Any> {
        val data = orderService.getAdminOrderDetail(orderId)
        return ResponseEntity.ok(data)
    }

    // ── 파트너(partner) ──

    /** 판매자가 자기 매장 주문을 상태·기간·키워드로 검색한다. (DL §22) */
    @GetMapping("/api/partner/v1/orders")
    fun getPartnerOrders(
        @RequestParam(required = false, defaultValue = "ALL") status: String?,
        @RequestParam(required = false) from: String?,
        @RequestParam(required = false) to: String?,
        @RequestParam(required = false) keyword: String?,
        @RequestParam(required = false, defaultValue = "1") page: Int?,
        @RequestParam(required = false, defaultValue = "10") size: Int?
    ): ResponseEntity<Any> {
        // TODO: 실 인증 연동 전 placeholder — 추후 X-Vendor-Id 헤더 등으로 교체
        val vendorId = "self"
        val data = orderService.getPartnerOrders(
            vendorId,
            PartnerOrderFilter(keyword = keyword, status = status, from = from, to = to, page = page ?: 1, size = size ?: 10)
        )
        return ResponseEntity.ok(mapOf("code" to "SUCCESS", "data" to data))
    }

    /** 판매자가 자기 매장의 특정 주문 상세(상품/배송/클레임/변경이력)를 조회한다. (DL §23) */
    @GetMapping("/api/partner/v1/orders/{orderId}")
    fun getPartnerOrderDetail(@PathVariable orderId: String): ResponseEntity<Any> {
        // TODO: 실 인증 연동 전 placeholder — getPartnerOrders()의 "self"(String, 미사용)와 달리 이 값은
        // 실제 소유 검증(order.vendorId != vendorId)에 쓰이므로 Long 고정값을 쓴다.
        val vendorId = 1L
        val data = orderService.getPartnerOrderDetail(vendorId, orderId)
        return ResponseEntity.ok(data)
    }
}
