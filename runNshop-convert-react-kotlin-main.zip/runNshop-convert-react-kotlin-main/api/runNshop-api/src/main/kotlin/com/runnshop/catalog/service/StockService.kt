package com.runnshop.catalog.service

import com.runnshop.catalog.repository.SkuStockRepository
import com.runnshop.catalog.repository.StockDeductionRepository
import com.runnshop.order.port.CatalogApi
import com.runnshop.order.port.StockDeductFailure
import com.runnshop.order.port.StockDeductItem
import com.runnshop.order.port.StockDeductResult
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Propagation
import org.springframework.transaction.annotation.Transactional

/** 상품(Catalog) 재고 차감 — Order의 CatalogApi Port 구현체. 차감은 SKU 단위 독립 트랜잭션(SkuStockDeductor)으로 처리한다. */
@Service
class StockService(
    private val deductor: SkuStockDeductor,
    private val skuStockRepository: SkuStockRepository,
    private val stockDeductionRepository: StockDeductionRepository
) : CatalogApi {

    override fun deductStock(requestId: String, items: List<StockDeductItem>): StockDeductResult {
        // 같은 SKU가 여러 줄이면 합산해 한 번에 차감한다.
        val bySku = items.groupBy { it.skuId }.mapValues { (_, v) -> v.sumOf { it.quantity } }
        val failures = mutableListOf<StockDeductFailure>()
        for ((skuId, quantity) in bySku) {
            val failure = try {
                deductor.deduct(requestId, skuId, quantity)
            } catch (e: DuplicateDeductionException) {
                null // 동시 처리로 이미 차감됨
            }
            if (failure != null) failures += failure
        }
        return StockDeductResult(failures)
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    override fun restoreStock(requestId: String) {
        val deductions = stockDeductionRepository.findByRequestId(requestId)
        deductions.forEach { skuStockRepository.restore(it.skuId, it.quantity) }
        stockDeductionRepository.deleteAll(deductions) // 복원 이력 제거 = 재호출 멱등(다시 복원하지 않음)
    }
}
