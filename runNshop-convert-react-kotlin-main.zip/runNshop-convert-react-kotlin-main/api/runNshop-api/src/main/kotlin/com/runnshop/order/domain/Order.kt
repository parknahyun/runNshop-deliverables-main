package com.runnshop.order.domain

import jakarta.persistence.CascadeType
import jakarta.persistence.Column
import jakarta.persistence.Entity
import jakarta.persistence.FetchType
import jakarta.persistence.GeneratedValue
import jakarta.persistence.GenerationType
import jakarta.persistence.Id
import jakarta.persistence.JoinColumn
import jakarta.persistence.ManyToOne
import jakarta.persistence.OneToMany
import jakarta.persistence.OneToOne
import jakarta.persistence.Table
import java.math.BigDecimal
import java.time.LocalDateTime

/**
 * ord_order — 주문 Entity (ERD §8 Order 도메인 원문 컬럼 그대로).
 * PK는 ERD 리터럴을 그대로 따라 `Long`(IDENTITY)을 채택한다 — 기존 DP-클래스설계의 String(ULID) 패턴과
 * 다르게 가는 것이 이번 ERD 정합화 작업의 의도된 결정이다(plan.md §1.6, work-scope "1차 근거 기준 정정" 원칙 적용).
 * items/delivery/claims는 연관관계 소유 주체(mappedBy="order")이며 fetch 전략은 전부 LAZY — 상세 조회는
 * OrderRepository.findDetailById()의 @EntityGraph로 즉시 로딩한다(plan.md §1.5).
 */
@Entity
@Table(name = "ord_order")
class Order(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    val id: Long = 0,

    @Column(name = "order_no")
    val orderNo: String,

    /**
     * ord_platform_order.id FK — order-create-mobile-api 작업에서 PlatformOrder Entity가 신설되어
     * 평문 Long(platformOrderId)에서 물리 연관관계로 교체됐다(design-02-entity.md §2-3, design.md §3 Finding 4).
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "platform_order_id")
    val platformOrder: PlatformOrder,

    @Column(name = "vendor_id")
    val vendorId: Long,

    @Column(name = "status")
    var status: String,

    @Column(name = "item_amount")
    val itemAmount: BigDecimal,

    @Column(name = "discount_amount")
    val discountAmount: BigDecimal,

    @Column(name = "shipping_fee")
    val shippingFee: BigDecimal,

    @Column(name = "shipping_fee_payer")
    val shippingFeePayer: String,

    @Column(name = "payment_amount")
    val paymentAmount: BigDecimal,

    @Column(name = "claim_lock")
    val claimLock: Boolean,

    @Column(name = "shipping_deadline")
    val shippingDeadline: LocalDateTime?,

    @Column(name = "confirmed_at")
    val confirmedAt: LocalDateTime?,

    @Column(name = "created_at")
    val createdAt: LocalDateTime,

    @Column(name = "updated_at")
    val updatedAt: LocalDateTime,

    @Column(name = "is_deleted")
    val isDeleted: Boolean,

    @Column(name = "deleted_at")
    val deletedAt: LocalDateTime?,

    @Column(name = "deleted_by")
    val deletedBy: String?,

    @OneToMany(mappedBy = "order", cascade = [CascadeType.ALL], orphanRemoval = true, fetch = FetchType.LAZY)
    val items: MutableList<OrderItem> = mutableListOf(),

    @OneToOne(mappedBy = "order", cascade = [CascadeType.ALL], optional = true, fetch = FetchType.LAZY)
    val delivery: Delivery? = null,

    @OneToMany(mappedBy = "order", cascade = [CascadeType.PERSIST, CascadeType.MERGE], orphanRemoval = false, fetch = FetchType.LAZY)
    val claims: MutableList<Claim> = mutableListOf()
) {
    // JPA 기본 생성자 요구사항 — Hibernate가 리플렉션으로 인스턴스를 만들 때 사용
    constructor() : this(
        orderNo = "", platformOrder = PlatformOrder(), vendorId = 0, status = "", itemAmount = BigDecimal.ZERO,
        discountAmount = BigDecimal.ZERO, shippingFee = BigDecimal.ZERO, shippingFeePayer = "",
        paymentAmount = BigDecimal.ZERO, claimLock = false, shippingDeadline = null, confirmedAt = null,
        createdAt = LocalDateTime.now(), updatedAt = LocalDateTime.now(), isDeleted = false,
        deletedAt = null, deletedBy = null
    )
}
