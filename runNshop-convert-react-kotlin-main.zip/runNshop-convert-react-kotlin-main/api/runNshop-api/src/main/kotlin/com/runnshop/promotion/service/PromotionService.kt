package com.runnshop.promotion.service

import com.runnshop.common.MockLoader
import com.runnshop.order.port.CouponCheckItem
import com.runnshop.order.port.CouponDiscountResult
import com.runnshop.order.port.PromotionApi
import org.springframework.stereotype.Service
import java.math.BigDecimal
import java.math.RoundingMode

/** Mock 파일명 — 메서드마다 하드코딩하지 않고 한곳에 모아 오타를 컴파일 타임에 잡는다. */
private object MockFile {
    const val INTERNAL_COUPON_VALIDATE = "mobile__GET_internal_coupon_validate.json"
}

/**
 * Promotion 도메인 서비스. 이번 범위는 `PromotionApi`(도메인 경계 Port)의 `validateCoupon()` 1개 메서드만
 * 담당한다 — DP가 정의할 완전한 Promotion Service(쿠폰 발급/적립 등)는 범위 밖이며 이 파일에 추가하지
 * 않는다(work-scope: Order 도메인 작업 중 사용자 승인을 받은 좁은 예외 범위, design-03-publicapi.md §1).
 */
@Service
class PromotionService(
    private val mockLoader: MockLoader
) : PromotionApi {

    /**
     * 쿠폰 1건이 주어진 상품 목록에 적용 가능한지 검증하고 할인액을 계산한다(PromotionApi 구현).
     * Mock 데이터(mock/promotion/mobile__GET_internal_coupon_validate.json)의 쿠폰 식별자(CPN-001/CPN-002)는
     * 기존 mock/order/mobile__POST_my_orders_sheet.json의 coupons.items와 동일하게 유지해 응답 일관성을 지킨다
     * (design-03-publicapi.md §1).
     */
    override fun validateCoupon(memberId: String, couponId: String, items: List<CouponCheckItem>): CouponDiscountResult {
        val loaded = mockLoader.load("promotion", MockFile.INTERNAL_COUPON_VALIDATE)
        @Suppress("UNCHECKED_CAST")
        val data = loaded["data"] as Map<String, Any?>
        @Suppress("UNCHECKED_CAST")
        val coupons = data["coupons"] as Map<String, Map<String, Any?>>
        val coupon = coupons[couponId]
            ?: return CouponDiscountResult(couponId = couponId, applicable = false, discountAmount = 0)

        val orderTotal = items.sumOf { it.priceSale.toLong() * it.quantity }
        val minOrder = (coupon["min_order"] as Number).toLong()
        if (orderTotal < minOrder) {
            return CouponDiscountResult(couponId = couponId, applicable = false, discountAmount = 0)
        }

        val discountType = coupon["discount_type"] as String
        val discountValue = (coupon["discount_value"] as Number).toLong()
        val maxDiscount = (coupon["max_discount"] as Number).toLong()
        val discountAmount = when (discountType) {
            "RATE" -> (BigDecimal(orderTotal).multiply(BigDecimal(discountValue))
                .divide(BigDecimal(100), 0, RoundingMode.DOWN).toLong()).coerceAtMost(maxDiscount)
            "FIXED" -> discountValue.coerceAtMost(maxDiscount)
            else -> 0L
        }

        return CouponDiscountResult(couponId = couponId, applicable = true, discountAmount = discountAmount.toInt())
    }
}
