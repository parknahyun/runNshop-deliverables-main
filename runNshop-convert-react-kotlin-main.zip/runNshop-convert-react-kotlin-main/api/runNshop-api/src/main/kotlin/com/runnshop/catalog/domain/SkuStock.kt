package com.runnshop.catalog.domain

import jakarta.persistence.Column
import jakarta.persistence.Entity
import jakarta.persistence.Id
import jakarta.persistence.Table
import java.time.LocalDateTime

/** cat_sku_stock — SKU별 가용 재고. 차감은 조건부 UPDATE(SkuStockRepository.deduct)로만 한다(동시성). */
@Entity
@Table(name = "cat_sku_stock")
class SkuStock(
    @Id
    @Column(name = "sku_id")
    val skuId: Long,

    @Column(name = "stock_qty")
    var stockQty: Int,

    @Column(name = "updated_at")
    var updatedAt: LocalDateTime = LocalDateTime.now()
) {
    constructor() : this(skuId = 0, stockQty = 0)
}
