package com.runnshop.order.service

import com.runnshop.common.MockLoader
import com.runnshop.common.exception.BadRequestException
import com.runnshop.common.exception.ForbiddenException
import com.runnshop.common.exception.NotFoundException
import com.runnshop.common.exception.UnprocessableException
import com.runnshop.order.domain.Claim
import com.runnshop.order.domain.Delivery
import com.runnshop.order.domain.Order
import com.runnshop.order.domain.OrderItem
import com.runnshop.order.domain.OutboxEvent
import com.runnshop.order.domain.OutboxEventType
import com.runnshop.order.domain.PlatformOrder
import com.runnshop.order.domain.PlatformOrderDiscount
import com.runnshop.order.domain.StatusTargetType
import com.runnshop.order.dto.OrderItemRequest
import com.runnshop.order.dto.OrderListResponse
import com.runnshop.order.dto.OrderSheetDiscountRequest
import com.runnshop.order.dto.OrderSheetRequest
import com.runnshop.order.dto.Pagination
import com.runnshop.order.dto.PayRequest
import com.runnshop.order.dto.PayResponse
import com.runnshop.order.mapper.OrderMapper
import com.runnshop.order.mapper.StatusCountRow
import com.runnshop.order.mapper.StatusHistoryRow
import com.runnshop.order.port.CouponCheckItem
import com.runnshop.order.port.MemberApi
import com.runnshop.order.port.PaymentApi
import com.runnshop.order.port.PromotionApi
import com.runnshop.order.port.VendorApi
import com.runnshop.order.repository.OrderRepository
import com.runnshop.order.repository.OutboxEventRepository
import com.runnshop.order.repository.PlatformOrderRepository
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import java.math.BigDecimal
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.UUID
import kotlin.math.ceil

/** Mock JSON 파일명 — 메서드마다 하드코딩하지 않고 한곳에 모아 오타를 컴파일 타임에 잡는다. */
private object MockFile {
    const val PARTNER_ORDERS = "partner__GET_orders.json"
    const val PARTNER_ORDER_DETAIL = "partner__GET_orders_{order_id}.json"
    const val MY_ORDERS = "mobile__GET_my_orders.json"
    const val MY_ORDER_DETAIL = "mobile__GET_my_orders_{order_id}.json"
    const val MY_ORDER_SHEET = "mobile__POST_my_orders_sheet.json"
    /** admin 주문상세의 history/inquiries/logs만 ERD 범위 밖 테이블(ord_platform_order 세부 테이블 미생성) 소관이라
     * Mock 유지한다. 수령인 정보(recipientName/phone/address/memo)는 [order-platform-order-channel-redesign]
     * ord_platform_order 컬럼(receiverName/receiverPhone/zipcode/address1/address2/deliveryMemo)으로
     * 전환되어 더 이상 이 Mock에서 가져오지 않는다 — buildShippingMap() 삭제와 한 짝(design.md §3-2-3). */
    const val ADMIN_ORDER_DETAIL = "admin__GET_orders_{order_id}.json"
}

/** DB의 LocalDateTime을 기존 Mock/목록 응답과 동일한 "YYYY-MM-DD HH:MM" 문자열로 포맷한다. */
/** 주문서 진입 시 생성되는 임시주문 상태(ERD ord_platform_order.status 기본값). 목록/집계에서는 제외한다. */
private const val TEMP_STATUS = "TEMP"
/** 주문 접수 직후 상태 — 재고차감 요청 후 컨슈머 처리 대기(OrderEventHandler가 STOCK_DEDUCTED/STOCK_FAILED로 전이). */
private const val STOCK_REQUESTED_STATUS = "STOCK_REQUESTED"

private val ORDER_DATE_FORMAT: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")

/**
 * ord_delivery.delivery_company_id → 택배사명 임시 매핑. cfg_delivery_company(Config 도메인) 모델링 전까지의
 * 임시 대체이며, 그 테이블이 생기면 실제 조인으로 교체되어야 한다(plan.md §1.7).
 */
private object DeliveryCompanyName {
    private val names = mapOf(1L to "CJ대한통운", 2L to "한진택배", 3L to "롯데택배")
    fun of(deliveryCompanyId: Long?): String? = deliveryCompanyId?.let { names[it] }
}

/**
 * ord_platform_order.status → 한글 라벨. 기존 mobile__GET_my_orders.json에 하드코딩된 statusLabel 값을
 * 그대로 매핑 테이블로 옮기고, placeOrder()가 실제로 생성하는 DEPOSIT_PENDING(기존 Mock에는 없던 상태) 1개를
 * 추가했다. (완전 신규 object — DeliveryCompanyName과 같은 "역할+이름" 네이밍 패턴을 따름,
 * order-platform-order-channel-redesign)
 */
private object MyOrderStatusLabel {
    private val labels = mapOf(
        "STOCK_REQUESTED" to "재고확인중", "STOCK_DEDUCTED" to "재고차감완료", "STOCK_FAILED" to "재고부족",
        "DEPOSIT_PENDING" to "입금대기", "ORDER_RECEIVED" to "주문접수", "PAYMENT_COMPLETED" to "결제완료",
        "PREPARING" to "상품준비중", "IN_DELIVERY" to "배송중", "DELIVERED" to "배송완료",
        "CONFIRMED" to "구매확정", "CANCELLED" to "취소"
    )
    fun of(status: String): String? = labels[status]
}

data class AdminOrderFilter(
    val keyword: String? = null,
    val status: String? = "ALL",
    val from: String? = null,
    val to: String? = null,
    val page: Int = 1,
    val size: Int = 10
)

data class PartnerOrderFilter(
    val keyword: String? = null,
    val status: String? = "ALL",
    val from: String? = null,
    val to: String? = null,
    val page: Int = 1,
    val size: Int = 10
)

/**
 * Order 도메인 조회(목록/상세) 비즈니스 로직.
 *
 * 목록 조회 메서드는 아래 4단계 구조를 따른다 (코딩 패턴 — DB 전환 시에도 유지):
 *  ① validation   — 입력 형식/범위를 명시적으로 검증한다 (조용한 보정 금지).
 *  ② mapper execute — 지금은 MockLoader가 전체 데이터셋을 로드하고 Service가 사후 필터링하지만,
 *      실제 쿼리는 list(목록)/count(건수)/summary(집계) 3개로 분리된다는 전제 위에서 메서드를 나눈다.
 *      - list: 공유조건(keyword+dateRange) + status 전용조건, ORDER BY + LIMIT/OFFSET
 *      - count: list와 동일 WHERE, LIMIT 없이 건수만
 *      - summary: 공유조건만 (status 제외), GROUP BY status — 목록 필터와 무관하게 전체 상태 분포를 보여주기 위함
 *  ③ dto convert   — Map 대신 OrderListResponse/Pagination DTO로 변환한다.
 * (DP-클래스설계/order.md 네이밍 준수)
 */
@Service
@Transactional
class OrderService(
    private val mockLoader: MockLoader,
    // ERD 정규화 테이블(ord_order 등) 연동 — admin 주문현황/상세 전용. 다른 메서드는 전부 MockLoader만 사용
    private val orderMapper: OrderMapper,          // 목록: MyBatis(slave, 읽기전용)
    private val orderRepository: OrderRepository,  // 상세: JPA(master)
    private val paymentApi: PaymentApi, // 상세의 payment 블록 조회: Payment 도메인 Port (PG 결제요청은 아웃박스 컨슈머가 호출)
    private val outboxEventRepository: OutboxEventRepository, // 재고차감 요청 아웃박스(비동기 처리)
    // order-create-mobile-api 결제확정(placeOrder) 전용 의존성 3개 추가(design.md §5 Finding H)
    private val platformOrderRepository: PlatformOrderRepository,
    private val promotionApi: PromotionApi,
    private val memberApi: MemberApi,
    // [backend-service-pattern 적용] admin 목록/상세의 customer/vendorName 표시값을 더 이상 Order가 직접
    // 보유한 고정 Map으로 채우지 않고, 각 도메인 소유의 Port로 조회한다(VendorApi 신규 주입).
    private val vendorApi: VendorApi,
    private val statusHistoryService: OrderStatusHistoryService // 상태전이 이력(주문/결제/배송/클레임) 기록·조회
) {

    private val log = LoggerFactory.getLogger(OrderService::class.java)

    // [order-platform-order-channel-redesign] ord_order.status(8종) 기준 → ord_platform_order.status
    // (DEPOSIT_PENDING/PAYMENT_COMPLETED/CANCELLED 3종, 실측) 기준으로 교체. 나머지 5종(ORDER_RECEIVED/
    // PREPARING/IN_DELIVERY/DELIVERED/CONFIRMED)은 PlatformOrder.status를 전이시키는 로직이 코드에
    // 없어 영구적으로 발생할 수 없는 값이라 제거한다(design.md §0-0 Finding 1/2, §2-3).
    private val adminStatusSummaryKeys = mapOf(
        "DEPOSIT_PENDING" to "depositPending",
        "PAYMENT_COMPLETED" to "paymentCompleted",
        "CANCELLED" to "cancelled"
    )

    /**
     * 어드민 주문 목록을 조회한다. (DL §15)
     * ERD 정규화 테이블 연동 — MyBatis(slave, 읽기전용 계정)로 `ord_order`(+`ord_order_item`)를 조회한다.
     * summary는 status를 제외한 조건(keyword+dateRange)으로 집계하고, 목록(list/count)은 status까지 포함한 조건으로 조회한다
     * — "상태별 요약 카드는 검색조건과 무관하게 전체 상태 분포를 보여주고, 목록만 선택한 상태로 좁힌다"는 의도된 설계.
     * (쿼리 WHERE 분기는 OrderMapper.xml의 listWhere/summaryWhere 참고)
     */
    fun getAdminOrders(filter: AdminOrderFilter): OrderListResponse {
        val page = validatePage(filter.page)
        val size = validateSize(filter.size)
        validateDateRange(filter.from, filter.to)

        val offset = (page - 1) * size
        val rows = orderMapper.selectList(filter.keyword, filter.status, filter.from, filter.to, offset, size)
        val totalCount = orderMapper.countList(filter.keyword, filter.status, filter.from, filter.to)
        val summary = buildAdminSummaryFromRows(orderMapper.selectStatusSummary(filter.keyword, filter.from, filter.to))

        // [backend-service-pattern 적용] 행마다 Port를 호출하면 N+1이 되므로, 이 페이지에 등장하는
        // memberId/vendorId를 모아 한 번씩만 배치 조회한다(MemberApi/VendorApi 배치 시그니처).
        // "제한적 서비스 가능(단순조회)" 유형 — customer/vendorName은 응답의 부가 정보라, 호출이 실패해도
        // 목록 전체를 막지 않고 빈 Map(전부 매핑표 밖 폴백 처리)으로 계속 진행한다(SKILL.md 참고).
        val memberNames = callWithFallback("MemberApi.getMemberNames") { memberApi.getMemberNames(rows.map { it.memberId }.distinct()) }
        val vendorNames = callWithFallback("VendorApi.getVendorNames") { vendorApi.getVendorNames(rows.map { it.vendorId }.distinct()) }

        val pageOrders = rows.map {
            mapOf(
                "orderId" to it.orderId,
                "platformOrderNo" to it.platformOrderNo,
                // [order-platform-order-channel-redesign] admin 목록이 ord_platform_order 1건=1줄로
                // 전환되어, 대표(최소 order id) 상품명/vendor명을 "대표 외 N건/곳"으로 가공한다.
                "productName" to formatRepresentative(it.productName, it.itemCount, "건"),
                // 매핑표에 없는 memberId/vendorId는 "비회원"/"미등록"만 보여주면 운영자가 원인을 추적할 수
                // 없으므로, 폴백 문자열에 원시 ID를 이어붙여 확인이 필요하다는 신호를 남긴다(사용자 결정).
                "customer" to (memberNames?.get(it.memberId) ?: "비회원${it.memberId}"),
                "vendorName" to formatRepresentative(
                    vendorNames?.get(it.vendorId) ?: "미등록${it.vendorId}", it.vendorCount, "곳"
                ),
                "status" to it.status,
                "amount" to it.amount,
                "orderDate" to it.orderDate
            )
        }

        return OrderListResponse(
            orders = pageOrders,
            summary = summary,
            pagination = buildPagination(page, size, totalCount)
        )
    }

    /**
     * count가 2 이상이면 "{대표값} 외 {count-1}건/곳"으로, 1건이면 대표값 그대로 반환한다. (완전 신규)
     * "나이키 페가수스 41 외 2건" 포맷은 `DN-화면레이아웃/mobile.md`에 이미 존재하는 표기 관례를 재사용한
     * 것이다(design.md §3-1) — 완전 신규 포맷을 만들지 않았다.
     */
    private fun formatRepresentative(representative: String, count: Int, unit: String): String =
        if (count > 1) "$representative 외 ${count - 1}$unit" else representative

    /** 판매자(자기 매장) 주문 목록을 조회한다. (DL §22) summary 없음 — admin과 달리 상태별 집계 카드가 화면에 없다. */
    fun getPartnerOrders(vendorId: String, filter: PartnerOrderFilter): OrderListResponse {
        val page = validatePage(filter.page)
        val size = validateSize(filter.size)
        validateDateRange(filter.from, filter.to)

        // vendorId: 이번 프로토타입은 mock 데이터셋이 이미 '해당 판매자 주문만'이라는 전제라
        // 실제 필터링에는 쓰지 않는다 — 향후 실 DB 연동 시 WHERE vendor_id = :vendorId로 자리 표시(placeholder)
        val allOrders = loadPartnerOrderDataset()
        val sharedFiltered = applySharedFilters(allOrders, filter.keyword, filter.from, filter.to)
        val listFiltered = sharedFiltered.filter { matchesStatus(it, filter.status) }
        val sorted = sortByOrderDateDesc(listFiltered)
        val pageOrders = selectPage(sorted, page, size)
        val totalCount = countFiltered(sorted)

        return OrderListResponse(
            orders = pageOrders,
            summary = null,
            pagination = buildPagination(page, size, totalCount)
        )
    }

    /**
     * 로그인한 본인(me)의 주문 목록을 조회한다. (DL §11)
     * [order-platform-order-channel-redesign] Mock 고정 응답에서 DB 조회로 전환 —
     * findByMemberIdOrderByOrderedAtDesc로 로그인 회원의 PlatformOrder 전체를 최신순으로 가져와
     * admin과 동일한 "대표+외N건" 포맷으로 가공한다.
     */
    fun getMyOrders(memberId: Long): Map<String, Any> {
        val platformOrders = platformOrderRepository.findByMemberIdOrderByOrderedAtDesc(memberId)
            .filter { it.status != TEMP_STATUS } // 주문서 진입 임시주문 제외
        val orders = platformOrders.map { buildMyOrderRow(it) }
        return mapOf("code" to "SUCCESS", "data" to mapOf("totalCount" to orders.size, "orders" to orders))
    }

    /**
     * PlatformOrder 1건을 mobile 목록의 orders[] 1개 항목으로 변환한다. (완전 신규)
     * findByMemberIdOrderByOrderedAtDesc가 fetch join을 쓰지 않아 po.orders/items 접근이 LAZY 쿼리를
     * 유발한다(design.md §2-1 기록) — 목록 건수가 보통 적어 이번 라운드는 이 N+1을 허용한다(design.md §7).
     */
    private fun buildMyOrderRow(po: PlatformOrder): Map<String, Any?> {
        val firstOrder = po.orders.minByOrNull { it.id }
        val items = firstOrder?.items ?: emptyList()
        val firstItem = items.minByOrNull { it.id }
        val itemCount = po.orders.sumOf { it.items.size }
        return mapOf(
            "orderId" to po.id.toString(),
            "platformOrderNo" to po.platformOrderNo,
            "productName" to formatRepresentative(firstItem?.productName ?: "", itemCount, "건"),
            "imageUrl" to placeholderImageUrl(firstItem?.productName ?: ""),
            "optionName" to listOfNotNull(firstItem?.option1Value, firstItem?.option2Value).joinToString(" / "),
            "quantity" to (firstItem?.quantity ?: 0),
            "amount" to po.totalOrderAmount, // 주문금액(고객 목록의 금액)
            "status" to po.status,
            "statusLabel" to (MyOrderStatusLabel.of(po.status) ?: po.status),
            "orderDate" to po.orderedAt.toLocalDate().toString()
        )
    }

    /**
     * OrderItem에는 이미지 URL 컬럼이 없다(ERD에 없음, Catalog 도메인 책임 — Catalog Port 연동은 work-scope상
     * 이번 Order 작업 범위를 벗어난다). 기존 Mock(mobile__GET_my_orders.json)이 쓰던
     * `https://placehold.co/80x80/f5f5f5/333?text={텍스트}` 포맷은 유지하지만, 실제 상품명을 그대로
     * URL 인코딩해 text 파라미터에 넣는다 — placehold.co는 UTF-8 쿼리 텍스트를 지원하므로 한글 상품명도
     * 그대로 렌더링된다. (완전 신규 함수)
     */
    private fun placeholderImageUrl(productName: String): String {
        val encoded = java.net.URLEncoder.encode(productName.take(10), Charsets.UTF_8)
        return "https://placehold.co/80x80/f5f5f5/333?text=$encoded"
    }

    /**
     * 장바구니 선택 상품으로 주문서를 생성한다. (DL §5)
     * [order-create-mobile-api] 기존 Mock 반환 로직은 그대로 두고, `data.order_sheet_id`만 UUID 기반 신규 값으로
     * 덮어써서 반환한다 — DB INSERT 없음, 메서드 호출마다 새 값을 생성해 응답에만 담는 순수 계산(design.md §1-1).
     * 이 값은 FE가 들고 있다가 결제 버튼 클릭 시 placeOrder()의 path parameter(sheetId)로 그대로 돌려보낸다.
     */
    @Suppress("UNCHECKED_CAST")
    fun createOrderSheet(memberId: Long, request: OrderSheetRequest): Map<String, Any> {
        validateSheetItems(request.items)

        // 주문서 진입 = 임시주문(TEMP) 생성. 선택 상품은 vendor별 Order/OrderItem(TEMP)까지 저장하고, 배송지는 기본 배송지
        // placeholder(ERD NOT NULL 충족)로 둔다 — 주문서 화면은 이후 이 저장값을 읽어 그린다(getOrderSheet).
        // order_sheet_id는 임시주문의 platformOrderNo다 — placeOrder가 이 값으로 임시주문을 이어받는다.
        val now = LocalDateTime.now()
        val addresses = mockLoader.load("order", MockFile.MY_ORDER_SHEET).let {
            ((it["data"] as Map<String, Any>)["addresses"] as? List<Map<String, Any>>) ?: emptyList()
        }
        val defaultAddressId = (addresses.firstOrNull { it["is_default"] == true } ?: addresses.firstOrNull())
            ?.get("address_id")?.let { (it as Number).toLong() }
        val address = OrderAddressMock.resolve(mockLoader, defaultAddressId)
            ?: throw BadRequestException("ADDRESS_REQUIRED", "배송지를 선택해주세요", "주문서 기본 배송지 없음")
        val totalItemAmount = request.items.sumOf { BigDecimal(it.priceSale).multiply(BigDecimal(it.quantity)) }
        val tempOrder = platformOrderRepository.save(
            PlatformOrder(
                platformOrderNo = nextPlatformOrderNo(now), memberId = memberId, status = TEMP_STATUS,
                totalItemAmount = totalItemAmount, totalDiscountAmount = BigDecimal.ZERO,
                totalShippingAmount = BigDecimal.ZERO, pointUsedAmount = 0, paymentAmount = totalItemAmount, totalOrderAmount = totalItemAmount,
                receiverName = address.receiverName, receiverPhone = address.receiverPhone, zipcode = address.zipcode,
                address1 = address.address1, address2 = address.address2, deliveryMemo = null,
                orderedAt = now, createdAt = now, updatedAt = now, cartedAt = now
            )
        )

        // vendor별 Order(TEMP) + OrderItem(TEMP). orderNo는 플랫폼 주문번호 본문 + 판매자 주문 순번(01~)으로 채번한다.
        request.items.groupBy { it.vendorId }.entries.forEachIndexed { index, (vendorId, vendorItems) ->
            val itemAmount = vendorItems.sumOf { BigDecimal(it.priceSale).multiply(BigDecimal(it.quantity)) }
            val order = Order(
                orderNo = formatVendorOrderNo(tempOrder.platformOrderNo, index + 1), platformOrder = tempOrder, vendorId = vendorId,
                status = TEMP_STATUS, itemAmount = itemAmount, discountAmount = BigDecimal.ZERO,
                shippingFee = BigDecimal.ZERO, shippingFeePayer = "CUSTOMER", paymentAmount = itemAmount,
                claimLock = false, shippingDeadline = null, confirmedAt = null, createdAt = now, updatedAt = now,
                isDeleted = false, deletedAt = null, deletedBy = null
            )
            vendorItems.forEach { order.items.add(buildOrderItem(it, order, tempOrder.id, now, TEMP_STATUS)) }
            tempOrder.orders.add(order)
        }
        platformOrderRepository.save(tempOrder)

        statusHistoryService.record(tempOrder.id, StatusTargetType.ORDER, null, TEMP_STATUS,
            targetId = tempOrder.id, changedBy = "CUSTOMER", reason = "주문서 진입, 임시주문 생성", at = now)

        return buildOrderSheetResponse(tempOrder)
    }

    /** 주문서(임시주문)를 다시 조회한다 — 새로고침/재진입 시 새 임시주문을 만들지 않고 저장된 값을 그대로 그린다. */
    fun getOrderSheet(memberId: Long, sheetId: String): Map<String, Any> =
        buildOrderSheetResponse(loadTempOrder(memberId, sheetId))

    /** sheetId(=platformOrderNo)로 임시주문을 찾는다. 없으면 404, 타인 주문서 403, 이미 진행된 주문서 422. */
    private fun loadTempOrder(memberId: Long, sheetId: String): PlatformOrder {
        val platformOrder = platformOrderRepository.findByPlatformOrderNo(sheetId)
            ?: throw NotFoundException("ORDER_SHEET_NOT_FOUND", "주문서를 찾을 수 없습니다", "sheetId=$sheetId")
        if (platformOrder.memberId != memberId) {
            throw ForbiddenException("ORDER_SHEET_FORBIDDEN", "본인의 주문서가 아닙니다", "sheetId=$sheetId")
        }
        if (platformOrder.status != TEMP_STATUS) {
            throw UnprocessableException("ORDER_SHEET_ALREADY_PROCESSED", "이미 결제가 진행된 주문서입니다", "sheetId=$sheetId, status=${platformOrder.status}")
        }
        return platformOrder
    }

    /**
     * 주문서 응답 — 상품(orders[])과 금액요약(price_summary)은 임시주문 저장값에서, 배송지/쿠폰/포인트/결제수단/약관/
     * 주문자는 기존 주문서 Mock에서 가져온다(해당 도메인 영속화는 범위 밖).
     */
    @Suppress("UNCHECKED_CAST")
    private fun buildOrderSheetResponse(po: PlatformOrder): Map<String, Any> {
        val loaded = mockLoader.load("order", MockFile.MY_ORDER_SHEET)
        val data = (loaded["data"] as Map<String, Any>).toMutableMap()
        val vendorIds = po.orders.map { it.vendorId }.distinct()
        val vendorNames = callWithFallback("VendorApi.getVendorNames") { vendorApi.getVendorNames(vendorIds.map { it.toString() }) }
        data["order_sheet_id"] = po.platformOrderNo
        data["orders"] = po.orders.sortedBy { it.id }.map { order ->
            mapOf(
                "vendor_id" to order.vendorId,
                "vendor_name" to (vendorNames?.get(order.vendorId.toString()) ?: "미등록${order.vendorId}"),
                "items" to order.items.sortedBy { it.id }.map { item ->
                    mapOf(
                        "product_id" to item.productId,
                        "product_name" to item.productName,
                        "image_url" to placeholderImageUrl(item.productName),
                        "color" to (item.option1Value ?: ""),
                        "size" to (item.option2Value ?: ""),
                        "price_sale" to item.priceSale.toInt(),
                        "quantity" to item.quantity
                    )
                }
            )
        }
        // 주문서에서 적용한 쿠폰/포인트는 임시주문에 영속돼 있다 — 재진입/새로고침 시 그대로 복원한다.
        data["selected_coupon_id"] = po.discounts.firstOrNull { !it.isRevoked }?.couponCode ?: "" // 미적용은 빈 문자열
        data["point_used"] = po.pointUsedAmount
        data["price_summary"] = mapOf(
            "total_product_price" to po.totalItemAmount.toInt(), "product_discount" to 0, "cart_discount" to 0,
            "coupon_discount" to -po.totalDiscountAmount.toInt(), "point_used" to po.pointUsedAmount,
            "shipping_fee" to po.totalShippingAmount.toInt(), "order_amount" to po.totalOrderAmount.toInt(),
            "total_payment" to po.paymentAmount.toInt() // total_payment = 결제금액(주문금액 − 포인트)
        )
        return loaded.toMutableMap().apply { this["data"] = data }
    }

    /**
     * 주문서에서 쿠폰/포인트를 적용(또는 해제)하고 임시주문에 영속한다. couponId=null이면 쿠폰 해제, pointUsed=0이면 포인트 해제.
     * 검증 실패(COUPON_NOT_APPLICABLE/POINT_EXCEED)면 기존 영속값은 그대로 유지된다(트랜잭션 롤백).
     */
    fun applyOrderSheetDiscount(memberId: Long, sheetId: String, request: OrderSheetDiscountRequest): Map<String, Any> {
        if ((request.pointUsed ?: 0) < 0) {
            throw BadRequestException("INVALID_ITEM_PRICE", "사용 포인트는 0 이상이어야 합니다", "pointUsed=${request.pointUsed}")
        }
        val platformOrder = loadTempOrder(memberId, sheetId)
        val items = tempOrderItems(platformOrder)
        val now = LocalDateTime.now()
        applyDiscountToTempOrder(memberId, platformOrder, items, request.couponId, request.pointUsed ?: 0, now)
        platformOrder.updatedAt = now
        platformOrderRepository.save(platformOrder)
        return buildOrderSheetResponse(platformOrder)
    }

    private fun tempOrderItems(platformOrder: PlatformOrder): List<OrderItemRequest> =
        platformOrder.orders.sortedBy { it.id }.flatMap { order ->
            order.items.sortedBy { it.id }.map {
                OrderItemRequest(
                    vendorId = order.vendorId, productId = it.productId, skuId = it.skuId, productName = it.productName,
                    priceOriginal = it.priceOriginal.toInt(), priceSale = it.priceSale.toInt(), quantity = it.quantity
                )
            }
        }

    /**
     * 쿠폰/포인트를 검증하고 임시주문에 반영한다: 쿠폰 할인 행(ord_platform_order_discount)을 교체(없으면 제거)하고
     * totalDiscountAmount/pointUsedAmount/paymentAmount를 갱신한다. 반환값은 쿠폰 할인액.
     * platformShare/vendorShare는 PlatformOrderDiscount 기본값(0/0) — 분담 정책 미확정(design.md §3).
     */
    private fun applyDiscountToTempOrder(
        memberId: Long, platformOrder: PlatformOrder, items: List<OrderItemRequest>,
        couponId: String?, pointUsedAmount: Int, now: LocalDateTime
    ): BigDecimal {
        val totalItemAmount = platformOrder.totalItemAmount
        validatePointUsage(memberId, pointUsedAmount)
        val totalDiscountAmount = BigDecimal(validateCouponIfPresent(memberId, couponId, items, totalItemAmount))
        validatePointNotExceedingPayableAmount(pointUsedAmount, totalItemAmount, totalDiscountAmount)

        platformOrder.discounts.clear()
        if (couponId != null) {
            platformOrder.discounts.add(
                PlatformOrderDiscount(
                    platformOrder = platformOrder, discountType = "ORDER_COUPON", promotionId = null,
                    couponCode = couponId, discountAmount = totalDiscountAmount, createdAt = now, updatedAt = now
                )
            )
        }
        platformOrder.totalDiscountAmount = totalDiscountAmount
        platformOrder.pointUsedAmount = pointUsedAmount
        // 주문금액 = 상품금액 − 할인금액 + 배송비(− 배송비 할인금액, 미구현), 결제금액 = 주문금액 − 포인트
        platformOrder.totalOrderAmount = totalItemAmount.subtract(totalDiscountAmount).add(platformOrder.totalShippingAmount)
        platformOrder.paymentAmount = platformOrder.totalOrderAmount.subtract(BigDecimal(pointUsedAmount))
        return totalDiscountAmount
    }

    /**
     * 주문서(orderSheetId)의 결제를 확정해 플랫폼주문/주문/주문상품을 생성한다. (DL §6)
     *
     * `sheetId`는 주문서 진입 시 createOrderSheet()가 만든 임시주문(TEMP)의 platformOrderNo다 — placeOrder는
     * 이 임시주문을 찾아(없으면 404, 타인 주문서 403, 이미 진행된 주문서 422) 확정 값으로 갱신하고 vendor 주문을
     * 생성한다. (2026-10-26 변경: 기존 "sheetId로 서버 조회를 하지 않는 stateless" 제약을 폐기)
     *
     * ① validation(아래 1단계) ② execute(2~9단계: Port 호출 + Entity 생성·저장) ③ dto convert(10단계)
     * 순서로 구성한다(design.md §5). `@Transactional`(클래스 레벨)이 2단계 저장(6-2/7)을 하나의 트랜잭션으로
     * 묶어, 6-3(Entity 생성)에서 예외가 나도 6-2의 INSERT까지 함께 롤백된다(design.md §3-1·§4-2 Finding A).
     */
    fun placeOrder(memberId: Long, sheetId: String, request: PayRequest): PayResponse {
        // ① validation
        validatePayRequest(request)

        // ② execute — 임시주문 로드. 상품은 요청 바디가 아니라 주문서 진입 시 저장된 임시주문(DB)에서 읽는다.
        val platformOrder = loadTempOrder(memberId, sheetId)
        val items = tempOrderItems(platformOrder)
        validateSheetItems(items)

        // ② execute — 합산 공식(design.md §4-2) 중 totalItemAmount는 포인트의 "할인 후 금액 초과" 검증에
        // 먼저 필요해 포인트/쿠폰 검증보다 앞으로 끌어온다(review.json Finding 1 반영, items만으로 계산 가능).
        val totalItemAmount = items.sumOf { BigDecimal(it.priceSale).multiply(BigDecimal(it.quantity)) }

        // ② execute — 쿠폰/포인트: 주문서에서 적용해 임시주문에 영속된 값을 결제 시점에 재검증한다(요청 바디의 couponId/pointUsed는 무시).
        val appliedCouponCode = platformOrder.discounts.firstOrNull { !it.isRevoked }?.couponCode
        val now = LocalDateTime.now()
        val totalDiscountAmount = applyDiscountToTempOrder(memberId, platformOrder, items, appliedCouponCode, platformOrder.pointUsedAmount, now)
        val pointUsedAmount = platformOrder.pointUsedAmount

        // ② execute — 배송지 변환
        val resolvedAddress = OrderAddressMock.resolve(mockLoader, request.addressId)
            ?: throw BadRequestException("ADDRESS_REQUIRED", "배송지를 선택해주세요", "addressId=${request.addressId}")

        // ② execute — 합산 공식(design.md §4-2 "합산 공식 전체 정리")
        val totalShippingAmount = BigDecimal.ZERO
        // 주문금액 = 상품금액 − 할인금액 + 배송비(− 배송비 할인금액, 미구현), 결제금액 = 주문금액 − 포인트
        val totalOrderAmount = totalItemAmount.subtract(totalDiscountAmount).add(totalShippingAmount)
        val paymentAmount = totalOrderAmount.subtract(BigDecimal(pointUsedAmount))

        // ② execute — 임시주문(TEMP)을 확정 값으로 갱신(이미 영속). vendor 주문/상품은 주문서 진입 때 생성돼 있으므로 상태만 바꾼다.
        val previousStatus = platformOrder.status
        platformOrder.status = STOCK_REQUESTED_STATUS
        platformOrder.totalItemAmount = totalItemAmount
        platformOrder.totalShippingAmount = totalShippingAmount
        platformOrder.totalOrderAmount = totalOrderAmount
        platformOrder.paymentAmount = paymentAmount
        platformOrder.receiverName = resolvedAddress.receiverName
        platformOrder.receiverPhone = resolvedAddress.receiverPhone
        platformOrder.zipcode = resolvedAddress.zipcode
        platformOrder.address1 = resolvedAddress.address1
        platformOrder.address2 = resolvedAddress.address2
        platformOrder.orderedAt = now
        platformOrder.updatedAt = now
        platformOrder.orders.forEach { order ->
            order.status = STOCK_REQUESTED_STATUS
            order.items.forEach { it.status = STOCK_REQUESTED_STATUS }
        }

        // ② execute — 7. 저장(cascade로 ord_platform_order_discount INSERT, 갱신된 주문/상품 UPDATE)
        platformOrderRepository.save(platformOrder)

        // ② execute — 8. 재고차감 요청을 아웃박스에 적재(주문 상태 변경과 같은 트랜잭션). 실제 차감은 컨슈머(OrderEventConsumer)가
        // 상품 API(CatalogApi.deductStock)로 비동기 처리하고, 차감 성공 후에야 PG 결제요청(PaymentApi.requestPayment)이 진행된다.
        outboxEventRepository.save(
            OutboxEvent(eventType = OutboxEventType.STOCK_DEDUCT_REQUESTED, platformOrderId = platformOrder.id, payload = request.paymentMethodType)
        )

        // ② execute — 9. 상태전이 이력 기록(같은 트랜잭션). 결제완료까지(주문 생성·결제)는 플랫폼주문 단위로 기록한다
        // (orderId=null, targetId=platformOrder.id). 배송/클레임 전이는 vendor 주문(ord_order) 단위로 기록한다(생성 시점엔 없음).
        statusHistoryService.record(platformOrder.id, StatusTargetType.ORDER, previousStatus, platformOrder.status,
            targetId = platformOrder.id, changedBy = "CUSTOMER", reason = "주문 접수, 재고차감 요청", at = now)
        // 이후 상태(STOCK_DEDUCTED/STOCK_FAILED/DEPOSIT_PENDING)와 결제상태(PG 요청/수신) 이력은 컨슈머와 Payment 도메인이 기록한다.

        // ③ dto convert — 10. 응답 반환
        // orderId는 대표 vendor Order 1건만 가리킨다(design.md §2 결정, 표시용) — 후속 네비게이션은 platformOrderId를 쓴다.
        // platformOrderNo는 목록/상세(getAdminOrders 등)가 "주문번호"로 노출하는 것과 동일한 포맷 문자열(P-yyMMdd-NNNNN-00)
        // 이다 — 화면의 "주문번호" 표시는 이 필드를 쓴다(PayResponse.kt KDoc 참조).
        return PayResponse(
            platformOrderId = platformOrder.id.toString(),
            platformOrderNo = platformOrder.platformOrderNo,
            orderId = platformOrder.orders.first().id.toString(),
            totalOrderAmount = platformOrder.totalOrderAmount,
            totalPayment = platformOrder.paymentAmount,
            status = STOCK_REQUESTED_STATUS,
            message = "주문이 접수되었습니다. 재고 확인 후 결제가 진행됩니다"
        )
    }

    /**
     * 어드민이 특정 주문(플랫폼 단위)의 상세를 조회한다. (DL §16)
     * [order-platform-order-channel-redesign] orderId는 이제 PlatformOrder.id를 가리킨다(design.md §1).
     * orders만 fetch join(PlatformOrderRepository.findDetailById)하고 orders.items/delivery/claims는
     * 접근 시 LAZY 로딩(vendor order 수만큼 N+1, design.md §7 기록).
     * [backend-service-pattern 적용] — 이 메서드 코드 안에 Payment/Member/Vendor의 Mock 경로/테이블명을
     * 직접 언급하지 않는다. history/inquiries/logs(ord_platform_order 세부 테이블 미생성, 범위 밖)는
     * 기존처럼 admin 상세 Mock 파일(admin__GET_orders_{order_id}.json)에서 가져와 병합한다.
     */
    fun getAdminOrderDetail(orderId: String): Map<String, Any> {
        val id = orderId.toLongOrNull()
            ?: throw BadRequestException("INVALID_ORDER_ID", "orderId는 숫자여야 합니다", "입력값: $orderId")
        val platformOrder = platformOrderRepository.findDetailById(id)
            ?: throw NotFoundException("ORDER_NOT_FOUND", "주문을 찾을 수 없습니다", "orderId=$orderId")

        val mockDetail = mockLoader.load("order", MockFile.ADMIN_ORDER_DETAIL)["data"] as? Map<String, Any> ?: emptyMap()
        val payment = paymentApi.getPaymentInfo(platformOrder.id.toString())

        // 플랫폼주문에 속한 vendor order들의 vendorId를 모아 한 번만 배치 조회(getAdminOrders()와 동일 패턴)
        val vendorIds = platformOrder.orders.map { it.vendorId }.distinct()
        val vendorNames = callWithFallback("VendorApi.getVendorNames") { vendorApi.getVendorNames(vendorIds.map { it.toString() }) }
        fun vendorNameOf(vendorId: Long): String = vendorNames?.get(vendorId.toString()) ?: "미등록$vendorId"

        val representativeVendorId = platformOrder.orders.minByOrNull { it.id }?.vendorId
        val vendorGroups = platformOrder.orders.map { order -> buildAdminVendorGroup(order, ::vendorNameOf) }
        val allClaims = platformOrder.orders.flatMap { it.claims }
            .map { claim -> buildClaimMap(claim, vendorNameOf(claim.order.vendorId)) }

        val data = mapOf(
            "orderId" to platformOrder.id.toString(),
            "platformOrderNo" to platformOrder.platformOrderNo,
            "status" to platformOrder.status, // 플랫폼 자신의 status 그대로(design.md §4-5 결정)
            "customer" to (callWithFallback("MemberApi.getMemberName") { memberApi.getMemberName(platformOrder.memberId.toString()) } ?: "비회원${platformOrder.memberId}"),
            "vendorName" to formatRepresentative(
                representativeVendorId?.let(::vendorNameOf) ?: "미등록", vendorIds.size, "곳"
            ),
            "amount" to platformOrder.totalOrderAmount, // 주문금액(어드민 목록·상세 헤더의 금액)
            "orderAmount" to platformOrder.totalOrderAmount,
            "paymentAmount" to platformOrder.paymentAmount, // 결제금액(주문금액 − 포인트, PG 결제분)
            "productAmount" to platformOrder.totalItemAmount, // 신규 — getMyOrderDetail() payment.productAmount와 동일 이름 재사용(상품금액)
            "shippingFee" to platformOrder.totalShippingAmount, // 신규 — 동일 이유로 기존 이름 재사용(배송비)
            "productDiscount" to BigDecimal.ZERO, // 신규 — 고정 0, getMyOrderDetail()과 동일 패턴(현재 데이터 모델에 상품별 할인 컬럼 없음, report.md §5)
            "cartDiscount" to platformOrder.totalDiscountAmount, // 신규 — 기존 이름 재사용, 단 getMyOrderDetail()의 .negate()와 달리 양수 그대로(FE가 "-" 리터럴 부여)
            "pointUsedAmount" to platformOrder.pointUsedAmount, // 완전 신규 식별자 — PlatformOrder.pointUsedAmount 엔티티 필드명 그대로 재사용
            "orderDate" to platformOrder.orderedAt.format(ORDER_DATE_FORMAT),
            "items" to vendorGroups, // vendor별 그룹 구조(design.md §3-2-1)
            "payment" to mapOf(
                "method" to payment.method,
                "pgProvider" to payment.pgProvider,
                "transactionId" to payment.transactionId,
                "paidAt" to payment.paidAt
            ),
            "shipping" to mapOf( // vendor별 배송 섹션(design.md §3-2-2)
                "recipientName" to platformOrder.receiverName,
                "phone" to platformOrder.receiverPhone,
                "address" to "[${platformOrder.zipcode}] ${platformOrder.address1}${platformOrder.address2?.let { " $it" } ?: ""}",
                "memo" to platformOrder.deliveryMemo,
                "deliveries" to platformOrder.orders.map { buildAdminDeliveryMap(it, ::vendorNameOf) }
            ),
            "claims" to allClaims, // vendorName 필드 추가(아래 buildClaimMap)
            // history는 ord_status_history 영속 데이터, inquiries/logs는 ERD 범위 밖 — Mock 유지
            "history" to statusHistoryService.findByPlatformOrderId(platformOrder.id).map(::buildHistoryMap),
            "inquiries" to (mockDetail["inquiries"] ?: emptyList<Any>()),
            "logs" to (mockDetail["logs"] ?: emptyList<Any>())
        )
        return mapOf("code" to "SUCCESS", "data" to data)
    }

    /** 상태전이 이력 1건 — targetType(ORDER/PAYMENT/DELIVERY/CLAIM)으로 어떤 상태가 바뀌었는지 구분한다. */
    private fun buildHistoryMap(h: StatusHistoryRow): Map<String, Any?> = mapOf(
        "targetType" to h.targetType,
        "fromStatus" to h.fromStatus,
        "toStatus" to h.toStatus,
        "changedBy" to h.changedBy,
        "reason" to h.reason,
        "createdAt" to h.createdAt
    )

    /** admin 상세 items[] 1개 vendor 그룹 — mobile OrderItemGroup과 동일한 "vendorName+vendorStatus+products[]" 구조. (완전 신규) */
    private fun buildAdminVendorGroup(order: Order, vendorNameOf: (Long) -> String): Map<String, Any> = mapOf(
        "vendorName" to vendorNameOf(order.vendorId),
        "vendorStatus" to order.status,
        "products" to order.items.map { buildItemMap(it) } // 기존 buildItemMap() 재사용, 변경 없음
    )

    /** vendor order 1건의 배송 정보를 shipping.deliveries[] 1개 항목으로 변환한다. (완전 신규) */
    private fun buildAdminDeliveryMap(order: Order, vendorNameOf: (Long) -> String): Map<String, Any?> = mapOf(
        "vendorName" to vendorNameOf(order.vendorId),
        "carrier" to DeliveryCompanyName.of(order.delivery?.deliveryCompanyId), // 기존 object 재사용, 변경 없음
        "trackingNumber" to order.delivery?.trackingNo,
        "shippedAt" to order.delivery?.shippedAt?.format(ORDER_DATE_FORMAT),
        "status" to order.status
    )

    /** OrderItem 1건을 상세 응답의 items[] 항목 Map으로 변환한다. */
    private fun buildItemMap(item: OrderItem): Map<String, Any> {
        val optionName = listOfNotNull(item.option1Value, item.option2Value).joinToString("/")
        return mapOf(
            "productName" to item.productName,
            "optionName" to optionName,
            "quantity" to item.quantity,
            "unitPrice" to item.priceSale,
            "subtotal" to item.priceSale.multiply(BigDecimal(item.quantity))
        )
    }

    /** Claim 1건을 상세 응답의 claims[] 항목 Map으로 변환한다. vendorName은 멀티 vendor 클레임 구분용(신규 필드). */
    private fun buildClaimMap(claim: Claim, vendorName: String): Map<String, Any?> = mapOf(
        "claimId" to claim.claimNo,
        "claimType" to claim.claimType,
        "status" to claim.status,
        "refundAmount" to claim.refundAmount,
        "extraShippingFee" to claim.extraDeliveryFee,
        "receivedAt" to claim.createdAt.format(ORDER_DATE_FORMAT),
        "vendorName" to vendorName // 신규 필드 — admin ClaimTab.tsx "판매자" 컬럼(design.md §5-1)
    )

    /**
     * 판매자가 자기 매장의 특정 주문 상세를 조회한다. (DL §23)
     * [order-platform-order-channel-redesign] Mock 고정 응답에서 DB 조회로 전환. 자기 vendor 주문(myItems,
     * 기존과 동일한 전체 필드)과, 같은 플랫폼주문에 속한 타 vendor 상품(otherVendorItems, 상품명/수량/금액
     * 3필드만 — 사용자 결정)을 구분해 반환한다. 본인 매장 소유 검증(vendorId 불일치 시 403)을 포함한다.
     */
    fun getPartnerOrderDetail(vendorId: Long, orderId: String): Map<String, Any> {
        val id = orderId.toLongOrNull()
            ?: throw BadRequestException("INVALID_ORDER_ID", "orderId는 숫자여야 합니다", "입력값: $orderId")
        val order = orderRepository.findDetailById(id)
            ?: throw NotFoundException("ORDER_NOT_FOUND", "주문을 찾을 수 없습니다", "orderId=$orderId")
        if (order.vendorId != vendorId) {
            throw ForbiddenException("FORBIDDEN", "본인 매장 주문만 조회할 수 있습니다", "orderId=$orderId, vendorId=$vendorId")
        }

        val siblingOrders = orderRepository.findSiblingOrdersWithItems(order.platformOrder.id, vendorId)
        val otherVendorItems = siblingOrders.flatMap { it.items }.map {
            mapOf(
                "productName" to it.productName,
                "quantity" to it.quantity,
                "amount" to it.priceSale.multiply(BigDecimal(it.quantity))
            ) // 상품명/수량/금액 3개 필드만 — 상태/vendor명 등은 비노출(사용자 결정)
        }

        val data = mapOf(
            "orderId" to order.id.toString(),
            "platformOrderNo" to order.platformOrder.platformOrderNo,
            "status" to order.status,
            "productName" to (order.items.firstOrNull()?.productName ?: ""),
            "customerName" to (callWithFallback("MemberApi.getMemberName") { memberApi.getMemberName(order.platformOrder.memberId.toString()) } ?: "비회원${order.platformOrder.memberId}"),
            "quantity" to order.items.sumOf { it.quantity },
            "amount" to order.paymentAmount,
            "orderDate" to order.createdAt.format(ORDER_DATE_FORMAT),
            "myItems" to order.items.map { buildItemMap(it) }, // 신규 필드 — "내 상품"(기존 buildItemMap 재사용)
            "otherVendorItems" to otherVendorItems, // 신규 필드 — "타 vendor 상품"(3필드만)
            "history" to loadPartnerHistoryMock(orderId)
        )
        return mapOf("code" to "SUCCESS", "data" to data)
    }

    /**
     * partner 상세의 history는 ERD 범위 밖(ord_platform_order 세부 테이블 미생성)이라 기존처럼 Mock 그대로
     * 유지한다. (완전 신규 헬퍼, 기존 패턴 통일) orderId는 호출부(getPartnerOrderDetail)와 시그니처 일관성을
     * 위해 받지만, PARTNER_ORDER_DETAIL Mock이 고정 1건이라 본문에서 사용하지 않는다(기존
     * getPartnerOrderDetail()도 동일한 제약이었음 — orderId 무관 고정 Mock을 반환했음).
     */
    @Suppress("UNCHECKED_CAST")
    private fun loadPartnerHistoryMock(orderId: String): List<Any> {
        val mockDetail = mockLoader.load("order", MockFile.PARTNER_ORDER_DETAIL)["data"] as? Map<String, Any> ?: emptyMap()
        return (mockDetail["history"] as? List<Any>) ?: emptyList()
    }

    /**
     * 로그인한 본인(me)의 주문 상세를 조회한다. 판매자별 상품·결제정보·배송정보·주문이력을 포함한다. (DL §30)
     * [order-platform-order-channel-redesign] Mock 고정 응답에서 DB 조회로 전환. mobile 채널의
     * "본인 소유 리소스"는 memberId 불일치 시 403을 반환해야 한다(api-design-rules.md "mobile /my 리소스"
     * 규칙) — orderId를 바꿔가며 타인의 배송지·결제 정보를 열람하는 IDOR을 방지한다.
     */
    fun getMyOrderDetail(memberId: Long, orderId: String): Map<String, Any> {
        val id = orderId.toLongOrNull()
            ?: throw BadRequestException("INVALID_ORDER_ID", "orderId는 숫자여야 합니다", "입력값: $orderId")
        val platformOrder = platformOrderRepository.findDetailById(id)
            ?: throw NotFoundException("ORDER_NOT_FOUND", "주문을 찾을 수 없습니다", "orderId=$orderId")
        if (platformOrder.memberId != memberId) {
            throw ForbiddenException("FORBIDDEN", "본인 주문만 조회할 수 있습니다", "orderId=$orderId, memberId=$memberId")
        }

        val mockDetail = mockLoader.load("order", MockFile.MY_ORDER_DETAIL)["data"] as? Map<String, Any> ?: emptyMap()
        val payment = paymentApi.getPaymentInfo(platformOrder.id.toString())

        val vendorIds = platformOrder.orders.map { it.vendorId }.distinct()
        val vendorNames = callWithFallback("VendorApi.getVendorNames") { vendorApi.getVendorNames(vendorIds.map { it.toString() }) }
        val itemGroups = platformOrder.orders.map { order ->
            buildMyOrderItemGroup(order, vendorNames?.get(order.vendorId.toString()) ?: "미등록${order.vendorId}")
        }

        val representativeOrder = platformOrder.orders.minByOrNull { it.id }
        val data = mapOf(
            "orderId" to platformOrder.id.toString(),
            "platformOrderNo" to platformOrder.platformOrderNo,
            "status" to platformOrder.status,
            "orderDate" to platformOrder.orderedAt.format(ORDER_DATE_FORMAT),
            "items" to itemGroups,
            "payment" to mapOf(
                "productAmount" to platformOrder.totalItemAmount,
                "productDiscount" to BigDecimal.ZERO, // 상품별 개별 할인 미연동(design.md §7 기록)
                "cartDiscount" to platformOrder.totalDiscountAmount.negate(),
                "shippingFee" to platformOrder.totalShippingAmount,
                "orderAmount" to platformOrder.totalOrderAmount,
                "pointUsedAmount" to platformOrder.pointUsedAmount,
                "paymentAmount" to platformOrder.paymentAmount,
                "totalAmount" to platformOrder.paymentAmount, // 하위호환 — paymentAmount와 같은 값(결제금액)
                "method" to payment.method,
                "paidAt" to payment.paidAt
            ),
            "shipping" to mapOf(
                "recipientName" to platformOrder.receiverName,
                "phone" to platformOrder.receiverPhone,
                "address" to "[${platformOrder.zipcode}] ${platformOrder.address1}${platformOrder.address2?.let { " $it" } ?: ""}",
                "memo" to platformOrder.deliveryMemo,
                "carrier" to DeliveryCompanyName.of(representativeOrder?.delivery?.deliveryCompanyId),
                "trackingNumber" to representativeOrder?.delivery?.trackingNo,
                "deliveryStatus" to (MyOrderStatusLabel.of(representativeOrder?.status ?: platformOrder.status) ?: platformOrder.status)
            ),
            "history" to (mockDetail["history"] ?: emptyList<Any>()) // ERD 범위 밖 — Mock 유지(변경 없음)
        )
        return mapOf("code" to "SUCCESS", "data" to data)
    }

    /** admin buildAdminVendorGroup과 같은 구조이나 mobile 전용 필드(imageUrl/claimableQuantity)를 쓴다. (완전 신규) */
    private fun buildMyOrderItemGroup(order: Order, vendorName: String): Map<String, Any> = mapOf(
        "vendorName" to vendorName,
        "vendorStatus" to order.status,
        "products" to order.items.map { item ->
            mapOf(
                "productName" to item.productName,
                "imageUrl" to placeholderImageUrl(item.productName),
                "optionName" to listOfNotNull(item.option1Value, item.option2Value).joinToString("/"),
                "quantity" to item.quantity,
                "amount" to item.priceSale.multiply(BigDecimal(item.quantity)),
                "claimableQuantity" to item.quantity // 클레임 수량 차감 미연동 — design.md §7 기록(기존 Mock도 동일 단순화)
            )
        }
    )

    // ── 타 도메인 Port 호출 공용 헬퍼 (SKILL.md "제한적 서비스 가능(단순조회)" 유형) ──

    /**
     * "제한적 서비스 가능(단순조회)" 유형의 Port 호출을 감싼다. 호출이 실패해도 그 예외를 호출자에게
     * 전파하지 않고 null을 반환해 응답 전체를 막지 않는다(표시용 부가 정보이므로 "비회원"/"미등록" 등
     * 기존 폴백으로 계속 진행 가능). 실패를 조용히 삼키지 않고 `apiName`을 포함한 WARN 로그를 남겨,
     * 매핑표 밖이라 정상적으로 null인 경우와 호출 자체가 실패한 경우를 운영자가 구분할 수 있게 한다.
     */
    private fun <T> callWithFallback(apiName: String, call: () -> T): T? =
        try {
            call()
        } catch (e: Exception) {
            log.warn("타 도메인 Port 호출 실패 — $apiName, 폴백값으로 계속 진행: ${e.message}", e)
            null
        }

    // ── ① validation ──

    /** page는 1 이상이어야 한다. 위반 시 조용히 보정하지 않고 명시적으로 거부한다. */
    private fun validatePage(page: Int): Int {
        if (page < 1) {
            throw BadRequestException("INVALID_PAGE", "page는 1 이상이어야 합니다", "입력값: $page")
        }
        return page
    }

    /** size는 1~100 범위여야 한다 (전체 데이터셋을 한 번에 반환하는 과도한 요청을 방지). */
    private fun validateSize(size: Int): Int {
        if (size !in 1..100) {
            throw BadRequestException("INVALID_SIZE", "size는 1~100 사이여야 합니다", "입력값: $size")
        }
        return size
    }

    /** from/to가 둘 다 있으면 from <= to여야 한다. */
    private fun validateDateRange(from: String?, to: String?) {
        if (!from.isNullOrBlank() && !to.isNullOrBlank() && from > to) {
            throw BadRequestException("INVALID_DATE_RANGE", "from은 to보다 늦을 수 없습니다", "from=$from, to=$to")
        }
    }

    /**
     * placeOrder() 요청 바디의 형식 검증(design.md §1-2/§1-4). items 없음/빈 배열, 미동의 약관,
     * 지원하지 않는 결제수단, 수량/가격이 양수가 아닌 item, 음수 pointUsed를 각각 거부한다 — 조용히 보정하지 않는다.
     * (리뷰 발견: pointUsed가 음수면 paymentAmount 계산에서 할인처럼 작용해 결제금액이 오히려 커지는데도
     * validatePointUsage()는 pointUsedAmount<=0을 통과시켜 걸러지지 않았다 — 여기서 음수를 먼저 차단한다.)
     */
    /** 주문서 상품 검증 — 주문서 진입(임시주문 저장) 시와 결제하기(저장된 상품 재검증) 시 공통. */
    private fun validateSheetItems(items: List<OrderItemRequest>) {
        if (items.isEmpty()) {
            throw BadRequestException("CART_ITEMS_REQUIRED", "주문할 상품이 없습니다", "items가 비어있음")
        }
        if (items.any { it.quantity < 1 || it.priceOriginal < 0 || it.priceSale < 0 }) {
            throw BadRequestException("INVALID_ITEM_PRICE", "상품 수량/가격이 올바르지 않습니다", "items=$items")
        }
    }

    private fun validatePayRequest(request: PayRequest) {
        if (request.addressId == null) {
            throw BadRequestException("ADDRESS_REQUIRED", "배송지를 선택해주세요", "addressId가 없음")
        }
        val requiredTerms = setOf("T001", "T002", "T003")
        if (!requiredTerms.all { request.termsAgreed.contains(it) }) {
            throw BadRequestException("TERMS_NOT_AGREED", "필수 약관에 동의해주세요", "termsAgreed=${request.termsAgreed}")
        }
        if (request.paymentMethodType !in setOf("CARD", "EASY_PAY", "POINT", "VIRTUAL_ACCOUNT")) {
            throw BadRequestException(
                "INVALID_PAYMENT_METHOD", "지원하지 않는 결제수단입니다", "paymentMethodType=${request.paymentMethodType}"
            )
        }
        // 카드 결제는 작업중 — 현재 가상계좌만 진행한다(모바일 화면에서도 선택 시 안내하고 막지만 서버에서도 거절)
        if (request.paymentMethodType == "CARD") {
            throw BadRequestException(
                "PAYMENT_METHOD_NOT_READY", "카드 결제는 작업중입니다. 가상계좌로 결제해주세요", "paymentMethodType=CARD"
            )
        }
        if ((request.pointUsed ?: 0) < 0) {
            throw BadRequestException("INVALID_ITEM_PRICE", "사용 포인트는 0 이상이어야 합니다", "pointUsed=${request.pointUsed}")
        }
    }

    /** pointUsed가 MemberApi.getPointBalance() 잔액(Mock 15000)을 초과하면 422 POINT_EXCEED(DL §32-2 기존 식별자). */
    private fun validatePointUsage(memberId: Long, pointUsedAmount: Int) {
        if (pointUsedAmount <= 0) return
        val pointInfo = memberApi.getPointBalance(memberId.toString())
        if (pointUsedAmount > pointInfo.balance) {
            throw UnprocessableException("POINT_EXCEED", "사용 가능 포인트를 초과했습니다", "pointUsed=$pointUsedAmount, balance=${pointInfo.balance}")
        }
    }

    /**
     * pointUsed가 할인 후 금액(totalItemAmount - totalDiscountAmount)을 초과하면 422 POINT_EXCEED
     * (DL §32-2 기존 식별자 재사용 — "사용 가능 포인트를 초과했습니다"는 잔액 초과와 결제금액 초과를 모두 포괄).
     * (review.json Finding 1 반영: pointUsed가 포인트 잔액 이내여도 상품금액을 넘으면 paymentAmount가 음수가
     * 되어 DB에 그대로 저장되는 경로를 막는다 — validatePointUsage()의 잔액 검증과는 별도의 상한.)
     */
    private fun validatePointNotExceedingPayableAmount(pointUsedAmount: Int, totalItemAmount: BigDecimal, totalDiscountAmount: BigDecimal) {
        if (pointUsedAmount <= 0) return
        val payableAmount = totalItemAmount.subtract(totalDiscountAmount)
        if (BigDecimal(pointUsedAmount) > payableAmount) {
            throw UnprocessableException(
                "POINT_EXCEED", "사용 가능 포인트를 초과했습니다", "pointUsed=$pointUsedAmount, payableAmount=$payableAmount"
            )
        }
    }

    /**
     * couponId가 있으면 PromotionApi.validateCoupon()으로 검증하고 할인액을 반환한다.
     * applicable=false면 422 COUPON_NOT_APPLICABLE(DL §32-2 기존 식별자). couponId가 없으면 0(쿠폰 미적용).
     * [신규] discountAmount가 totalItemAmount를 초과하면(쿠폰 자체는 applicable=true여도) 같은
     * COUPON_NOT_APPLICABLE(422)로 거부한다 — POINT_EXCEED가 "잔액 초과"/"결제금액 초과" 두 원인을
     * 하나의 code로 묶은 전례(validatePointNotExceedingPayableAmount() 참고)와 동일한 재사용 결정
     * (order-placeorder-design-gaps/design.md §1).
     */
    private fun validateCouponIfPresent(memberId: Long, couponId: String?, items: List<OrderItemRequest>, totalItemAmount: BigDecimal): Int {
        if (couponId == null) return 0
        val checkItems = items.map {
            CouponCheckItem(productId = it.productId, skuId = it.skuId, priceSale = it.priceSale, quantity = it.quantity)
        }
        val result = promotionApi.validateCoupon(memberId.toString(), couponId, checkItems)
        if (!result.applicable) {
            throw UnprocessableException("COUPON_NOT_APPLICABLE", "적용할 수 없는 쿠폰입니다", "couponId=$couponId")
        }
        if (BigDecimal(result.discountAmount) > totalItemAmount) {
            throw UnprocessableException(
                "COUPON_NOT_APPLICABLE", "적용할 수 없는 쿠폰입니다",
                "couponId=$couponId, discountAmount=${result.discountAmount}, totalItemAmount=$totalItemAmount"
            )
        }
        return result.discountAmount
    }

    /** platform_order_no = "P" + yyMMdd + "-" + 5자리 시퀀스(당일 생성 건수+1, 동시성 보장 안 함) + "-00" (예: P261026-00001-00). */
    private fun nextPlatformOrderNo(now: LocalDateTime): String {
        val dayStart = now.toLocalDate().atStartOfDay()
        val dayEnd = dayStart.plusDays(1).minusNanos(1)
        val sequence = platformOrderRepository.countByOrderedAtBetween(dayStart, dayEnd) + 1
        return "P${now.toLocalDate().format(DateTimeFormatter.ofPattern("yyMMdd"))}-${"%05d".format(sequence)}-00"
    }

    /** order_no(vendor별) = "V" + 플랫폼 주문번호 본문(yyMMdd-NNNNN) + "-" + 해당 주문 안의 판매자 주문 순번 2자리(01~) (예: V261026-00001-01). */
    private fun formatVendorOrderNo(platformOrderNo: String, seq: Int): String =
        "V${platformOrderNo.substring(1, platformOrderNo.length - 3)}-${"%02d".format(seq)}"

    /**
     * 요청 바디 OrderItemRequest 1건을 OrderItem Entity로 변환한다(design-02-entity.md §2-4 사용자 결정 4).
     * priceSupply=priceSale(공급가 단순화), feeRate=0(수수료율 미연동) — 정산 정확도는 범위 밖.
     */
    private fun buildOrderItem(itemRequest: OrderItemRequest, order: Order, platformOrderId: Long, now: LocalDateTime, status: String): OrderItem {
        val priceSale = BigDecimal(itemRequest.priceSale)
        return OrderItem(
            platformOrderId = platformOrderId,
            order = order,
            productId = itemRequest.productId,
            skuId = itemRequest.skuId,
            productName = itemRequest.productName,
            option1Type = itemRequest.color?.let { "컬러" },
            option1Value = itemRequest.color,
            option2Type = itemRequest.size?.let { "사이즈" },
            option2Value = itemRequest.size,
            quantity = itemRequest.quantity,
            priceOriginal = BigDecimal(itemRequest.priceOriginal),
            priceSale = priceSale,
            priceSupply = priceSale,
            feeRate = BigDecimal.ZERO,
            status = status,
            reviewWritten = false,
            createdAt = now,
            updatedAt = now,
            isDeleted = false,
            deletedAt = null,
            deletedBy = null
        )
    }

    // ── ② mapper execute (list / count / summary) — partner 전용 (아직 Mock, DB 미전환) ──
    // admin은 이미 TestAdminOrderMapper(MyBatis)로 전환되어 이 블록을 쓰지 않는다.
    // partner는 지금 MockLoader가 전체 데이터셋을 로드하고 아래 메서드들이 사후 필터링한다.
    // DB 전환 시 loadPartnerOrderDataset()은 사라지고, applySharedFilters+matchesStatus+sortByOrderDateDesc+selectPage의 조건이
    // list/count 쿼리의 WHERE+ORDER BY+LIMIT/OFFSET으로 흡수된다 (admin이 이미 이 전환을 마친 참고 사례).

    /** 판매자 목록용 전체 데이터셋을 로드한다. */
    private fun loadPartnerOrderDataset(): List<Map<String, Any>> =
        extractOrders(mockLoader.load("order", MockFile.PARTNER_ORDERS))

    /** Mock 응답(JSON)에서 `data.orders[]` 배열을 꺼낸다. */
    @Suppress("UNCHECKED_CAST")
    private fun extractOrders(loaded: Map<String, Any>): List<Map<String, Any>> {
        val data = loaded["data"] as? Map<String, Any> ?: return emptyList()
        return (data["orders"] as? List<Map<String, Any>>) ?: emptyList()
    }

    /** list/count/summary 쿼리가 공통으로 쓰는 조건(keyword, dateRange)만 적용한다 — status는 호출부에서 별도 적용. */
    private fun applySharedFilters(orders: List<Map<String, Any>>, keyword: String?, from: String?, to: String?): List<Map<String, Any>> =
        orders.filter { matchesKeyword(it, keyword) && matchesDateRange(it, from, to) }

    /**
     * 주문번호·상품명·고객명에 키워드가 포함되는지 확인한다. 키워드가 없으면 전체 통과.
     * partner 전용 — partner 목록 Mock(partner__GET_orders.json)의 고객명 필드는 `customerName`이다
     * (admin은 이미 DB로 전환되어 이 메서드를 쓰지 않음 — admin 스키마의 `customer`와 혼용하지 않는다).
     */
    private fun matchesKeyword(order: Map<String, Any>, keyword: String?): Boolean {
        if (keyword.isNullOrBlank()) return true
        val kw = keyword.lowercase()
        val platformOrderNo = (order["platformOrderNo"] as? String)?.lowercase() ?: ""
        val productName = (order["productName"] as? String)?.lowercase() ?: ""
        val customerName = (order["customerName"] as? String)?.lowercase() ?: ""
        return platformOrderNo.contains(kw) || productName.contains(kw) || customerName.contains(kw)
    }

    /** 주문 상태가 필터값과 일치하는지 확인한다. status가 비어있거나 "ALL"이면 전체 통과. list/count 쿼리 전용 조건(summary에는 적용하지 않음). */
    private fun matchesStatus(order: Map<String, Any>, status: String?): Boolean {
        if (status.isNullOrBlank() || status == "ALL") return true
        return order["status"] == status
    }

    /** 주문일자가 from~to 범위(YYYY-MM-DD, 양쪽 포함) 안에 있는지 확인한다. from/to가 비어있으면 해당 경계는 무시한다. */
    private fun matchesDateRange(order: Map<String, Any>, from: String?, to: String?): Boolean {
        val orderDate = order["orderDate"] as? String ?: return true
        val datePart = if (orderDate.length >= 10) orderDate.substring(0, 10) else orderDate
        if (!from.isNullOrBlank() && datePart < from) return false
        if (!to.isNullOrBlank() && datePart > to) return false
        return true
    }

    /** list 쿼리의 ORDER BY에 대응 — 주문일자 기준 최신순(내림차순) 정렬. */
    private fun sortByOrderDateDesc(orders: List<Map<String, Any>>): List<Map<String, Any>> =
        orders.sortedByDescending { (it["orderDate"] as? String) ?: "" }

    /** list 쿼리의 LIMIT/OFFSET에 대응 — 정렬된 전체 목록에서 요청한 page/size 구간만 선택한다. */
    private fun selectPage(sortedOrders: List<Map<String, Any>>, page: Int, size: Int): List<Map<String, Any>> {
        val startIndex = (page - 1) * size
        return sortedOrders.drop(startIndex).take(size)
    }

    /** count 쿼리에 대응 — list와 동일 WHERE 조건(상태 필터 포함)의 전체 건수. 지금은 메모리의 리스트 크기로 대신한다. */
    private fun countFiltered(listFilteredOrders: List<Map<String, Any>>): Int = listFilteredOrders.size

    /** MyBatis(slave)의 GROUP BY status 집계 결과(StatusCountRow[])를 응답용 summary Map으로 변환한다. */
    private fun buildAdminSummaryFromRows(rows: List<StatusCountRow>): Map<String, Any> {
        val counts = adminStatusSummaryKeys.values.associateWith { 0 }.toMutableMap()
        var total = 0
        rows.forEach { row ->
            total += row.count
            val key = adminStatusSummaryKeys[row.status] ?: return@forEach
            counts[key] = row.count
        }
        return mapOf("all" to total) + counts
    }

    // ── ③ dto convert ──

    /** 응답에 포함할 Pagination DTO를 만든다. */
    private fun buildPagination(page: Int, size: Int, totalCount: Int): Pagination {
        val totalPages = if (totalCount == 0) 1 else ceil(totalCount.toDouble() / size).toInt().coerceAtLeast(1)
        return Pagination(page = page, size = size, totalCount = totalCount, totalPages = totalPages)
    }
}
