package com.runnshop.catalog.repository

import com.runnshop.catalog.domain.StockDeduction
import org.springframework.data.jpa.repository.JpaRepository

interface StockDeductionRepository : JpaRepository<StockDeduction, Long> {
    fun existsByRequestIdAndSkuId(requestId: String, skuId: Long): Boolean
    fun findByRequestId(requestId: String): List<StockDeduction>
}
