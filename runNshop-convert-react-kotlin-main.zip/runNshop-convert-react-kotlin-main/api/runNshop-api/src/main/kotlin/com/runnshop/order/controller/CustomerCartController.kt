package com.runnshop.order.controller

import com.runnshop.common.MockLoader
import com.runnshop.order.dto.UpdateQuantityRequest
import com.runnshop.order.service.CartService
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PatchMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RestController

@RestController
class CustomerCartController(private val mockLoader: MockLoader, private val cartService: CartService) {

    /** 장바구니 조회 (DL §2). mobile-cart-back-and-quantity 작업에서 CartService로 레이어를 옮겼다
     * (design.md 과업2 결정 4) — PATCH(updateQuantity)를 추가하면서 Controller가 MockLoader를
     * 직접 호출하는 패턴과 Service를 경유하는 패턴이 같은 Controller 안에 공존하지 않게 한다. */
    @GetMapping("/api/mobile/v1/my/cart")
    fun getCart(): ResponseEntity<Any> = ResponseEntity.ok(cartService.getCart())

    /** 장바구니 상품의 수량을 변경한다. (DL §3) */
    @PatchMapping("/api/mobile/v1/my/cart/items/{cartItemId}/quantity")
    fun updateQuantity(@PathVariable cartItemId: String, @RequestBody request: UpdateQuantityRequest): ResponseEntity<Any> {
        val data = cartService.updateQuantity(cartItemId, request.quantity)
        return ResponseEntity.ok(mapOf("code" to "SUCCESS", "data" to data))
    }

    /**
     * 장바구니 삭제 (DL §4). Cart 영속 계층이 코드베이스에 없어 cartItemId 존재 검증·실제
     * 삭제를 수행하지 않고 항상 성공 Mock을 반환한다 — 이 작업(mobile-cart-back-and-quantity) 범위
     * 밖이라 기존처럼 MockLoader를 직접 호출하는 패턴을 그대로 유지한다(불필요한 리팩터 방지).
     */
    @DeleteMapping("/api/mobile/v1/my/cart/items/{cartItemId}")
    fun removeItem(@PathVariable cartItemId: String): ResponseEntity<Any> {
        val data = mockLoader.load("order", "mobile__DELETE_my_cart_items_{cart_item_id}.json")
        return ResponseEntity.ok(data)
    }
}
