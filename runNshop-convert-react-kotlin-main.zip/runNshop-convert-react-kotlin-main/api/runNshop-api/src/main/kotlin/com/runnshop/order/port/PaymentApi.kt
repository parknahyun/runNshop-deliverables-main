package com.runnshop.order.port

/**
 * Order가 Payment 도메인을 조회하는 Port 인터페이스(도메인 경계를 넘는 호출 계약, DP-클래스설계/order.md §1:
 * publicapi/PaymentPublicApi.kt — 패키지/이름이 `order.publicapi.PaymentPublicApi`에서 `order.port.PaymentApi`로
 * 변경됨, 사유: SKILL.md "타 도메인 PublicApi 호출" 네이밍 간소화 결정).
 * 구현체는 제공 도메인(payment.service.PaymentService)에 있고 Spring DI로 이 인터페이스 타입에 주입된다 —
 * Order 코드는 Payment의 Mock 파일 경로/테이블명/구현 세부사항을 전혀 참조하지 않는다.
 *
 * `getPaymentInfo`는 기존 PublicApi들의 getter 네이밍 패턴(getProductInfo, getAddresses,
 * getPointBalance, getAvailableCoupons)과 일관되게 신규 정의한 메서드다(plan.md §0).
 *
 * `requestPayment(orderId, memberId, amount, method): PaymentResult`는 결제 "요청" 흐름(주문생성/
 * 결제요청)용 메서드다. `common.md` §5 원안은 3-파라미터(`orderId, amount, method`)였으나, `pay_payment.
 * member_id`(ERD NOT NULL) 저장을 위해 `memberId: String` 파라미터가 추가됐다(payment-persist-mobile-order
 * 작업, design.md §1 결정 5). `orderId`에 담기는 값도 `platformOrder.platformOrderNo`(표시용)에서
 * `platformOrder.id.toString()`(PK)로 바뀌어 `getPaymentInfo(orderId)`와 의미가 통일됐다.
 */
interface PaymentApi {

    /** 주문 1건의 결제정보(결제수단/PG사/거래번호/결제시각)를 조회한다. 결제 미완료 주문은 paidAt이 null일 수 있다.
     *  pay_payment를 platformOrderId로 실 조회한다(payment-persist-mobile-order 작업, design.md §1 결정 6). */
    fun getPaymentInfo(orderId: String): PaymentInfo

    /** 복합결제 지원(2026-10-27): 결제수단별 1행으로 저장한다 — `amount`(PG 결제수단 금액, 0이면 생략)와 `pointAmount`
     *  (포인트 사용분, 0이면 생략)를 각각 pay_payment 행으로 만든다. 같은 호출의 행들은 같은 `pay_group_no`(결제 시도 번호)를 갖고,
     *  결제번호는 `Y`+플랫폼 주문번호 본문(`platformOrderNo`)+행 순번(YyMMdd-NNNNN-NN)이다. */
    fun requestPayment(
        orderId: String, platformOrderNo: String, memberId: String, amount: Int, method: String, pointAmount: Int
    ): PaymentResult
}

/**
 * 주문상세 응답의 `payment` 블록과 1:1 호환되는 결제정보 DTO (완전 신규 — 1차 근거 문서에 필드 정의 없음,
 * 기존 admin 상세 응답의 payment 블록 구조를 그대로 따름, plan.md §0).
 */
data class PaymentInfo(
    val method: String,
    val pgProvider: String,
    val transactionId: String,
    val paidAt: String?
)

/**
 * 결제요청 결과 DTO — `common.md` §5에 이름만 등재돼 있어 필드는 신규로 채운다. 기존 `PaymentInfo`의
 * `transactionId` 네이밍을 참고해 최소 2개 필드로 정의한다(design-03-publicapi.md §3).
 */
data class PaymentResult(
    val accepted: Boolean,
    val transactionId: String
)
