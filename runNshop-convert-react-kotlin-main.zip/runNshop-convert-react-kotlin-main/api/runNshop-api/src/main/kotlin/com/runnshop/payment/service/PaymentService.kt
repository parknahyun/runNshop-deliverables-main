package com.runnshop.payment.service

import com.runnshop.order.port.PaymentInfo
import com.runnshop.order.port.PaymentApi
import com.runnshop.order.port.PaymentResult
import com.runnshop.order.domain.StatusTargetType
import com.runnshop.order.service.OrderStatusHistoryService
import com.runnshop.payment.domain.Payment
import com.runnshop.payment.repository.PaymentRepository
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import java.math.BigDecimal
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

/** pay_payment.payment_method → 화면 표시 라벨(payment-persist-mobile-order 작업, design.md §3 —
 *  OrderService의 MyOrderStatusLabel과 동일 패턴). Order가 실제로 보내는 4종(CARD/EASY_PAY/POINT/
 *  VIRTUAL_ACCOUNT) 전부를 라벨로 매핑한다(payment-method-fidelity-fix 작업, design.md §1 결정 2 각주 —
 *  2-버킷 근사 매핑을 폐기하고 무손실 저장으로 교체). `MIXED`는 ERD가 정의하지만 Order가 아직 보내지
 *  않아 라벨만 선반영해둔다(복합결제 미지원, 범위 밖). 모바일 주문서 Mock(`mobile__POST_my_orders_sheet.json`)·
 *  어드민 공통코드 Mock(`runNshop-admin` PAYMENT_METHOD 코드)의 기존 한국어 표기와 동일하게 맞췄다. */
private object PaymentMethodLabel {
    private val labels = mapOf(
        "CARD" to "신용카드",
        "EASY_PAY" to "간편결제",
        "POINT" to "포인트",
        "VIRTUAL_ACCOUNT" to "가상계좌",
        "MIXED" to "복합결제"
    )
    fun of(method: String): String? = labels[method]
}

/**
 * pay_payment.pg_provider → 화면 표시 라벨(design.md §1 결정 3·§3). DB에는 Mock임을 드러내는
 * "MOCK_PG"를 그대로 저장하되(결정 3), CS 상담원이 보는 어드민 화면에는 한국어 라벨로 변환해 노출한다
 * — payment_method에 적용하는 PaymentMethodLabel과 동일한 원칙.
 */
private object PgProviderLabel {
    private val labels = mapOf("MOCK_PG" to "PG 미연동(Mock)")
    fun of(provider: String): String? = labels[provider]
}

private val PAYMENT_DATE_FORMAT: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")

/**
 * Payment 도메인 서비스 (DP-클래스설계/payment.md §2 패키지 트리). PaymentApi(Port) 구현 2개 메서드만
 * 담당한다 — DP가 정의한 전체 PaymentService(§4, handlePgCallback 등)는 범위 밖(work-scope 예외 승인,
 * payment-persist-mobile-order 작업, design.md §0). 이번 변경으로 고정 Mock 반환을 pay_payment 저장/
 * 조회로 교체했다(design.md §0-§1).
 */
@Service
@Transactional
class PaymentService(
    private val paymentRepository: PaymentRepository,
    private val statusHistoryService: OrderStatusHistoryService // 결제상태 전이 이력(PG 요청/수신) 기록
) : PaymentApi {

    /**
     * 주문 1건의 결제정보를 조회한다 (PaymentApi 구현). pay_payment를 platformOrderId로 실제 조회한다
     * (design.md §1 결정 6). 행이 없으면(레거시/이론상 누락) 예외 대신 placeholder를 반환한다 — 상세
     * 조회 전체를 막지 않기 위함(design.md §1 결정 6 근거).
     */
    override fun getPaymentInfo(orderId: String): PaymentInfo {
        val platformOrderId = orderId.toLongOrNull()
        val rows = platformOrderId?.let { paymentRepository.findByPlatformOrderIdOrderByIdAsc(it) } ?: emptyList()
        if (rows.isEmpty()) return PaymentInfo(method = "-", pgProvider = "-", transactionId = "-", paidAt = null)
        // 가장 최근 결제 시도(pay_group_no)의 행들만 보여준다. 복합결제면 수단 라벨을 "신용카드 + 포인트"로 합치고,
        // PG 정보(PG사/거래번호/결제시각)는 PG를 거치는 첫 행(없으면 첫 행)에서 가져온다.
        val latest = rows.filter { it.payGroupNo == rows.maxOf { r -> r.payGroupNo } }
        val labels = latest.map { PaymentMethodLabel.of(it.paymentMethod) ?: it.paymentMethod }
        val pgRow = latest.firstOrNull { it.paymentMethod != "POINT" } ?: latest.first()
        return PaymentInfo(
            method = if (latest.size > 1) "복합결제 (${labels.joinToString(" + ")})" else labels.first(),
            pgProvider = pgRow.pgProvider?.let { PgProviderLabel.of(it) ?: it } ?: "-",
            transactionId = pgRow.pgTransactionId ?: "-",
            paidAt = pgRow.pgApprovedAt?.format(PAYMENT_DATE_FORMAT)
        )
    }

    /**
     * 결제확정(placeOrder) 흐름에서 결제를 요청하고 pay_payment에 저장한다 (PaymentApi 구현).
     * 복합결제(2026-10-27): PG 결제수단 금액(`amount`>0)과 포인트 사용분(`pointAmount`>0)을 결제수단별 1행으로 저장한다.
     * 한 번의 요청 행들은 같은 pay_group_no(결제 시도 번호)를 갖고, 결제번호 순번은 그 주문 안의 결제 행 생성 순서다.
     * Mock PG는 항상 성공만 반환한다(PG 연동 없음).
     */
    override fun requestPayment(
        orderId: String, platformOrderNo: String, memberId: String, amount: Int, method: String, pointAmount: Int
    ): PaymentResult {
        val platformOrderId = orderId.toLongOrNull()
            ?: throw IllegalArgumentException("orderId는 platformOrderId(숫자)여야 합니다: $orderId")
        val memberIdLong = memberId.toLongOrNull()
            ?: throw IllegalArgumentException("memberId는 숫자여야 합니다: $memberId")
        if (amount <= 0 && pointAmount <= 0) throw IllegalArgumentException("결제 금액이 없습니다: amount=$amount, pointAmount=$pointAmount")
        val now = LocalDateTime.now()
        val existing = paymentRepository.findByPlatformOrderIdOrderByIdAsc(platformOrderId)
        val payGroupNo = (existing.maxOfOrNull { it.payGroupNo } ?: 0) + 1
        var seq = existing.size
        var transactionId = "TXN-MOCK-$platformOrderId"

        val saved = mutableListOf<Payment>()
        // ① PG 결제수단 행 (카드/간편결제/가상계좌). 가상계좌는 계좌 발급만 받고 입금 통보 전까지 입금대기(WAITING_DEPOSIT).
        if (amount > 0) {
            val isVirtualAccount = method == "VIRTUAL_ACCOUNT"
            val paymentAmount = BigDecimal(amount)
            saved += paymentRepository.save(Payment(
                paymentNo = formatPaymentNo(platformOrderNo, ++seq), platformOrderId = platformOrderId, memberId = memberIdLong,
                paymentAmount = paymentAmount,
                approvedAmount = if (isVirtualAccount) null else paymentAmount, // 가상계좌는 입금 통보 전까지 승인금액 없음
                paymentMethod = method, payGroupNo = payGroupNo, pgProvider = "MOCK_PG", pgTransactionId = transactionId,
                pgApprovalNo = if (isVirtualAccount) null else "APV-MOCK-$platformOrderId",
                pgApprovedAt = if (isVirtualAccount) null else now,
                status = if (isVirtualAccount) "WAITING_DEPOSIT" else "COMPLETED", createdAt = now, updatedAt = now
            ))
        }
        // ② 포인트 사용 행 — PG를 거치지 않으므로 PG 컬럼은 비우고 승인시각만 사용 시각으로 채운다.
        if (pointAmount > 0) {
            if (amount <= 0) transactionId = "PNT-$platformOrderId"
            saved += paymentRepository.save(Payment(
                paymentNo = formatPaymentNo(platformOrderNo, ++seq), platformOrderId = platformOrderId, memberId = memberIdLong,
                paymentAmount = BigDecimal(pointAmount), approvedAmount = BigDecimal(pointAmount), paymentMethod = "POINT",
                payGroupNo = payGroupNo, pgProvider = null, pgTransactionId = null, pgApprovalNo = null, pgApprovedAt = now,
                status = "COMPLETED", createdAt = now, updatedAt = now
            ))
        }

        // 결제상태 전이 이력 — 행별로 PG 요청 → PG 수신(승인). payload는 남기지 않고 시각과 작업 내용만 기록한다.
        // Mock PG는 요청 즉시 응답(카드=승인, 가상계좌=계좌발급)하므로 두 건의 시각이 같다(실제 PG 연동 시 비동기 콜백 시각으로 분리됨).
        saved.forEach { payment ->
            val isPoint = payment.paymentMethod == "POINT"
            val isVirtualAccount = payment.status == "WAITING_DEPOSIT"
            statusHistoryService.record(platformOrderId, StatusTargetType.PAYMENT, null, "REQUESTED",
                targetId = payment.id,
                reason = if (isPoint) "포인트 사용 요청 (${payment.paymentAmount.toPlainString()}P, ${payment.paymentNo})"
                         else "PG 결제 요청 (${payment.pgProvider}, 결제수단 ${payment.paymentMethod}, ${payment.paymentAmount.toPlainString()}원, ${payment.paymentNo})",
                at = now)
            statusHistoryService.record(platformOrderId, StatusTargetType.PAYMENT, "REQUESTED", payment.status,
                targetId = payment.id,
                reason = when {
                    isPoint -> "포인트 사용 완료"
                    isVirtualAccount -> "PG 가상계좌 발급 수신 (${payment.pgProvider}), 입금 대기"
                    else -> "PG 승인 수신 (${payment.pgProvider})"
                },
                at = now)
        }

        return PaymentResult(accepted = true, transactionId = transactionId)
    }

    /** payment_no = "Y" + 플랫폼 주문번호 본문(yyMMdd-NNNNN) + "-" + 그 주문 안의 결제 행 순번 2자리(01~) (예: Y261026-00001-01). 주문당 99행 한도(플랫폼 제약). */
    private fun formatPaymentNo(platformOrderNo: String, seq: Int): String {
        require(platformOrderNo.length == 16) { "platformOrderNo 형식 오류: $platformOrderNo" }
        require(seq in 1..99) { "주문당 결제 행은 99건까지입니다: $platformOrderNo" }
        return "Y${platformOrderNo.substring(1, 13)}-${"%02d".format(seq)}"
    }
}
