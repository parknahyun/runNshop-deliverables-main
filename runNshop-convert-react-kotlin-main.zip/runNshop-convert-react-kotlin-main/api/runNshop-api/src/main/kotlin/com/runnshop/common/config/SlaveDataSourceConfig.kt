package com.runnshop.common.config

import com.zaxxer.hikari.HikariDataSource
import org.apache.ibatis.session.SqlSessionFactory
import org.mybatis.spring.SqlSessionFactoryBean
import org.mybatis.spring.SqlSessionTemplate
import org.mybatis.spring.annotation.MapperScan
import org.springframework.boot.context.properties.ConfigurationProperties
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.core.io.support.PathMatchingResourcePatternResolver
import javax.sql.DataSource

/**
 * slave DataSource(MyBatis 전용, 읽기전용 계정 `runnshop_slave`).
 * 동적 검색(목록) 쿼리는 전부 이 DataSource(MyBatis)를 거친다.
 * DB 레벨에서 SELECT 외 권한이 없어 쓰기 작업은 애플리케이션 레이어가 아니라 DB가 차단한다.
 */
@Configuration
@MapperScan(basePackages = ["com.runnshop.order.mapper"], sqlSessionFactoryRef = "slaveSqlSessionFactory")
class SlaveDataSourceConfig {

    /** application.yml의 app.datasource.slave 설정값. */
    @ConfigurationProperties("app.datasource.slave")
    @Bean
    fun slaveJdbcProperties(): JdbcProperties = JdbcProperties()

    /** slave(MyBatis) 전용 커넥션 풀 — 읽기전용 계정으로 연결. */
    @Bean
    fun slaveDataSource(slaveJdbcProperties: JdbcProperties): DataSource =
        HikariDataSource().apply {
            jdbcUrl = slaveJdbcProperties.jdbcUrl
            username = slaveJdbcProperties.username
            password = slaveJdbcProperties.password
            driverClassName = slaveJdbcProperties.driverClassName
            poolName = "slave-hikari-pool"
            isReadOnly = true // 커넥션 자체도 읽기 전용으로 선언 (DB 권한과 이중 방어)
        }

    /** slave DataSource로 Mapper XML(resources/mapper 하위 전체)을 로드하는 SqlSessionFactory. */
    @Bean
    fun slaveSqlSessionFactory(slaveDataSource: DataSource): SqlSessionFactory {
        val factoryBean = SqlSessionFactoryBean()
        factoryBean.setDataSource(slaveDataSource)
        val mapperXmlPattern = "classpath:mapper/" + "**/" + "*.xml"
        val mapperResources = PathMatchingResourcePatternResolver().getResources(mapperXmlPattern)
        factoryBean.setMapperLocations(*mapperResources)
        return factoryBean.getObject()!!
    }

    /** slave SqlSessionFactory를 사용하는 SqlSessionTemplate. */
    @Bean
    fun slaveSqlSessionTemplate(slaveSqlSessionFactory: SqlSessionFactory): SqlSessionTemplate =
        SqlSessionTemplate(slaveSqlSessionFactory)
}
