package com.runnshop.order.domain

import jakarta.persistence.Column
import jakarta.persistence.Entity
import jakarta.persistence.GeneratedValue
import jakarta.persistence.GenerationType
import jakarta.persistence.Id
import jakarta.persistence.Table
import java.time.LocalDateTime

object OutboxEventType {
    /** 재고차감 요청 — 컨슈머가 상품 API로 차감한다. */
    const val STOCK_DEDUCT_REQUESTED = "STOCK_DEDUCT_REQUESTED"
    /** PG(입금/승인) 결제 요청 — 재고차감 성공 후 컨슈머가 처리한다. */
    const val PAYMENT_REQUESTED = "PAYMENT_REQUESTED"
}

/**
 * ord_outbox_event — 주문 비동기 처리용 아웃박스. API는 주문 상태 변경과 같은 트랜잭션에서 INSERT만 하고(유실 방지),
 * 이후 조회·상태(PENDING/DONE/FAILED)·재시도 관리는 별도 컨슈머 앱이 한다.
 */
@Entity
@Table(name = "ord_outbox_event")
class OutboxEvent(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    val id: Long = 0,

    @Column(name = "event_type")
    val eventType: String,

    @Column(name = "platform_order_id")
    val platformOrderId: Long,

    @Column(name = "payload")
    val payload: String? = null,

    @Column(name = "status")
    var status: String = "PENDING",

    @Column(name = "retry_count")
    var retryCount: Int = 0,

    @Column(name = "last_error")
    var lastError: String? = null,

    @Column(name = "created_at")
    val createdAt: LocalDateTime = LocalDateTime.now(),

    @Column(name = "processed_at")
    var processedAt: LocalDateTime? = null
) {
    constructor() : this(eventType = "", platformOrderId = 0)
}
