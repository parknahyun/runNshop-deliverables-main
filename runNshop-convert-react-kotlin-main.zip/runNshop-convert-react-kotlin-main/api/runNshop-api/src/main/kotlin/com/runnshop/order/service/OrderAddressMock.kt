package com.runnshop.order.service

import com.runnshop.common.MockLoader

/**
 * 완전 신규 식별자(DP/DL 어디에도 이름 없음, design.md §1-2 사용자 결정 1). 요청 바디 `addressId`(Long)를
 * 받는 신규 Address Entity/PublicApi를 만들지 않고, 기존 Mock 파일 `mock/order/mobile__POST_my_orders_sheet.json`의
 * `data.addresses[]`(고정 2건)에서 변환한다 — "역할+이름" object 명명 패턴(AdminCustomerName/AdminVendorName)을 그대로 따름.
 */
object OrderAddressMock {

    private const val MOCK_FILE = "mobile__POST_my_orders_sheet.json"

    /**
     * addressId(1 또는 2)에 해당하는 배송지를 조회해 PlatformOrder 필드명으로 변환한다.
     * 매핑: recipient→receiverName, phone→receiverPhone, zip_code→zipcode, address→address1, address_detail→address2.
     * 대응 항목이 없으면(addressId가 1·2 외의 값) null을 반환하고, 호출부가 400 ADDRESS_REQUIRED로 처리한다.
     */
    @Suppress("UNCHECKED_CAST")
    fun resolve(mockLoader: MockLoader, addressId: Long?): ResolvedAddress? {
        if (addressId == null) return null
        val loaded = mockLoader.load("order", MOCK_FILE)
        val data = loaded["data"] as? Map<String, Any> ?: return null
        val addresses = data["addresses"] as? List<Map<String, Any>> ?: return null
        val address = addresses.firstOrNull { (it["address_id"] as? Number)?.toLong() == addressId } ?: return null
        return ResolvedAddress(
            receiverName = address["recipient"] as String,
            receiverPhone = address["phone"] as String,
            zipcode = address["zip_code"] as String,
            address1 = address["address"] as String,
            address2 = address["address_detail"] as String?
        )
    }
}

/** OrderAddressMock.resolve() 결과 DTO. deliveryMemo는 Mock에 대응 필드가 없어 항상 null로 별도 처리한다. */
data class ResolvedAddress(
    val receiverName: String,
    val receiverPhone: String,
    val zipcode: String,
    val address1: String,
    val address2: String?
)
