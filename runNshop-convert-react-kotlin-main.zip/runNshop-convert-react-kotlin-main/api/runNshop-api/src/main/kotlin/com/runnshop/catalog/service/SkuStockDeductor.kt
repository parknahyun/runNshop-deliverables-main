package com.runnshop.catalog.service

import com.runnshop.catalog.domain.StockDeduction
import com.runnshop.catalog.repository.SkuStockRepository
import com.runnshop.catalog.repository.StockDeductionRepository
import com.runnshop.order.port.StockDeductFailure
import org.springframework.dao.DataIntegrityViolationException
import org.springframework.stereotype.Component
import org.springframework.transaction.annotation.Propagation
import org.springframework.transaction.annotation.Transactional

/**
 * SKU 1건의 차감을 **독립 트랜잭션**(REQUIRES_NEW)으로 수행한다 — 한 SKU의 실패가 다른 SKU의 차감을 롤백하지 않고,
 * 호출한 쪽(주문 상태 갱신 트랜잭션)과도 분리된다. StockService가 SKU마다 이 빈을 호출한다(자기 호출은 프록시를 타지 않아 별도 빈으로 분리).
 */
@Component
class SkuStockDeductor(
    private val skuStockRepository: SkuStockRepository,
    private val stockDeductionRepository: StockDeductionRepository
) {

    /** 차감에 성공(또는 이미 차감됨)하면 null, 실패하면 사유를 반환한다. */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    fun deduct(requestId: String, skuId: Long, quantity: Int): StockDeductFailure? {
        // 멱등: 이전 시도에서 이미 차감한 SKU는 건너뛴다(부분 재시도 시 성공분 재차감 방지).
        if (stockDeductionRepository.existsByRequestIdAndSkuId(requestId, skuId)) return null
        if (skuStockRepository.deduct(skuId, quantity) == 0) {
            val reason = if (skuStockRepository.existsById(skuId)) "재고 부족" else "미등록 SKU"
            return StockDeductFailure(skuId, "$reason (skuId=$skuId, 요청 $quantity)")
        }
        try {
            stockDeductionRepository.saveAndFlush(StockDeduction(requestId = requestId, skuId = skuId, quantity = quantity))
        } catch (e: DataIntegrityViolationException) {
            // 임대 만료 등으로 같은 요청이 동시에 처리돼 다른 쪽이 먼저 기록한 경우 — 이 트랜잭션(차감 포함)은 롤백되고 이미 차감된 것으로 본다.
            throw DuplicateDeductionException()
        }
        return null
    }
}

/** 같은 (requestId, skuId) 차감이 동시에 기록됨 — 호출자가 이미 차감된 것으로 처리한다. */
class DuplicateDeductionException : RuntimeException("duplicate stock deduction")
