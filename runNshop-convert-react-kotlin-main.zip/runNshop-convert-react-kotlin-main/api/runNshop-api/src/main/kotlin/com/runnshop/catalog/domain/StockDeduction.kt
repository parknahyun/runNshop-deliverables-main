package com.runnshop.catalog.domain

import jakarta.persistence.Column
import jakarta.persistence.Entity
import jakarta.persistence.GeneratedValue
import jakarta.persistence.GenerationType
import jakarta.persistence.Id
import jakarta.persistence.Table
import java.time.LocalDateTime

/** cat_stock_deduction — 차감 이력 겸 멱등 키(request_id + sku_id 유니크). */
@Entity
@Table(name = "cat_stock_deduction")
class StockDeduction(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    val id: Long = 0,

    @Column(name = "request_id")
    val requestId: String,

    @Column(name = "sku_id")
    val skuId: Long,

    @Column(name = "quantity")
    val quantity: Int,

    @Column(name = "created_at")
    val createdAt: LocalDateTime = LocalDateTime.now()
) {
    constructor() : this(requestId = "", skuId = 0, quantity = 0)
}
