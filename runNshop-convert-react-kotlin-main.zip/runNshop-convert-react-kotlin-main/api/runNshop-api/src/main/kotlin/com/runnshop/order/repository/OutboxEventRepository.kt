package com.runnshop.order.repository

import com.runnshop.order.domain.OutboxEvent
import org.springframework.data.jpa.repository.JpaRepository

/** 아웃박스 적재(INSERT) 전용 — 이벤트 조회·상태 변경은 별도 컨슈머 앱(runNshop-consumer)이 담당한다. */
interface OutboxEventRepository : JpaRepository<OutboxEvent, Long>
