package com.runnshop.order.dto

/**
 * 컨슈머 앱이 내부 API로 넘기는 이벤트 처리 요청. 이벤트 테이블(조회·상태 변경)은 컨슈머가 소유하고,
 * 이 API는 업무 처리(재고차감/PG 요청)만 수행하므로 이벤트 id가 아니라 처리에 필요한 값만 받는다.
 */
data class OrderEventProcessRequest(
    val eventType: String,
    val platformOrderId: Long,
    /** 이벤트 부가정보 — PAYMENT_REQUESTED에서는 결제수단 코드. */
    val payload: String? = null
)

/**
 * 이벤트 처리 결과. `result`는 처리 후(또는 이미 처리된) 주문의 업무 상태를 뜻한다 — 같은 요청을 다시 호출해도
 * 같은 결과를 돌려주므로(멱등) 컨슈머가 이벤트 상태를 DONE으로 바꾸는 도중 장애가 나도 재호출로 복구된다.
 * STOCK_DEDUCTED(재고차감 완료) / STOCK_PARTIAL(일부 SKU 차감 실패 — 성공분은 유지, 컨슈머가 재시도하면 실패 SKU만 재차감) /
 * STOCK_FAILED(이미 실패 처리된 주문) / DEPOSIT_PENDING(PG 요청 완료) / SKIPPED(처리 대상 아님).
 */
data class OrderEventProcessResult(val result: String, val message: String? = null)

/** 컨슈머가 재시도를 소진해 이벤트를 포기할 때 업무 쪽 실패 전이를 요청한다. */
data class OrderEventGiveUpRequest(
    val eventType: String,
    val platformOrderId: Long,
    val reason: String? = null
)
