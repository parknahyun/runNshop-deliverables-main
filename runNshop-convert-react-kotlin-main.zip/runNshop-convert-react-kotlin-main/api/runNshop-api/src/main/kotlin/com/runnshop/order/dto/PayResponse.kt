package com.runnshop.order.dto

import java.math.BigDecimal

/**
 * POST .../pay 성공 응답 DTO (DL §6 원안 + design-03-publicapi.md §4-6 status 교체: PAYMENT_PENDING→DEPOSIT_PENDING).
 *
 * [order-placeorder-design-gaps/design.md §2] vendor가 2개 이상이면 `orderId`는 생성된 `Order` 중
 * 대표 1건(최솟값 id)만 가리킨다 — 영수증 화면의 부가 참고값이며, 이후 조회/네비게이션의 1차 식별자가
 * 아니다. 주문 상세 조회·"주문 상세 보기" 이동 등 후속 동작은 전부 `platformOrderId`
 * (`GET /api/mobile/v1/my/orders/{platformOrderId}` — 해당 API의 path parameter 이름은 `orderId`이지만
 * `OrderService.getMyOrderDetail()`이 실제로 조회하는 것은 `PlatformOrder.id`다)를 쓴다.
 *
 * `platformOrderNo`(완전 신규 필드, DP/DL 어디에도 기존 식별자 없음 — `platformOrder.platformOrderNo`
 * 그대로 재사용): "주문번호" 화면 표시용 필드다. `getAdminOrders()`/`getMyOrders()` 등 모든 조회 API가
 * "주문번호"로 `"P"+yyMMdd+"-"+5자리+"-00"` 포맷을 반환하므로, 결제확정 응답도 같은 포맷을 돌려줘야
 * 완료 화면의 주문번호 표기가 목록·상세 화면과 일치한다 — `orderId`(raw PK)는 표시용으로 쓰지 않는다.
 */
data class PayResponse(
    val platformOrderId: String,
    val platformOrderNo: String,
    val orderId: String,
    /** 주문금액 — 상품금액 − 할인금액 + 배송비 − 배송비 할인금액(= 포인트 + 결제금액). */
    val totalOrderAmount: BigDecimal,
    /** 결제금액 — 주문금액 − 포인트(PG 결제수단으로 지불하는 금액). 필드명은 하위호환으로 유지한다. */
    val totalPayment: BigDecimal,
    val status: String,
    val message: String
)
