package com.runnshop.order.dto

/**
 * POST /api/mobile/v1/my/orders/{orderSheetId}/pay 요청 바디 (DL §6 원안 필드명 + 2차 리뷰 반영 `items` 필드,
 * design.md §1-2). `items`는 FE가 GET /my/cart(Mock) 응답에서 선택한 항목을 그대로 되돌려 보낸다 — Cart 영속
 * 계층이 코드베이스에 없어 요청 바디로 상품 데이터 전체를 받는 결정(design.md §0 Finding 3).
 */
data class PayRequest(
    /** @deprecated 2026-10-26 — 상품은 주문서 진입 시 저장된 임시주문(DB)에서 읽는다. 이 값은 무시한다(하위호환용 필드). */
    val items: List<OrderItemRequest> = emptyList(),
    val addressId: Long?,
    /** @deprecated 2026-10-26 — 쿠폰/포인트는 주문서에서 적용돼 임시주문에 영속된 값을 쓴다. 이 값은 무시한다(하위호환용 필드). */
    val couponId: String? = null,
    /** @deprecated 2026-10-26 — couponId와 동일(무시). */
    val pointUsed: Int? = 0,
    val paymentMethodType: String,
    val termsAgreed: List<String> = emptyList()
)

/**
 * `items` 원소 1건 — 기존 `OrderItem` Entity(survey.md §4) 필드명과 동일 네이밍을 그대로 가져와
 * 일관성을 유지한다(design.md §1-2).
 */
data class OrderItemRequest(
    val vendorId: Long,
    val productId: Long,
    val skuId: Long,
    val productName: String,
    val priceOriginal: Int,
    val priceSale: Int,
    val quantity: Int,
    val color: String? = null,
    val size: String? = null
)

/** POST /api/mobile/v1/my/orders/sheet 요청 바디 — 장바구니에서 선택한 상품. 서버가 임시주문으로 저장한다. */
data class OrderSheetRequest(
    val items: List<OrderItemRequest> = emptyList()
)

/** PUT /api/mobile/v1/my/orders/sheet/{orderSheetId}/discount 요청 바디 — 주문서의 쿠폰/포인트 적용(null/0이면 해제). */
data class OrderSheetDiscountRequest(
    val couponId: String? = null,
    val pointUsed: Int? = 0
)
