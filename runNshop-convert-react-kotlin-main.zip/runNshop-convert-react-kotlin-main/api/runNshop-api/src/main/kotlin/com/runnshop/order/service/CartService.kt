package com.runnshop.order.service

import com.runnshop.common.MockLoader
import com.runnshop.common.exception.BadRequestException
import com.runnshop.common.exception.ConflictException
import com.runnshop.common.exception.NotFoundException
import com.runnshop.order.dto.CartItemResponse
import org.springframework.stereotype.Service

/** Mock 파일명 — 메서드마다 하드코딩하지 않고 한곳에 모아 오타를 컴파일 타임에 잡는다. */
private object CartMockFile {
    const val MY_CART = "mobile__GET_my_cart.json"
}

/**
 * Order 도메인 장바구니(cart) 비즈니스 로직 (DP-클래스설계/order.md §3 `CartService` 기존 이름).
 * `CustomerCartController`가 기존에 `MockLoader`를 직접 호출하던 GET도 이번에 함께 옮겨, Controller가
 * 레이어 경계(backend-service-pattern)를 예외 없이 지키게 한다(design.md 과업2 결정 4).
 */
@Service
class CartService(private val mockLoader: MockLoader) {

    /**
     * 로그인한 본인(me)의 장바구니를 조회한다. (DL §2)
     *
     * `memberId`를 파라미터로 받지 않는다 — 이 Mock은 회원 구분 없는 단일 전역 데이터셋이라 필터링할
     * 대상이 없다(design.md 과업2 "식별자 도출 근거" 참고, DP 시그니처 `getCart(memberId: String)`와의
     * 의도적 이탈). 반환 타입도 DP의 `CartResponse`(DTO) 대신 `Map<String, Any>` 패스스루를 쓴다 — Mock
     * JSON 파일(snake_case)을 그대로 반환해야 DL §2의 snake_case 응답 계약을 유지할 수 있기 때문이다.
     */
    fun getCart(): Map<String, Any> = mockLoader.load("order", CartMockFile.MY_CART)

    /**
     * 장바구니 상품의 수량을 변경한다. (DL §3)
     *
     * 정적 성공 Mock 파일을 두지 않고, 기존 `getCart()`가 쓰는 전체 데이터셋을 "Repository가 쿼리했다면
     * 돌려줬을 전체 데이터셋"으로 간주해 그때그때 다시 읽어 해당 item의 실제 stock/price_sale로
     * 검증·계산한다(design.md 과업2 결정 5) — 정적 파일로는 요청값별 분기(범위초과/재고초과)를
     * 표현할 수 없다.
     */
    @Suppress("UNCHECKED_CAST")
    fun updateQuantity(cartItemId: String, quantity: Int): CartItemResponse {
        // ① validation
        if (quantity < 1 || quantity > 99) {
            throw BadRequestException("INVALID_QUANTITY", "수량은 1~99 사이여야 합니다", "quantity=$quantity")
        }

        // ② mapper execute — Mock 데이터셋에서 cartItemId로 item 탐색
        val cart = mockLoader.load("order", CartMockFile.MY_CART)["data"] as Map<String, Any>
        val vendors = cart["vendors"] as List<Map<String, Any>>
        val item = vendors.flatMap { it["items"] as List<Map<String, Any>> }
            .find { (it["cart_item_id"] as Number).toString() == cartItemId }
            ?: throw NotFoundException("CART_ITEM_NOT_FOUND", "장바구니 항목을 찾을 수 없습니다", "cartItemId=$cartItemId")

        val stock = (item["stock"] as Number).toInt()
        if (quantity > stock) {
            throw ConflictException("EXCEED_STOCK", "재고 수량을 초과합니다", "cartItemId=$cartItemId, quantity=$quantity, stock=$stock")
        }

        // ③ dto convert
        val priceSale = (item["price_sale"] as Number).toInt()
        return CartItemResponse(cartItemId = cartItemId, quantity = quantity, subtotal = priceSale * quantity)
    }
}
