package com.runnshop.order.domain

import jakarta.persistence.CascadeType
import jakarta.persistence.Column
import jakarta.persistence.Entity
import jakarta.persistence.FetchType
import jakarta.persistence.GeneratedValue
import jakarta.persistence.GenerationType
import jakarta.persistence.Id
import jakarta.persistence.OneToMany
import jakarta.persistence.Table
import java.math.BigDecimal
import java.time.LocalDateTime

/**
 * ord_platform_order — 플랫폼 주문(애그리거트 루트) Entity (ERD §8 Order 도메인 원문 25개 컬럼 그대로,
 * design-02-entity.md §2-1). PK는 기존 Order/OrderItem과 동일하게 ERD 리터럴 그대로 Long(IDENTITY) 채택.
 *
 * orders/discounts는 cascade=ALL — placeOrder()가 1차 저장(이 Entity만 자식 없이 save)으로 id를 확보한 뒤
 * 2차 저장(자식 포함 save)으로 Order/OrderItem/PlatformOrderDiscount를 한 번에 INSERT한다
 * (design.md §3-1 "2단계 저장", OrderItem.platformOrderId 비정규화 컬럼이 실제 id를 필요로 하기 때문).
 *
 * carted_at/last_validated_at/price_snapshot/event_price_id는 이번 라운드(장바구니 영속화 없음, 행사가 미연동)
 * 범위 밖이라 TODO로 비워두거나(nullable) orderedAt과 동일 값으로 대체한다(design-02-entity.md §2-1 참조).
 */
@Entity
@Table(name = "ord_platform_order")
class PlatformOrder(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    val id: Long = 0,

    @Column(name = "platform_order_no")
    val platformOrderNo: String,

    @Column(name = "member_id")
    val memberId: Long,

    @Column(name = "status")
    var status: String,

    @Column(name = "total_item_amount")
    var totalItemAmount: BigDecimal,

    @Column(name = "total_discount_amount")
    var totalDiscountAmount: BigDecimal,

    @Column(name = "total_shipping_amount")
    var totalShippingAmount: BigDecimal,

    @Column(name = "point_used_amount")
    var pointUsedAmount: Int,

    /** 결제금액 — 주문금액 − 포인트(PG 결제수단 지불분). 컬럼명은 유지(DBA order.md 3.7.5, 2026-10-29). */
    @Column(name = "payment_amount")
    var paymentAmount: BigDecimal,

    @Column(name = "receiver_name")
    var receiverName: String,

    @Column(name = "receiver_phone")
    var receiverPhone: String,

    @Column(name = "zipcode")
    var zipcode: String,

    @Column(name = "address1")
    var address1: String,

    @Column(name = "address2")
    var address2: String?,

    @Column(name = "delivery_memo")
    var deliveryMemo: String?,

    @Column(name = "ordered_at")
    var orderedAt: LocalDateTime,

    @Column(name = "created_at")
    val createdAt: LocalDateTime,

    @Column(name = "updated_at")
    var updatedAt: LocalDateTime,

    /** 장바구니 담은 일시(ERD NOT NULL). 이번 라운드는 카트 담은 시각 추적이 없어 orderedAt과 동일 값(TODO). */
    @Column(name = "carted_at")
    val cartedAt: LocalDateTime,

    /** 마지막 유효성 검사 일시. 이번 라운드는 동기 사전검증 로직 범위 밖이라 항상 null(TODO). */
    @Column(name = "last_validated_at")
    val lastValidatedAt: LocalDateTime? = null,

    /** 담을 당시 가격 스냅샷. 범위 밖, 항상 null(TODO). */
    @Column(name = "price_snapshot")
    val priceSnapshot: BigDecimal? = null,

    /** 담을 당시 적용된 행사가 ID. 행사가 미연동으로 항상 null(TODO). */
    @Column(name = "event_price_id")
    val eventPriceId: Long? = null,

    @Column(name = "is_deleted")
    val isDeleted: Boolean = false,

    @Column(name = "deleted_at")
    val deletedAt: LocalDateTime? = null,

    @Column(name = "deleted_by")
    val deletedBy: String? = null,

    @OneToMany(mappedBy = "platformOrder", cascade = [CascadeType.ALL], orphanRemoval = true, fetch = FetchType.LAZY)
    val orders: MutableList<Order> = mutableListOf(),

    @OneToMany(mappedBy = "platformOrder", cascade = [CascadeType.ALL], orphanRemoval = true, fetch = FetchType.LAZY)
    val discounts: MutableList<PlatformOrderDiscount> = mutableListOf(),

    /**
     * 주문금액 — 상품금액 − 할인금액 + 배송비 − 배송비 할인금액(= 포인트 + 결제금액). 어드민·고객 목록의 금액.
     * (2026-10-29 신설, order-total-order-amount.sql) 배송비 할인금액 컬럼은 아직 없어 식에서 0으로 본다.
     */
    @Column(name = "total_order_amount")
    var totalOrderAmount: BigDecimal = BigDecimal.ZERO
) {
    // JPA 기본 생성자 요구사항 — Hibernate가 리플렉션으로 인스턴스를 만들 때 사용 (Order.kt의 기존 패턴과 동일)
    constructor() : this(
        platformOrderNo = "", memberId = 0, status = "", totalItemAmount = BigDecimal.ZERO,
        totalDiscountAmount = BigDecimal.ZERO, totalShippingAmount = BigDecimal.ZERO, pointUsedAmount = 0,
        paymentAmount = BigDecimal.ZERO, receiverName = "", receiverPhone = "", zipcode = "", address1 = "",
        address2 = null, deliveryMemo = null, orderedAt = LocalDateTime.now(), createdAt = LocalDateTime.now(),
        updatedAt = LocalDateTime.now(), cartedAt = LocalDateTime.now()
    )
}
