package com.runnshop.common.config

import com.zaxxer.hikari.HikariDataSource
import jakarta.persistence.EntityManagerFactory
import org.springframework.boot.context.properties.ConfigurationProperties
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.context.annotation.Primary
import org.springframework.data.jpa.repository.config.EnableJpaRepositories
import org.springframework.orm.jpa.JpaTransactionManager
import org.springframework.orm.jpa.JpaVendorAdapter
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter
import org.springframework.transaction.PlatformTransactionManager
import javax.sql.DataSource

/** HikariCP 커넥션 풀 설정값을 담는 단순 데이터 홀더 (application.yml app.datasource.{master|slave} 바인딩용). */
class JdbcProperties {
    lateinit var jdbcUrl: String
    lateinit var username: String
    lateinit var password: String
    lateinit var driverClassName: String
}

/**
 * master DataSource(JPA 전용, DB owner 계정 `runnshop_master`).
 * 상세 조회(단건+연관관계)와 향후 CUD는 전부 이 DataSource(JPA)를 거친다.
 * `@Primary`로 지정해 기본 DataSource/EntityManager/TransactionManager 주입 대상이 되게 한다.
 */
@Configuration
@EnableJpaRepositories(
    basePackages = ["com.runnshop"],
    entityManagerFactoryRef = "entityManagerFactory",
    transactionManagerRef = "transactionManager"
)
class MasterDataSourceConfig {

    /** application.yml의 app.datasource.master 설정값. */
    @ConfigurationProperties("app.datasource.master")
    @Bean
    fun masterJdbcProperties(): JdbcProperties = JdbcProperties()

    /** master(JPA) 전용 커넥션 풀 — 기본(@Primary) DataSource. */
    @Primary
    @Bean
    fun masterDataSource(masterJdbcProperties: JdbcProperties): DataSource =
        HikariDataSource().apply {
            jdbcUrl = masterJdbcProperties.jdbcUrl
            username = masterJdbcProperties.username
            password = masterJdbcProperties.password
            driverClassName = masterJdbcProperties.driverClassName
            poolName = "master-hikari-pool"
        }

    /** Hibernate 기반 JPA Vendor 설정. */
    @Bean
    fun jpaVendorAdapter(): JpaVendorAdapter = HibernateJpaVendorAdapter().apply {
        setGenerateDdl(false) // 스키마는 수동 SQL로 관리 (테스트 테이블은 직접 생성)
        setShowSql(true)
    }

    /** master DataSource 기반 EntityManagerFactory — com.runnshop 전체 패키지의 @Entity를 스캔한다. */
    @Primary
    @Bean
    fun entityManagerFactory(
        masterDataSource: DataSource,
        jpaVendorAdapter: JpaVendorAdapter
    ): LocalContainerEntityManagerFactoryBean =
        LocalContainerEntityManagerFactoryBean().apply {
            dataSource = masterDataSource
            setJpaVendorAdapter(jpaVendorAdapter)
            setPackagesToScan("com.runnshop")
            setPersistenceUnitName("master")
        }

    /** master DataSource 기반 트랜잭션 매니저 — JPA(상세+CUD) 쪼에서 사용. */
    @Primary
    @Bean
    fun transactionManager(entityManagerFactory: EntityManagerFactory): PlatformTransactionManager =
        JpaTransactionManager(entityManagerFactory)
}
