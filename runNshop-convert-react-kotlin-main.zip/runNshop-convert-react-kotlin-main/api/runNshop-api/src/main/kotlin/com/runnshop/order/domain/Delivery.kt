package com.runnshop.order.domain

import jakarta.persistence.Column
import jakarta.persistence.Entity
import jakarta.persistence.FetchType
import jakarta.persistence.GeneratedValue
import jakarta.persistence.GenerationType
import jakarta.persistence.Id
import jakarta.persistence.JoinColumn
import jakarta.persistence.OneToOne
import jakarta.persistence.Table
import java.math.BigDecimal
import java.time.LocalDateTime

/**
 * ord_delivery — 배송 Entity, Order와 1:1 (ERD §8 원문 컬럼 그대로, plan.md §1.3).
 * DP-클래스설계의 `Shipment`(배송 실행, ord_shipment)와는 다른 개념 — 이번 ERD 범위는 배송 주소/송장
 * 1:1 테이블인 `ord_delivery`이므로 테이블명 그대로 `Delivery`로 신규 생성한다(plan.md §0, Shipment와 혼용 금지).
 * 주문 생성 시점엔 배송정보가 없을 수 있어 optional=true.
 */
@Entity
@Table(name = "ord_delivery")
class Delivery(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    val id: Long = 0,

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "order_id")
    val order: Order,

    /** cfg_delivery_company.id FK — Config 도메인이 이번 범위 밖이라 물리 FK 없이 BIGINT 값만 저장(plan.md §1.7). */
    @Column(name = "delivery_company_id")
    val deliveryCompanyId: Long?,

    @Column(name = "tracking_no")
    val trackingNo: String?,

    @Column(name = "shipping_fee")
    val shippingFee: BigDecimal,

    @Column(name = "shipping_fee_payer")
    val shippingFeePayer: String,

    @Column(name = "status")
    var status: String,

    @Column(name = "shipped_at")
    val shippedAt: LocalDateTime?,

    @Column(name = "delivered_at")
    val deliveredAt: LocalDateTime?,

    @Column(name = "return_tracking_no")
    val returnTrackingNo: String?,

    @Column(name = "created_at")
    val createdAt: LocalDateTime,

    @Column(name = "updated_at")
    val updatedAt: LocalDateTime,

    @Column(name = "is_deleted")
    val isDeleted: Boolean,

    @Column(name = "deleted_at")
    val deletedAt: LocalDateTime?,

    @Column(name = "deleted_by")
    val deletedBy: String?
) {
    // JPA 기본 생성자 요구사항 — Hibernate가 리플렉션으로 인스턴스를 만들 때 사용
    constructor() : this(
        order = Order(), deliveryCompanyId = null, trackingNo = null, shippingFee = BigDecimal.ZERO,
        shippingFeePayer = "", status = "", shippedAt = null, deliveredAt = null, returnTrackingNo = null,
        createdAt = LocalDateTime.now(), updatedAt = LocalDateTime.now(), isDeleted = false,
        deletedAt = null, deletedBy = null
    )
}
