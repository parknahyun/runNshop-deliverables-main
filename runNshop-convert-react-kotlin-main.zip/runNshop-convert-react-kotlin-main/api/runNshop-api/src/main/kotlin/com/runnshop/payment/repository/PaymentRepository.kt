package com.runnshop.payment.repository

import com.runnshop.payment.domain.Payment
import org.springframework.data.jpa.repository.JpaRepository

/**
 * pay_payment Repository (JPA, master 계정). DP-클래스설계/payment.md §2 패키지트리에 이미 이름이
 * 정의돼 있어 그대로 사용한다(design.md §3).
 */
interface PaymentRepository : JpaRepository<Payment, Long> {

    /** 주문의 결제 행 전체(복합결제는 수단별 여러 행) — 생성 순. getPaymentInfo()와 결제번호/결제 시도 번호 채번에 쓴다. */
    fun findByPlatformOrderIdOrderByIdAsc(platformOrderId: Long): List<Payment>
}
