package com.runnshop.order.mapper

/**
 * admin 주문현황(목록) DB 연동용 MyBatis Mapper (slave 계정, 읽기전용).
 * 동적 검색 조건(keyword/status/from~to)이 있는 목록·건수·요약 쿼리를 담당한다 — ord_order 테이블 대상
 * (옛 TestAdminOrderMapper와 시그니처 동일, 대상 테이블만 ord_order로 교체).
 * XML: resources/mapper/order/OrderMapper.xml
 */
interface OrderMapper {

    /** 공유조건(keyword+dateRange)+status로 필터링된 목록을 페이징해 조회한다. */
    fun selectList(
        keyword: String?,
        status: String?,
        from: String?,
        to: String?,
        offset: Int,
        limit: Int
    ): List<OrderRow>

    /** selectList와 동일 WHERE(status 포함) 조건의 전체 건수. */
    fun countList(
        keyword: String?,
        status: String?,
        from: String?,
        to: String?
    ): Int

    /** 공유조건(keyword+dateRange)만 적용한, status별 건수 집계 (목록 필터와 무관한 전체 상태 분포). */
    fun selectStatusSummary(
        keyword: String?,
        from: String?,
        to: String?
    ): List<StatusCountRow>
}

/**
 * MyBatis 결과 매핑용 — admin 목록 응답(orders[] 항목)의 원시 컬럼 1행. ord_platform_order 기준
 * (base table 전환, design.md §2-3). vendorId는 대표(최소 order id) vendor의 id — 플랫폼주문에 vendor
 * order가 1건뿐이면 그 vendor 자신, 여러 건이면 Service가 vendorCount와 함께 "대표 외 N곳"으로 포맷한다.
 * itemCount/vendorCount는 신규(design.md §2-3) — Service의 "대표+외N건/곳" 가공용 원재료이며 JSON에는
 * 노출하지 않는다.
 * [backend-service-pattern 적용] customer/vendorName(표시용 이름)은 이 Row에 담지 않는다 — 고객명/판매자명은
 * Member/Vendor 도메인 소유 데이터라 SQL CASE로 이 Mapper가 직접 채우지 않고, memberId/vendorId 원시값만
 * 반환해 Service(OrderService.getAdminOrders())가 MemberApi/VendorApi 배치 호출로 채운다.
 */
data class OrderRow(
    val orderId: String,
    val platformOrderNo: String,
    val productName: String,
    val memberId: String,
    val vendorId: String,
    val itemCount: Int,
    val vendorCount: Int,
    val status: String,
    val amount: Long,
    val orderDate: String
)

/** status별 집계 결과 1행 (기존 이름 재사용). */
data class StatusCountRow(
    val status: String,
    val count: Int
)
