package com.runnshop.order.domain

import jakarta.persistence.Column
import jakarta.persistence.Entity
import jakarta.persistence.FetchType
import jakarta.persistence.GeneratedValue
import jakarta.persistence.GenerationType
import jakarta.persistence.Id
import jakarta.persistence.JoinColumn
import jakarta.persistence.ManyToOne
import jakarta.persistence.Table
import java.math.BigDecimal
import java.time.LocalDateTime

/**
 * ord_platform_order_discount — 플랫폼 주문 할인 Entity (ERD §8 14개 컬럼 + 비정규화 coupon_code 1개 = 15개 컬럼,
 * design-02-entity.md §2-2). 완전 신규 식별자(DP/DL에 이름 없음) — ERD 테이블명 PascalCase 변환 패턴을 따라 명명.
 *
 * 쿠폰 적용 시에만 1건 생성(옵션 처리) — 쿠폰 미적용이면 이 Entity 자체를 생성하지 않는다.
 * promotionId(ERD Long?)와 요청 바디 couponId(String, 예: "CPN-001")의 타입 불일치는 TODO로 남기고,
 * couponCode(비정규화)에 쿠폰 코드 원문을 보관한다(design.md §3-1 Finding 5).
 */
@Entity
@Table(name = "ord_platform_order_discount")
class PlatformOrderDiscount(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    val id: Long = 0,

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "platform_order_id")
    val platformOrder: PlatformOrder,

    /** 'ORDER_COUPON' 고정(이번 라운드는 쿠폰만, CART_DISCOUNT는 범위 밖). */
    @Column(name = "discount_type")
    val discountType: String,

    /** request.couponId(String)를 매핑할 실제 Promotion PK를 모르므로 항상 null(TODO, §3-1 Finding 5). */
    @Column(name = "promotion_id")
    val promotionId: Long? = null,

    /** ERD 범위 밖 비정규화 컬럼 — promotionId와 별개로 쿠폰 코드 원문을 보관(design.md §3-1 Finding 5). */
    @Column(name = "coupon_code")
    val couponCode: String? = null,

    @Column(name = "discount_amount")
    val discountAmount: BigDecimal,

    /**
     * 플랫폼/판매자 분담 비율 — 공식의 입력값(`prm_coupon.issuer_type`(PLATFORM·VENDOR),
     * `prm_coupon.cost_share_rate` DECIMAL(5,2), ERD Promotion `prm_coupon` 1439/1461행)은 이미 모델링돼
     * 있으나, (a) Order가 호출하는 `order.port.PromotionApi.validateCoupon()`의 반환형
     * `CouponDiscountResult`에 이 두 값이 아직 노출되지 않았고, (b) 이 비용 분담 정책을 서술하는 as-is
     * 정책서 2건(`09-promotion.md` 29행, `10-settlement.md` 28행)이 모두 문서 헤더에서 "상태: 초안(Draft)"을
     * 선언하고 분담 비율도 산식이 아닌 "계약 비율"/"계약서에 따름"(외부 계약 참조)으로만 서술해 아직
     * 확정되지 않았다 (order-placeorder-design-gaps/design.md §3 조사 결과). 두 조건이 해소되기 전까지
     * 공식을 추측해 구현하지 않고 0으로 유지한다 — Promotion이 `CouponDiscountResult`에
     * `issuerType`/`costShareRate`를 추가 노출하고 정책이 확정되면, 그 값으로 `platformShare`/`vendorShare`를
     * 계산하는 것이 다음 단계다.
     */
    @Column(name = "platform_share")
    val platformShare: BigDecimal = BigDecimal.ZERO,

    /** 동일 사유(위 platformShare KDoc 참고) — 0으로 유지. */
    @Column(name = "vendor_share")
    val vendorShare: BigDecimal = BigDecimal.ZERO,

    @Column(name = "partial_cancel_policy")
    val partialCancelPolicy: String = "KEEP",

    @Column(name = "is_revoked")
    val isRevoked: Boolean = false,

    @Column(name = "created_at")
    val createdAt: LocalDateTime,

    @Column(name = "updated_at")
    val updatedAt: LocalDateTime,

    @Column(name = "is_deleted")
    val isDeleted: Boolean = false,

    @Column(name = "deleted_at")
    val deletedAt: LocalDateTime? = null,

    @Column(name = "deleted_by")
    val deletedBy: String? = null
) {
    // JPA 기본 생성자 요구사항 — Hibernate가 리플렉션으로 인스턴스를 만들 때 사용
    constructor() : this(
        platformOrder = PlatformOrder(), discountType = "", discountAmount = BigDecimal.ZERO,
        createdAt = LocalDateTime.now(), updatedAt = LocalDateTime.now()
    )
}
