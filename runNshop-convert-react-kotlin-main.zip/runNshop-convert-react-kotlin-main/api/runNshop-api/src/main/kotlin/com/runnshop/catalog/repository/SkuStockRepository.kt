package com.runnshop.catalog.repository

import com.runnshop.catalog.domain.SkuStock
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Modifying
import org.springframework.data.jpa.repository.Query
import org.springframework.data.repository.query.Param

interface SkuStockRepository : JpaRepository<SkuStock, Long> {

    /** 재고가 충분할 때만 차감한다(조건부 UPDATE로 동시 차감에서도 음수 방지). 반환값 = 갱신 행 수(0이면 부족/미등록). */
    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("update SkuStock s set s.stockQty = s.stockQty - :qty, s.updatedAt = CURRENT_TIMESTAMP where s.skuId = :skuId and s.stockQty >= :qty")
    fun deduct(@Param("skuId") skuId: Long, @Param("qty") qty: Int): Int

    /** 차감분을 되돌린다(보상). */
    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("update SkuStock s set s.stockQty = s.stockQty + :qty, s.updatedAt = CURRENT_TIMESTAMP where s.skuId = :skuId")
    fun restore(@Param("skuId") skuId: Long, @Param("qty") qty: Int): Int
}
