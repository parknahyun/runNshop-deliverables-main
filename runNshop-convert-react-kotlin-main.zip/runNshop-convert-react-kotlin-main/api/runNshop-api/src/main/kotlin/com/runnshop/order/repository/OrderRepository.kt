package com.runnshop.order.repository

import com.runnshop.order.domain.Order
import org.springframework.data.jpa.repository.EntityGraph
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Query
import org.springframework.data.repository.query.Param
import java.time.LocalDateTime

/**
 * ord_order Repository (JPA, master 계정).
 * 기본 `findById`(연관관계 LAZY, 메타데이터만 필요한 경우) 외에, 상세 조회 전용으로
 * items/delivery를 즉시 로딩하는 `findDetailById`를 둔다(plan.md §1.5 fetch 전략 — 상세 조회는
 * 단건이라 N+1이 치명적이진 않지만 조회 왕복을 줄이기 위해 @EntityGraph를 적용).
 * claims는 EntityGraph에 포함하지 않는다 — items와 claims를 동시에 fetch join하면 Hibernate가
 * `MultipleBagFetchException`(컬렉션 2개를 동시에 bag으로 fetch join 불가)을 던진다. claims는
 * order.claims 접근 시 별도 쿼리로 LAZY 로딩되며, 단건 조회라 추가 쿼리 1회는 허용 범위다.
 * 목록/동적검색은 MyBatis(slave, OrderMapper)가 담당하므로 이 Repository에 두지 않는다.
 */
interface OrderRepository : JpaRepository<Order, Long> {

    @EntityGraph(attributePaths = ["items", "delivery"])
    fun findDetailById(id: Long): Order?

    /** 당일 생성 건수를 세어 과거 vendor orderNo 채번용(현재는 플랫폼 주문번호 본문+순번 사용). */
    fun countByCreatedAtBetween(from: LocalDateTime, to: LocalDateTime): Long

    /**
     * partner 상세 전용(완전 신규, design.md §2-2/§3-6) — 같은 platformOrder에 속하지만 "내 vendor"가 아닌
     * 다른 vendor의 order들을 items와 함께 조회한다. Order에 스칼라 필드 platformOrderId가 없고
     * platformOrder(연관관계) + id 경로로만 접근 가능해 Spring Data 메서드명 파생이 모호할 수 있어
     * JPQL로 명시한다. items만 fetch join한다(delivery/claims는 응답에 노출하지 않으므로 로딩 자체가
     * 불필요 — "타 vendor 상품은 상품명/수량/금액만" 정책과 쿼리 레벨에서부터 맞춘다).
     */
    @Query("SELECT o FROM Order o LEFT JOIN FETCH o.items WHERE o.platformOrder.id = :platformOrderId AND o.vendorId <> :vendorId")
    fun findSiblingOrdersWithItems(@Param("platformOrderId") platformOrderId: Long, @Param("vendorId") vendorId: Long): List<Order>
}
