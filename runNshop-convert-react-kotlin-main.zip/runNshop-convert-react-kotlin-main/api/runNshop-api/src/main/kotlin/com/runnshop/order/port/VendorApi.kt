package com.runnshop.order.port

/**
 * Order가 Vendor 도메인을 조회하는 Port 인터페이스(도메인 경계를 넘는 호출 계약, 완전 신규,
 * 1차 근거 어디에도 정의 없음 — 패키지/이름이 `order.publicapi.VendorPublicApi`에서 `order.port.VendorApi`로
 * 변경됨, 사유: SKILL.md "타 도메인 PublicApi 호출" 네이밍 간소화 결정).
 * 구현체는 제공 도메인(vendor.service.VendorService)에 있고 Spring DI로 이 인터페이스 타입에 주입된다.
 *
 * [backend-service-pattern 적용] 기존에는 Order가 판매자명을 `AdminVendorName`(1~8 고정 Map)으로 자체
 * 보유했으나, 판매자명은 Vendor 도메인 소유 데이터라 도메인 경계를 넘는 조회는 Port로 가야 한다는
 * 코딩표준에 따라 신규 생성 — PaymentApi/PromotionApi/MemberApi와 동일한 패턴
 * (Order 소유 인터페이스 + 제공 도메인의 Mock 구현체).
 */
interface VendorApi {

    /** 판매자 1곳의 표시용 이름을 조회한다. admin 주문상세(단건)에서 쓴다. */
    fun getVendorName(vendorId: String): String?

    /**
     * 여러 판매자의 표시용 이름을 배치로 조회한다. admin 주문목록(N건)에서 행마다 Port를 호출하는
     * N+1 패턴을 피하기 위해 별도 시그니처로 둔다.
     */
    fun getVendorNames(vendorIds: List<String>): Map<String, String>
}
