package com.runnshop.order.service

import com.runnshop.order.domain.OrderStatusHistory
import com.runnshop.order.mapper.OrderStatusHistoryMapper
import com.runnshop.order.mapper.StatusHistoryRow
import com.runnshop.order.domain.StatusTargetType
import com.runnshop.order.repository.OrderStatusHistoryRepository
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import java.time.LocalDateTime

/**
 * 상태전이 이력 기록/조회. 상태를 바꾸는 모든 경로(주문·결제·배송·클레임)는 상태 변경과 같은 트랜잭션에서
 * [record]를 호출해야 한다 — 상태 변경이 롤백되면 이력도 함께 롤백된다.
 * 상태가 실제로 바뀌지 않은 경우(from == to)는 기록하지 않는다.
 */
@Service
@Transactional
class OrderStatusHistoryService(
    private val repository: OrderStatusHistoryRepository, // 등록: JPA(master)
    private val mapper: OrderStatusHistoryMapper // 목록 조회: MyBatis(slave)
) {

    fun record(
        platformOrderId: Long,
        targetType: StatusTargetType,
        fromStatus: String?,
        toStatus: String,
        orderId: Long? = null,
        targetId: Long? = null,
        changedBy: String = "SYSTEM",
        reason: String? = null,
        at: LocalDateTime = LocalDateTime.now()
    ) {
        if (fromStatus == toStatus) return
        repository.save(
            OrderStatusHistory(
                platformOrderId = platformOrderId,
                orderId = orderId,
                targetType = targetType.name,
                targetId = targetId,
                fromStatus = fromStatus,
                toStatus = toStatus,
                changedBy = changedBy,
                reason = reason,
                createdAt = at
            )
        )
    }

    @Transactional(readOnly = true)
    fun findByPlatformOrderId(platformOrderId: Long): List<StatusHistoryRow> =
        mapper.selectByPlatformOrderId(platformOrderId)
}
