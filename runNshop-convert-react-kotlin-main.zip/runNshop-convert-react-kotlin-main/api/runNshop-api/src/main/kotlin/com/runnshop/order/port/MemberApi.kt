package com.runnshop.order.port

/**
 * Order가 Member 도메인을 조회하는 Port 인터페이스(도메인 경계를 넘는 호출 계약, 완전 신규,
 * design-03-publicapi.md §2 — 패키지/이름이 `order.publicapi.MemberPublicApi`에서 `order.port.MemberApi`로
 * 변경됨, 사유: SKILL.md "타 도메인 PublicApi 호출" 네이밍 간소화 결정).
 * 구현체는 제공 도메인(member.service.MemberService)에 있고 Spring DI로 이 인터페이스 타입에 주입된다.
 * `getPointBalance` 시그니처는 `DP-클래스설계/common.md` §5 원안을 그대로 재사용(work-scope 1차 근거 재검색 결과).
 */
interface MemberApi {

    /** 회원 1명의 포인트 잔액을 조회한다. 결제확정 시 pointUsed 검증에 쓰인다. */
    fun getPointBalance(memberId: String): PointInfo

    /**
     * 회원 1명의 표시용 이름(마스킹)을 조회한다. admin 주문상세(단건)에서 쓴다.
     * [backend-service-pattern 적용] 기존에는 Order가 `AdminCustomerName`(1~8 고정 Map)을 자체 보유했으나,
     * 고객명은 Member 도메인 소유 데이터라 도메인 경계를 넘는 조회는 Port로 가야 한다는 코딩표준에 따라
     * 신규 추가 — 1차 근거(common.md §5)에 없던 메서드다(work-scope: Order 도메인 작업 중 신규 명명).
     */
    fun getMemberName(memberId: String): String?

    /**
     * 여러 회원의 표시용 이름을 배치로 조회한다. admin 주문목록(N건)에서 행마다 Port를 호출하는
     * N+1 패턴을 피하기 위해 별도 시그니처로 둔다(getMemberName과 동일 이유로 신규 추가).
     */
    fun getMemberNames(memberIds: List<String>): Map<String, String>
}

/**
 * 완전 신규 DTO(design-03-publicapi.md §2) — 이번 범위는 "잔액 조회+검증"만이라 usable/min_use는 포함하지 않고
 * balance 1개 필드만 둔다(기존 Mock `mobile__POST_my_orders_sheet.json`의 `point.balance` 네이밍 재사용).
 */
data class PointInfo(
    val balance: Int
)
