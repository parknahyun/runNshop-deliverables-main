package com.runnshop.order.service

import com.runnshop.order.domain.OutboxEventType
import com.runnshop.order.domain.PlatformOrder
import com.runnshop.order.domain.StatusTargetType
import com.runnshop.order.dto.OrderEventGiveUpRequest
import com.runnshop.order.dto.OrderEventProcessRequest
import com.runnshop.order.dto.OrderEventProcessResult
import com.runnshop.order.port.CatalogApi
import com.runnshop.order.port.PaymentApi
import com.runnshop.order.port.StockDeductItem
import com.runnshop.order.repository.PlatformOrderRepository
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import java.time.LocalDateTime

/**
 * 컨슈머 앱이 내부 API로 호출하는 주문 이벤트 **업무 처리**. 이벤트 테이블(조회·상태 변경·재시도 횟수·후속 이벤트 적재)은
 * 컨슈머 앱이 맡고, 여기서는 주문 상태 전이와 타 도메인 Port 호출만 한다. 요청 1건 = 트랜잭션 1개.
 *
 * STOCK_DEDUCT_REQUESTED: 상품 API(CatalogApi)로 재고 차감 → STOCK_DEDUCTED / 부족 시 STOCK_FAILED.
 * PAYMENT_REQUESTED: PG 결제요청(PaymentApi) → DEPOSIT_PENDING.
 * 멱등: 이미 처리된 주문이면 재처리 없이 현재 업무 상태를 결과로 돌려준다.
 */
@Service
@Transactional
class OrderEventHandler(
    private val platformOrderRepository: PlatformOrderRepository,
    private val catalogApi: CatalogApi,
    private val paymentApi: PaymentApi,
    private val statusHistoryService: OrderStatusHistoryService
) {

    /** 이벤트 유형에 맞는 업무 처리를 수행하고 처리 후 업무 상태를 반환한다. */
    fun process(request: OrderEventProcessRequest): OrderEventProcessResult {
        val order = platformOrderRepository.findById(request.platformOrderId).orElse(null)
            ?: return OrderEventProcessResult("SKIPPED", "주문 없음 platformOrderId=${request.platformOrderId}")
        return when (request.eventType) {
            OutboxEventType.STOCK_DEDUCT_REQUESTED -> deductStock(order)
            OutboxEventType.PAYMENT_REQUESTED -> requestPayment(order, request.payload)
            else -> OrderEventProcessResult("SKIPPED", "알 수 없는 이벤트 타입 ${request.eventType}")
        }
    }

    /**
     * 컨슈머가 재시도를 소진한 이벤트의 업무 실패 전이. 재고차감 이벤트는 부분 차감분을 되돌리고(보상) 주문을 STOCK_FAILED로 바꿔
     * 접수 상태로 남지 않게 한다.
     */
    fun giveUp(request: OrderEventGiveUpRequest) {
        if (request.eventType != OutboxEventType.STOCK_DEDUCT_REQUESTED) return
        val order = platformOrderRepository.findById(request.platformOrderId).orElse(null)
            ?.takeIf { it.status == "STOCK_REQUESTED" } ?: return
        catalogApi.restoreStock(order.platformOrderNo)
        changeStatus(order, "STOCK_FAILED", "재고 차감 실패(재시도 초과, 차감분 복원): ${request.reason?.take(200)}")
    }

    /**
     * 재고를 SKU 단위로 차감한다. 일부 SKU가 실패하면 주문 상태는 그대로 두고 `STOCK_PARTIAL`을 반환한다 — 성공한 SKU의 차감은 유지되고
     * 컨슈머가 이벤트를 재시도하면 이미 차감한 SKU는 건너뛰고 **실패한 SKU만** 다시 차감한다(재시도 소진 시 [giveUp]).
     */
    private fun deductStock(order: PlatformOrder): OrderEventProcessResult {
        when (order.status) {
            "STOCK_REQUESTED" -> Unit
            "STOCK_FAILED" -> return OrderEventProcessResult("STOCK_FAILED", "이미 재고 차감 실패 처리됨")
            // 차감 이후 단계(STOCK_DEDUCTED/DEPOSIT_PENDING 등)면 차감은 완료된 것 — 컨슈머가 이벤트 상태를 못 바꾸고 재호출한 경우의 멱등 응답
            else -> return OrderEventProcessResult("STOCK_DEDUCTED", "이미 재고 차감 완료됨(상태 ${order.status})")
        }
        val items = order.orders.flatMap { o -> o.items.map { StockDeductItem(skuId = it.skuId, quantity = it.quantity) } }
        val result = catalogApi.deductStock(order.platformOrderNo, items)
        if (!result.success) {
            return OrderEventProcessResult("STOCK_PARTIAL", "재고 차감 실패 SKU: " + result.failures.joinToString("; ") { it.reason })
        }
        changeStatus(order, "STOCK_DEDUCTED", "재고 차감 완료(상품 API)")
        return OrderEventProcessResult("STOCK_DEDUCTED")
    }

    private fun requestPayment(order: PlatformOrder, method: String?): OrderEventProcessResult {
        if (order.status == "DEPOSIT_PENDING") return OrderEventProcessResult("DEPOSIT_PENDING", "이미 PG 요청 완료됨")
        if (order.status != "STOCK_DEDUCTED") return OrderEventProcessResult("SKIPPED", "건너뜀: 주문 상태 ${order.status}")
        val paymentMethod = method ?: throw IllegalStateException("결제수단 payload 없음 platformOrderId=${order.id}")
        // 복합결제: PG 결제수단 금액(포인트 차감 후 결제금액)과 포인트 사용분을 결제수단별 행으로 나눠 요청한다.
        paymentApi.requestPayment(
            order.id.toString(), order.platformOrderNo, order.memberId.toString(),
            order.paymentAmount.toInt(), paymentMethod, order.pointUsedAmount
        )
        changeStatus(order, "DEPOSIT_PENDING", "PG 결제 요청")
        return OrderEventProcessResult("DEPOSIT_PENDING")
    }

    /** 플랫폼주문/vendor 주문/주문상품 상태를 함께 바꾸고 주문상태 이력을 남긴다. */
    private fun changeStatus(order: PlatformOrder, to: String, reason: String) {
        val from = order.status
        val now = LocalDateTime.now()
        order.status = to
        order.updatedAt = now
        order.orders.forEach { o ->
            o.status = to
            o.items.forEach { it.status = to }
        }
        platformOrderRepository.save(order)
        statusHistoryService.record(order.id, StatusTargetType.ORDER, from, to, targetId = order.id, reason = reason, at = now)
    }
}
