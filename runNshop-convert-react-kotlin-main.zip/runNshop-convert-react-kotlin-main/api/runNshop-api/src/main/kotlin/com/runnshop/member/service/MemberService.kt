package com.runnshop.member.service

import com.runnshop.common.MockLoader
import com.runnshop.order.port.MemberApi
import com.runnshop.order.port.PointInfo
import org.springframework.stereotype.Service

/** Mock 파일명 — 메서드마다 하드코딩하지 않고 한곳에 모아 오타를 컴파일 타임에 잡는다. */
private object MockFile {
    const val INTERNAL_POINT_BALANCE = "mobile__GET_internal_point_balance.json"
}

/**
 * memberId → 표시용 이름(마스킹) 임시 매핑. 실제 회원 프로필 테이블이 아직 모델링되지 않아
 * Mock 고정값으로 대체한다 — 기존에 Order가 `OrderService.AdminCustomerName`으로 들고 있던 매핑을
 * 그대로 옮긴 것이다(backend-service-pattern 코딩표준: 제공 도메인이 자신의 데이터를 소유해야 함).
 * 실제 회원 테이블이 생기면 이 Map은 DB 조회로 교체되어야 한다.
 */
private val memberNames = mapOf(
    "1" to "홍*동", "2" to "김*수", "3" to "이*미", "4" to "박*희",
    "5" to "최*준", "6" to "정*영", "7" to "강*현", "8" to "윤*서"
)

/**
 * Member 도메인 서비스. 이번 범위는 `MemberApi`(도메인 경계 Port)의 포인트 잔액·회원명 조회만 담당하며,
 * 포인트 잔액은 memberId와 무관하게 고정값 15000을 반환한다(작업 지시 "포인트 잔액은 mock데이타로 15000포인트 고정").
 * 회원명은 위 `memberNames` 고정 매핑표 밖의 memberId면 null을 반환한다(호출부가 "비회원" 등으로 폴백).
 * DP가 정의할 완전한 Member Service(주소/프로필 CRUD 등)는 범위 밖이며 이 파일에 추가하지 않는다
 * (work-scope: Order 도메인 작업 중 사용자 승인을 받은 좁은 예외 범위, design-03-publicapi.md §2).
 */
@Service
class MemberService(
    private val mockLoader: MockLoader
) : MemberApi {

    /**
     * 회원 1명의 포인트 잔액을 조회한다(MemberApi 구현). memberId별 구분 없이 Mock 고정값 15000을 반환한다.
     */
    override fun getPointBalance(memberId: String): PointInfo {
        val loaded = mockLoader.load("member", MockFile.INTERNAL_POINT_BALANCE)
        @Suppress("UNCHECKED_CAST")
        val data = loaded["data"] as Map<String, Any?>
        return PointInfo(balance = (data["balance"] as Number).toInt())
    }

    /** 회원 1명의 표시용 이름을 조회한다(MemberApi 구현). 매핑표 밖이면 null. */
    override fun getMemberName(memberId: String): String? = memberNames[memberId]

    /** 여러 회원의 표시용 이름을 배치로 조회한다(MemberApi 구현). 매핑표 밖인 memberId는 결과 Map에서 생략된다. */
    override fun getMemberNames(memberIds: List<String>): Map<String, String> =
        memberIds.mapNotNull { id -> memberNames[id]?.let { id to it } }.toMap()
}
