package com.runnshop.order.port

/**
 * Order가 Catalog(상품) 도메인에 재고 차감을 요청하는 Port 인터페이스(PaymentApi/PromotionApi와 동일 패턴 —
 * Order 소유 인터페이스 + 제공 도메인(catalog.service.StockService)의 구현체).
 * 주문 접수 시 동기로 호출하지 않고, 컨슈머 앱이 호출하는 내부 API 처리(OrderEventHandler)에서 호출한다.
 */
interface CatalogApi {

    /**
     * SKU별 재고를 차감한다. **SKU 단위로 독립 처리**한다 — 일부 SKU가 실패해도 성공한 SKU의 차감은 유지되고,
     * 같은 `requestId`(주문의 platformOrderNo)로 다시 호출하면 이미 차감한 SKU는 건너뛰고 **실패했던 SKU만** 재차감한다(멱등·부분 재시도).
     * 재고 부족/미등록 SKU는 예외가 아니라 `failures`로 돌려준다.
     */
    fun deductStock(requestId: String, items: List<StockDeductItem>): StockDeductResult

    /** `requestId`로 차감된 재고를 전부 되돌린다(재시도를 포기하는 등 주문을 실패 처리할 때의 보상). 멱등하다. */
    fun restoreStock(requestId: String)
}

data class StockDeductItem(val skuId: Long, val quantity: Int)

data class StockDeductResult(val failures: List<StockDeductFailure> = emptyList()) {
    /** 모든 SKU 차감 완료(이전 호출에서 차감된 SKU 포함). */
    val success: Boolean get() = failures.isEmpty()
}

data class StockDeductFailure(val skuId: Long, val reason: String)
