package com.runnshop.order.dto

/**
 * PATCH .../my/cart/items/{cartItemId}/quantity 성공 응답 DTO (DL §3, DP-클래스설계/order.md §3
 * `CartService.updateQuantity()` 반환 타입으로 이미 정의된 이름). 필드는 DL §3 응답 예시
 * `{ cartItemId, quantity, subtotal }` 그대로 camelCase다 — 이 코드베이스의 "DTO로 만든 응답은
 * Kotlin 필드명 그대로(camelCase) 직렬화" 규칙(design.md 과업2 결정 2) 적용.
 *
 * `subtotal`을 `Int`로 두는 이유: Mock 가격이 전부 원 단위 정수이고 quantity(1~99)와 곱해도 Int
 * 범위를 넘지 않는다 — `PayResponse.totalPayment`(BigDecimal)와 다른 이유는 이 응답이 소수점 금액
 * (할부 등)을 다루지 않기 때문.
 */
data class CartItemResponse(val cartItemId: String, val quantity: Int, val subtotal: Int)
