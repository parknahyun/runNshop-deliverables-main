package com.runnshop.order.repository

import com.runnshop.order.domain.PlatformOrder
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Query
import org.springframework.data.repository.query.Param
import java.time.LocalDateTime

/**
 * ord_platform_order Repository (JPA, master 계정). PlatformOrder가 애그리거트 루트라 Order/OrderItem/
 * PlatformOrderDiscount는 자체 Repository 없이 cascade(ALL)로 이 Repository를 통해서만 저장된다
 * (design-02-entity.md §3). placeOrder()는 save()를 1차(자식 없음, id 확보용)·2차(자식 포함) 두 번 호출한다
 * ("2단계 저장", design.md §3-1).
 *
 * countByOrderedAtBetween: 당일 생성 건수를 세어 platformOrderNo(PyyMMdd-NNNNN-00) 채번에 쓴다
 * (design-02-entity.md §3, 6차 리뷰 반영 Finding G — derived query, 구현 코드 없이 시그니처만 선언하면 자동 구현됨).
 */
interface PlatformOrderRepository : JpaRepository<PlatformOrder, Long> {

    fun countByOrderedAtBetween(from: LocalDateTime, to: LocalDateTime): Long

    /** 주문서(sheetId = platformOrderNo)로 진입 시 생성된 임시주문을 찾는다 — placeOrder가 이어받는다. */
    fun findByPlatformOrderNo(platformOrderNo: String): PlatformOrder?

    /**
     * mobile "내 주문" 목록 — 로그인 회원(memberId) 소유 플랫폼주문 전체, 최신순. (완전 신규, design.md §3-3)
     * 목록은 "대표 상품명 + 외 N건" 가공이 필요해 orders/items를 fetch join하지 않고 PlatformOrder 자체
     * 필드(상태/금액/주문일시)만 가져온다 — 대표 상품명/vendor는 호출부가 po.orders.firstOrNull()?.items로
     * LAZY 접근하며, 건수가 많지 않은 "본인 전체 주문" 특성상 N+1을 허용한다(design.md §7 기록).
     */
    fun findByMemberIdOrderByOrderedAtDesc(memberId: Long): List<PlatformOrder>

    /**
     * admin/mobile 상세 — PlatformOrder 1건 + 하위 orders[]를 JPQL로 즉시 로딩한다. (완전 신규, design.md §3-2/§3-4)
     * "orders"만 fetch join하고 "orders.items"는 fetch join하지 않는다 — OrderRepository.findDetailById()가
     * items+claims 동시 fetch join 시 MultipleBagFetchException을 던진 전례와 동일한 Hibernate 제약
     * (List→List 2단계 fetch join 금지)을 피하기 위함이다. orders.items/orders[].delivery/orders[].claims는
     * 호출부가 접근하는 시점에 vendor order 수(보통 1~3건)만큼 추가 LAZY 쿼리가 발생한다 — 상세 단건 조회라
     * 허용 범위다(design.md §7 기록).
     */
    @Query("SELECT po FROM PlatformOrder po LEFT JOIN FETCH po.orders WHERE po.id = :id")
    fun findDetailById(@Param("id") id: Long): PlatformOrder?
}
