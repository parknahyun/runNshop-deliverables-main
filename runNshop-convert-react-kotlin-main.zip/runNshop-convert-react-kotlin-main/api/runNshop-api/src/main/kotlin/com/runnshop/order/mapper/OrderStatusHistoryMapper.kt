package com.runnshop.order.mapper

/**
 * 주문 상태전이 이력 조회용 MyBatis Mapper (slave 계정, 읽기전용). 이력 "등록"은 JPA(OrderStatusHistoryRepository),
 * 플랫폼주문 1건의 이력 "목록" 조회는 이 Mapper가 담당한다(목록 조회를 JPA Repository에 두지 않는 규칙).
 * XML: resources/mapper/order/OrderStatusHistoryMapper.xml
 */
interface OrderStatusHistoryMapper {

    /** 플랫폼주문 1건의 전체 이력(주문/결제/배송/클레임)을 최신순으로 조회한다. */
    fun selectByPlatformOrderId(platformOrderId: Long): List<StatusHistoryRow>
}

/** 이력 1행. createdAt은 화면 표시 포맷(yyyy-MM-dd HH:mm) 문자열로 조회한다. */
data class StatusHistoryRow(
    val targetType: String,
    val fromStatus: String?,
    val toStatus: String,
    val changedBy: String,
    val reason: String?,
    val createdAt: String
)
