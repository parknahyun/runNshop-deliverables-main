package com.runnshop.order.domain

import jakarta.persistence.Column
import jakarta.persistence.Entity
import jakarta.persistence.FetchType
import jakarta.persistence.GeneratedValue
import jakarta.persistence.GenerationType
import jakarta.persistence.Id
import jakarta.persistence.JoinColumn
import jakarta.persistence.ManyToOne
import jakarta.persistence.Table
import java.math.BigDecimal
import java.time.LocalDateTime

/**
 * ord_claim — 클레임(취소/반품/교환) Entity, Order와 1:N (ERD §8 원문 컬럼 그대로, plan.md §1.4).
 * 클레임은 주문과 독립적인 라이프사이클을 가지므로(접수 후 주문과 별개로 상태 전이) Order 쪽
 * 연관관계에 cascade=[PERSIST, MERGE]만 적용하고 orphanRemoval=false(plan.md §1.5).
 */
@Entity
@Table(name = "ord_claim")
class Claim(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    val id: Long = 0,

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "order_id")
    val order: Order,

    @Column(name = "claim_no")
    val claimNo: String,

    @Column(name = "claim_type")
    val claimType: String,

    @Column(name = "cancel_type")
    val cancelType: String?,

    @Column(name = "status")
    var status: String,

    @Column(name = "blame_type")
    val blameType: String?,

    /** JSONB — 귀책 증빙 이미지 URL 목록. 이번 범위는 원문 그대로(파싱/구조화 없이) 문자열로 보관한다. */
    @Column(name = "blame_evidence_urls", columnDefinition = "jsonb")
    val blameEvidenceUrls: String?,

    @Column(name = "reason")
    val reason: String?,

    @Column(name = "channel")
    val channel: String,

    @Column(name = "counselor_id")
    val counselorId: Long?,

    @Column(name = "counselor_memo")
    val counselorMemo: String?,

    @Column(name = "refund_amount")
    val refundAmount: BigDecimal,

    @Column(name = "extra_delivery_fee")
    val extraDeliveryFee: BigDecimal,

    @Column(name = "extra_payment_id")
    val extraPaymentId: Long?,

    @Column(name = "extra_payment_status")
    val extraPaymentStatus: String?,

    @Column(name = "completed_at")
    val completedAt: LocalDateTime?,

    @Column(name = "created_at")
    val createdAt: LocalDateTime,

    @Column(name = "updated_at")
    val updatedAt: LocalDateTime,

    @Column(name = "is_deleted")
    val isDeleted: Boolean,

    @Column(name = "deleted_at")
    val deletedAt: LocalDateTime?,

    @Column(name = "deleted_by")
    val deletedBy: String?
) {
    // JPA 기본 생성자 요구사항 — Hibernate가 리플렉션으로 인스턴스를 만들 때 사용
    constructor() : this(
        order = Order(), claimNo = "", claimType = "", cancelType = null, status = "", blameType = null,
        blameEvidenceUrls = null, reason = null, channel = "", counselorId = null, counselorMemo = null,
        refundAmount = BigDecimal.ZERO, extraDeliveryFee = BigDecimal.ZERO, extraPaymentId = null,
        extraPaymentStatus = null, completedAt = null,
        createdAt = LocalDateTime.now(), updatedAt = LocalDateTime.now(), isDeleted = false,
        deletedAt = null, deletedBy = null
    )
}
