package com.runnshop.order.repository

import com.runnshop.order.domain.OrderStatusHistory
import org.springframework.data.jpa.repository.JpaRepository

/** 이력 등록(INSERT)만 담당한다 — 이력 목록 조회는 MyBatis(OrderStatusHistoryMapper, slave)가 담당한다. */
interface OrderStatusHistoryRepository : JpaRepository<OrderStatusHistory, Long>
