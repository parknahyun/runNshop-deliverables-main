package com.runnshop.order.domain

import jakarta.persistence.Column
import jakarta.persistence.Entity
import jakarta.persistence.GeneratedValue
import jakarta.persistence.GenerationType
import jakarta.persistence.Id
import jakarta.persistence.Table
import java.time.LocalDateTime

/** 이력 대상 종류 — 주문/결제/배송/클레임 상태전이만 기록한다. */
enum class StatusTargetType { ORDER, PAYMENT, DELIVERY, CLAIM }

/**
 * ord_status_history — 상태전이 이력 Entity (append-only, order-status-history.sql).
 * fromStatus가 null이면 최초 생성(초기 상태 진입)이다. targetId는 대상 레코드 PK
 * (ORDER=ord_order.id 또는 platform order id, PAYMENT=pay_payment.id, DELIVERY=ord_delivery.id, CLAIM=ord_claim.id).
 */
@Entity
@Table(name = "ord_status_history")
class OrderStatusHistory(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    val id: Long = 0,

    @Column(name = "platform_order_id")
    val platformOrderId: Long,

    @Column(name = "order_id")
    val orderId: Long? = null,

    @Column(name = "target_type")
    val targetType: String,

    @Column(name = "target_id")
    val targetId: Long? = null,

    @Column(name = "from_status")
    val fromStatus: String? = null,

    @Column(name = "to_status")
    val toStatus: String,

    @Column(name = "changed_by")
    val changedBy: String = "SYSTEM",

    @Column(name = "reason")
    val reason: String? = null,

    @Column(name = "created_at")
    val createdAt: LocalDateTime = LocalDateTime.now()
) {
    protected constructor() : this(platformOrderId = 0, targetType = "", toStatus = "")
}
