package com.runnshop.order.port

/**
 * Order가 Promotion 도메인을 조회하는 Port 인터페이스(도메인 경계를 넘는 호출 계약, 완전 신규,
 * design-03-publicapi.md §1 — 패키지/이름이 `order.publicapi.PromotionPublicApi`에서
 * `order.port.PromotionApi`로 변경됨, 사유: SKILL.md "타 도메인 PublicApi 호출" 네이밍 간소화 결정).
 * 구현체는 제공 도메인(promotion.service.PromotionService)에 있고 Spring DI로 이 인터페이스 타입에 주입된다.
 *
 * `common.md` §5 원안의 `getAvailableCoupons(memberId, items): CouponListInfo`는 "적용 가능 쿠폰 목록 조회"
 * 목적이라 이번 범위("특정 쿠폰 1건 검증+할인액 계산")와 다르다 — 그대로 재사용하지 않고 `validateCoupon`을
 * 신규 명명한다(common.md의 동사+목적어 패턴을 따르되, "검증+계산"이라는 다른 성격의 동작임을 드러내기 위해
 * `validate` 접두 사용, design-03-publicapi.md §0 근거).
 */
interface PromotionApi {

    /** 쿠폰 1건이 주어진 상품 목록에 적용 가능한지 검증하고 할인액을 계산한다. */
    fun validateCoupon(memberId: String, couponId: String, items: List<CouponCheckItem>): CouponDiscountResult
}

/**
 * 쿠폰 할인 계산에 필요한 최소 정보 — 기존 `OrderItem.kt` 필드명(productId, skuId, priceSale, quantity)과
 * 동일 네이밍을 그대로 가져와 일관성을 유지한다(design-03-publicapi.md §1).
 */
data class CouponCheckItem(
    val productId: Long,
    val skuId: Long?,
    val priceSale: Int,
    val quantity: Int
)

/**
 * 완전 신규 DTO(design-03-publicapi.md §1) — 기존 결과 DTO 네이밍 패턴(`Coupon`+목적+`Info`/`Result`)을 따라 명명.
 * applicable=false면 호출부가 COUPON_NOT_APPLICABLE(422) 처리, discountAmount는 그 경우 0.
 */
data class CouponDiscountResult(
    val couponId: String,
    val applicable: Boolean,
    val discountAmount: Int
)
