package com.runnshop.payment.domain

import jakarta.persistence.Column
import jakarta.persistence.Entity
import jakarta.persistence.GeneratedValue
import jakarta.persistence.GenerationType
import jakarta.persistence.Id
import jakarta.persistence.Table
import java.math.BigDecimal
import java.time.LocalDateTime

/**
 * pay_payment — 결제 Entity (ERD §9 Payment 도메인 기준, design.md §1 결정 1). 2026-10-27 복합결제: 결제수단별 1행(point_amount/card_amount 제거, pay_group_no 추가, platform_order_id UNIQUE 해제).
 * PK는 Order/PlatformOrder와 동일하게 ERD 리터럴 그대로 Long(IDENTITY) 채택(DP-클래스설계/payment.md
 * 원안의 String(ULID) Payment와 다른 결정 — work-scope "1차 근거 기준 정정" 원칙 적용).
 * platformOrderId는 PlatformOrder에 대한 물리 연관관계(@ManyToOne)가 아니라 평문 Long이다 — Payment가
 * Order 도메인 Entity를 직접 참조하면 도메인 경계가 깨진다(design.md §1 결정 1).
 *
 * 이번 라운드는 pay_payment_cancel/pay_extra_payment/pay_payment_log/pay_fds_log(범위 밖)와 연관되는
 * 어떤 필드/행위 메서드도 두지 않는다(design.md §7).
 */
@Entity
@Table(name = "pay_payment")
class Payment(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    val id: Long = 0,

    @Column(name = "payment_no")
    val paymentNo: String,

    @Column(name = "platform_order_id")
    val platformOrderId: Long,

    @Column(name = "member_id")
    val memberId: Long,

    @Column(name = "payment_amount")
    val paymentAmount: BigDecimal,

    @Column(name = "approved_amount")
    val approvedAmount: BigDecimal?,

    @Column(name = "payment_method")
    val paymentMethod: String,

    /** 결제 시도 번호 — 같은 주문의 한 번의 결제 요청(복합결제의 수단별 행들)을 묶는다. 재시도하면 +1. */
    @Column(name = "pay_group_no")
    val payGroupNo: Int = 1,

    @Column(name = "pg_provider")
    val pgProvider: String?,

    @Column(name = "pg_transaction_id")
    val pgTransactionId: String?,

    @Column(name = "pg_approval_no")
    val pgApprovalNo: String?,

    @Column(name = "pg_approved_at")
    val pgApprovedAt: LocalDateTime?,

    @Column(name = "status")
    val status: String,

    @Column(name = "failed_reason")
    val failedReason: String? = null,

    @Column(name = "retry_count")
    val retryCount: Int = 0,

    @Column(name = "created_at")
    val createdAt: LocalDateTime,

    @Column(name = "updated_at")
    val updatedAt: LocalDateTime,

    @Column(name = "is_deleted")
    val isDeleted: Boolean = false,

    @Column(name = "deleted_at")
    val deletedAt: LocalDateTime? = null,

    @Column(name = "deleted_by")
    val deletedBy: String? = null
) {
    // JPA 기본 생성자 요구사항(PlatformOrder.kt와 동일 패턴)
    constructor() : this(
        paymentNo = "", platformOrderId = 0, memberId = 0, paymentAmount = BigDecimal.ZERO,
        approvedAmount = null, paymentMethod = "", pgProvider = null, pgTransactionId = null,
        pgApprovalNo = null, pgApprovedAt = null, status = "", createdAt = LocalDateTime.now(),
        updatedAt = LocalDateTime.now()
    )
}
