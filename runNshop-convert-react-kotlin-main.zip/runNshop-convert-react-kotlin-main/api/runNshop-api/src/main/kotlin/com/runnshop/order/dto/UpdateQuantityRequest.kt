package com.runnshop.order.dto

/** PATCH .../my/cart/items/{cartItemId}/quantity 요청 바디 (DL §3, DP-클래스설계/order.md §3 기존 이름). */
data class UpdateQuantityRequest(val quantity: Int)
