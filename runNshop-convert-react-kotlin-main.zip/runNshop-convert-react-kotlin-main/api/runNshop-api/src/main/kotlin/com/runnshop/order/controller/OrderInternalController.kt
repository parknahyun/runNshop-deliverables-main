package com.runnshop.order.controller

import com.runnshop.order.dto.OrderEventGiveUpRequest
import com.runnshop.order.dto.OrderEventProcessRequest
import com.runnshop.order.service.OrderEventHandler
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RestController

/**
 * 서비스 내부(시스템 간) API — 별도 컨슈머 앱(runNshop-consumer)이 호출한다. 고객/어드민/판매자 채널이 아니므로 채널명 `internal`을 쓴다
 * (Prefix `/api/internal/v1` 하위 전체, 외부 노출 금지 — Gateway에서 차단 대상). 이벤트 조회·상태 관리는 컨슈머 앱 소유이고,
 * 여기서는 업무 처리만 한다. 가공 로직은 OrderEventHandler가 담당한다.
 */
@RestController
class OrderInternalController(private val orderEventHandler: OrderEventHandler) {

    /**
     * 주문 이벤트 1건의 업무를 처리한다(재고차감 요청 → 상품 API 차감, 결제 요청 → PG 요청). 멱등하다 — 이미 처리된 주문이면
     * 현재 업무 상태를 결과(`result`)로 돌려준다. 예외는 그대로 전파(500)되며 재시도 횟수는 컨슈머가 관리한다.
     */
    @PostMapping("/api/internal/v1/order-events/process")
    fun processOrderEvent(@RequestBody request: OrderEventProcessRequest): ResponseEntity<Any> =
        ResponseEntity.ok(mapOf("code" to "SUCCESS", "data" to orderEventHandler.process(request)))

    /** 컨슈머가 재시도를 소진해 이벤트를 포기할 때 업무 쪽 실패 전이(재고차감 이벤트 → 주문 STOCK_FAILED)를 요청한다. */
    @PostMapping("/api/internal/v1/order-events/give-up")
    fun giveUpOrderEvent(@RequestBody request: OrderEventGiveUpRequest): ResponseEntity<Any> {
        orderEventHandler.giveUp(request)
        return ResponseEntity.ok(mapOf("code" to "SUCCESS"))
    }
}
