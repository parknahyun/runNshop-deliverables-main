package com.runnshop.consumer

import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Component
import org.springframework.web.client.RestClient

/** API 서버의 내부 API(`/api/internal/v1/order-events`) 호출 — 컨슈머의 업무 처리는 전부 여기를 통한다. */
@Component
class OrderEventApiClient(@Value("\${order.outbox.api-base-url}") apiBaseUrl: String) {

    private val restClient = RestClient.builder().baseUrl(apiBaseUrl).build()

    /** 이벤트 1건의 업무 처리(재고차감/PG 요청)를 요청하고 처리 후 업무 상태를 받는다. 2xx가 아니면 예외. */
    fun process(eventType: String, platformOrderId: Long, payload: String?): ProcessResult =
        restClient.post().uri("/api/internal/v1/order-events/process")
            .body(mapOf("eventType" to eventType, "platformOrderId" to platformOrderId, "payload" to payload))
            .retrieve().body(ProcessResponse::class.java)?.data
            ?: throw IllegalStateException("처리 API 응답 본문 없음")

    /** 재시도를 소진한 이벤트의 업무 실패 전이를 요청한다(재고차감 이벤트 → 주문 STOCK_FAILED). */
    fun giveUp(eventType: String, platformOrderId: Long, reason: String?) {
        restClient.post().uri("/api/internal/v1/order-events/give-up")
            .body(mapOf("eventType" to eventType, "platformOrderId" to platformOrderId, "reason" to reason))
            .retrieve().toBodilessEntity()
    }
}

data class ProcessResponse(val code: String? = null, val data: ProcessResult? = null)

/** result: STOCK_DEDUCTED / STOCK_FAILED / DEPOSIT_PENDING / SKIPPED */
data class ProcessResult(val result: String, val message: String? = null)
