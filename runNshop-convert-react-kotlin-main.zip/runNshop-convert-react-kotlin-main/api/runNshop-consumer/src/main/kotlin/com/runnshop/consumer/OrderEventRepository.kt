package com.runnshop.consumer

import org.springframework.jdbc.core.simple.JdbcClient
import org.springframework.stereotype.Repository

data class PendingEvent(val id: Long, val eventType: String, val platformOrderId: Long, val payload: String?, val retryCount: Int)

/**
 * ord_outbox_event 조회·상태 변경(컨슈머 소유). 적재(INSERT)는 API가 주문 트랜잭션 안에서 한다.
 *
 * 컨슈머를 여러 개 실행해도 같은 이벤트를 중복 처리하지 않도록 **점유(claim)** 방식을 쓴다: PENDING 이벤트를 `FOR UPDATE SKIP LOCKED`로
 * 가져가며 같은 문장에서 PROCESSING으로 바꾸므로, 인스턴스마다 서로 다른 이벤트를 받는다. 시각 비교는 인스턴스 시계 차이를 피하려고
 * 전부 DB 시각(`now()`)을 쓴다.
 */
@Repository
class OrderEventRepository(private val jdbc: JdbcClient) {

    /** 처리 가능한(PENDING, 재시도 시각 도래) 이벤트를 발행 순으로 최대 [limit]건 점유해 반환한다. */
    fun claim(limit: Int, instanceId: String): List<PendingEvent> =
        jdbc.sql(
            """
            update ord_outbox_event set status = 'PROCESSING', locked_at = now(), locked_by = :instanceId
            where id in (
                select id from ord_outbox_event
                where status = 'PENDING' and next_attempt_at <= now()
                order by id limit :limit for update skip locked
            )
            returning id, event_type, platform_order_id, payload, retry_count
            """.trimIndent()
        ).param("instanceId", instanceId).param("limit", limit)
            .query { rs, _ -> PendingEvent(rs.getLong("id"), rs.getString("event_type"), rs.getLong("platform_order_id"), rs.getString("payload"), rs.getInt("retry_count")) }
            .list().sortedBy { it.id }

    /** 점유한 채 임대 시간([leaseSeconds]) 안에 끝나지 않은(컨슈머 장애 등) 이벤트를 PENDING으로 되돌린다. 되돌린 건수를 반환한다. */
    fun releaseExpired(leaseSeconds: Long): Int =
        jdbc.sql("update ord_outbox_event set status = 'PENDING', locked_at = null, locked_by = null where status = 'PROCESSING' and locked_at < now() - make_interval(secs => :lease)")
            .param("lease", leaseSeconds.toDouble()).update()

    fun markDone(id: Long, note: String?) {
        jdbc.sql("update ord_outbox_event set status = 'DONE', last_error = :note, processed_at = now(), locked_at = null where id = :id")
            .param("note", note?.take(500)).param("id", id).update()
    }

    /**
     * 실패를 기록한다. 한도에 도달(`terminal`)하면 FAILED로 종결하고, 아니면 PENDING으로 되돌리되 [backoffSeconds] 뒤에야
     * 다시 점유되게 한다(API가 잠깐 내려간 경우 재시도를 몇 초 만에 소진하지 않도록).
     */
    fun markRetry(id: Long, error: String, terminal: Boolean, backoffSeconds: Long) {
        jdbc.sql(
            """
            update ord_outbox_event set retry_count = retry_count + 1, last_error = :error, locked_at = null,
                status = case when :terminal then 'FAILED' else 'PENDING' end,
                processed_at = case when :terminal then now() else processed_at end,
                next_attempt_at = now() + make_interval(secs => :backoff)
            where id = :id
            """.trimIndent()
        ).param("error", error.take(500)).param("terminal", terminal).param("backoff", backoffSeconds.toDouble()).param("id", id).update()
    }

    /** 후속 이벤트 적재(예: 재고차감 성공 → PAYMENT_REQUESTED). */
    fun enqueue(eventType: String, platformOrderId: Long, payload: String?) {
        jdbc.sql("insert into ord_outbox_event (event_type, platform_order_id, payload) values (:type, :orderId, :payload)")
            .param("type", eventType).param("orderId", platformOrderId).param("payload", payload).update()
    }
}
