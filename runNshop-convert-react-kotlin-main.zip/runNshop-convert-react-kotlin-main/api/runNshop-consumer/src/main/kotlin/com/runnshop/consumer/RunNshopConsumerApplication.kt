package com.runnshop.consumer

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication
import org.springframework.scheduling.annotation.EnableScheduling

@SpringBootApplication
@EnableScheduling
class RunNshopConsumerApplication

fun main(args: Array<String>) {
    runApplication<RunNshopConsumerApplication>(*args)
}
