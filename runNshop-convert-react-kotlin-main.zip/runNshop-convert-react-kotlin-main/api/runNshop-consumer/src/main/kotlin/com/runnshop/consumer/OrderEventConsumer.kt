package com.runnshop.consumer

import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Value
import org.springframework.scheduling.annotation.Scheduled
import org.springframework.stereotype.Component
import org.springframework.transaction.support.TransactionTemplate
import java.net.InetAddress
import java.util.UUID

/**
 * 주문 아웃박스 컨슈머 — 이벤트 조회(점유)와 이벤트 상태 변경(DONE/재시도/FAILED, 후속 이벤트 적재)은 이 앱이 하고,
 * **업무 처리(재고차감·주문 상태 전이·PG 요청)는 API 서버의 내부 API 호출로만** 진행한다. 이 클래스에 업무 로직은 없다.
 *
 * 흐름: STOCK_DEDUCT_REQUESTED → API 처리 → 결과 STOCK_DEDUCTED면 PAYMENT_REQUESTED 적재 후 DONE, STOCK_PARTIAL(일부 SKU 실패)이면
 *       실패로 기록해 재시도(API는 실패 SKU만 재차감), STOCK_FAILED(이미 실패 처리됨)면 DONE.
 *       PAYMENT_REQUESTED → API 처리(PG 요청) → DONE. 호출 실패(연결/5xx)는 재시도 횟수를 올리고 백오프 후 PENDING으로 되돌려
 *       다시 처리하며, 한도([maxRetry]) 도달 시 FAILED로 종결하고 API에 업무 실패 전이(give-up)를 요청한다.
 * 다중 실행: 컨슈머 인스턴스를 여러 개 띄워도 되며(처리량 확장), 이벤트는 `FOR UPDATE SKIP LOCKED`로 점유(PROCESSING)되어
 *       인스턴스끼리 겹치지 않는다. 점유한 컨슈머가 죽어 [leaseSeconds] 안에 끝내지 못한 이벤트는 다른 인스턴스가 PENDING으로 되돌려 재처리한다.
 * API 처리는 멱등하므로 "API 성공 후 DONE 기록 전 장애"나 임대 만료 후 중복 호출이 나도 안전하다.
 */
@Component
class OrderEventConsumer(
    private val events: OrderEventRepository,
    private val api: OrderEventApiClient,
    private val tx: TransactionTemplate,
    @Value("\${order.outbox.batch-size}") private val batchSize: Int,
    @Value("\${order.outbox.max-retry}") private val maxRetry: Int,
    @Value("\${order.outbox.retry-backoff-seconds}") private val retryBackoffSeconds: Long,
    @Value("\${order.outbox.lease-seconds}") private val leaseSeconds: Long
) {

    /** 점유 기록(locked_by)용 인스턴스 식별자 — 호스트-PID-난수. */
    private val instanceId = "${runCatching { InetAddress.getLocalHost().hostName }.getOrDefault("unknown")}-${ProcessHandle.current().pid()}-${UUID.randomUUID().toString().take(4)}"


    private val log = LoggerFactory.getLogger(OrderEventConsumer::class.java)

    /** 주기적으로 만료된 점유를 되돌리고, 처리 가능한 이벤트를 점유해 건별로 처리한다. */
    @Scheduled(fixedDelayString = "\${order.outbox.poll-interval-ms}")
    fun poll() {
        val released = events.releaseExpired(leaseSeconds)
        if (released > 0) log.warn("임대 만료 이벤트 {}건을 PENDING으로 되돌림", released)
        for (event in events.claim(batchSize, instanceId)) {
            try {
                handle(event)
            } catch (e: Exception) {
                fail(event, e)
            }
        }
    }

    private fun handle(event: PendingEvent) {
        val result = api.process(event.eventType, event.platformOrderId, event.payload)
        // 일부 SKU 재고 차감 실패 — 성공분은 API가 유지하고 있으므로 실패로 기록해 백오프 후 재시도하면 실패 SKU만 다시 차감된다.
        if (result.result == "STOCK_PARTIAL") throw IllegalStateException(result.message ?: "일부 SKU 재고 차감 실패")
        tx.executeWithoutResult {
            if (event.eventType == STOCK_DEDUCT_REQUESTED && result.result == "STOCK_DEDUCTED") {
                events.enqueue(PAYMENT_REQUESTED, event.platformOrderId, event.payload)
            }
            events.markDone(event.id, result.message)
        }
    }

    private fun fail(event: PendingEvent, e: Exception) {
        val error = e.message ?: e.javaClass.simpleName
        val terminal = event.retryCount + 1 >= maxRetry
        log.warn("이벤트 처리 실패 id={} type={} retry={}/{}: {}", event.id, event.eventType, event.retryCount + 1, maxRetry, error)
        // 재시도 간격은 실패 횟수에 비례해 늘린다(1회째 backoff, 2회째 2×backoff, …).
        events.markRetry(event.id, error, terminal, retryBackoffSeconds * (event.retryCount + 1))
        if (terminal) {
            log.error("이벤트 종결(FAILED) id={} type={} orderId={}", event.id, event.eventType, event.platformOrderId)
            runCatching { api.giveUp(event.eventType, event.platformOrderId, error) }
                .onFailure { log.error("give-up 요청 실패 id={}", event.id, it) }
        }
    }

    companion object {
        private const val STOCK_DEDUCT_REQUESTED = "STOCK_DEDUCT_REQUESTED"
        private const val PAYMENT_REQUESTED = "PAYMENT_REQUESTED"
    }
}
