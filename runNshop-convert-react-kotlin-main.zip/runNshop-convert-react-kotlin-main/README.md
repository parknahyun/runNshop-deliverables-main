# runNshop-react-kotlin

runNshop의 React(admin/mobile/partner) + Kotlin/Spring Boot 구현.

## 구성
- `apps/runNshop-admin-react`, `apps/runNshop-mobile`, `apps/runNshop-partner` — 프론트엔드
- `api/runNshop-api`, `api/runNshop-consumer` — 백엔드(Kotlin/Spring Boot), 컨슈머/배치
- `docs/` — `runNshop-docs` 레포의 git submodule (공통 설계 문서 + 공통 steering/skill 원본)

## 설계 문서 참조
이 레포는 자체 설계 문서를 두지 않고 `docs/`(submodule)를 참조한다. 서브모듈 초기화:
```bash
git submodule update --init --recursive
```
공통 규칙 동기화(새 Bolt 착수 시점 등 자연스러운 경계에서):
```bash
git submodule update --remote docs
```

## 관련 레포
- [runNshop-docs](https://github.com/3top-fepest/runNshop-docs) — 설계 문서 허브
- [runNshop-vue-java](https://github.com/3top-fepest/runNshop-vue-java) — Vue+Java 파생 프로젝트

## 원본 레포
이 레포는 기존 `runNshop`(현재 아카이브) 레포에서 React/Kotlin 관련 경로를 이력 보존하여 분리했다.
