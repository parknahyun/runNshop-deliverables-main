---
name: design-doc-to-code
description: DN-화면레이아웃 설계 문서를 읽고 화면을 구현할 때, FE 프레임워크에 상관없이 먼저 거치는 공통 절차를 다룬다 — 문서 파싱, 데이터 흐름 원칙, 네이밍 컨벤션(camelCase), 화면 유형 판별, API/Mock 존재 확인·레이어 경계. 이 레포에서는 screen-to-fe-code(React/Next.js)가 이 skill의 절차를 이어받는다.
---

> 이 파일은 stub이다. 원본은 `runNshop-docs`(git submodule, `docs/`)에 있다 — 복사하지 않고
> 참조만 한다.

#[[file:docs/.kiro/skills/design-doc-to-code/SKILL.md]]
