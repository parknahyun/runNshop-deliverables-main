---
name: backend-service-pattern
description: runNshop 백엔드(Spring Boot 공통 — Kotlin/Java 언어 무관) Controller·Service를 구현하거나 리팩토링할 때 사용. 레이어 경계(Controller→Service→MockLoader/Repository), Service 내부 4단계 구조(validation→mapper execute→dto convert), 코멘트·섹션 규칙, 공용 예외 처리를 다룬다. 이 레포에서는 Kotlin 코드로 적용한다.
---

> 이 파일은 stub이다. 원본은 `runNshop-docs`(git submodule, `docs/`)에 있다 — 복사하지 않고
> 참조만 한다.

#[[file:docs/.kiro/skills/backend-service-pattern/SKILL.md]]
