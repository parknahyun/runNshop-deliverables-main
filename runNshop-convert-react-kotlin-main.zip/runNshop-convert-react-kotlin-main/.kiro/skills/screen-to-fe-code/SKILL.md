---
name: screen-to-fe-code
description: DN-화면레이아웃 설계 문서를 읽고 runNshop admin/partner/mobile 프론트엔드 Next.js(React) 코드로 변환한다. 화면 구현, 화면 코드 생성, 또는 기존 화면의 하드코딩된 mock 데이터를 백엔드 API 연동 구조로 전환할 때 사용. 문서 파싱·네이밍·API확인 등 프레임워크 공통 절차는 design-doc-to-code skill을 먼저 따른다.
---

> **분류: 언어/프레임워크별(React/Next.js)** — 절차 1~4(문서 파싱, camelCase 네이밍, 화면 유형 판별, API/Mock 확인)는 `design-doc-to-code`(공통) skill을 그대로 따른다. 이 skill은 그 이후 **React/Next.js 전용 파일 생성·구현**만 다룬다. 향후 Vue 구현은 이 skill 대신 Vue 전용 skill을 만들고 동일하게 `design-doc-to-code`를 공통 기반으로 삼는다.

# 화면설계 → React/Next.js 코드 변환

## 선행 절차
`design-doc-to-code` skill의 절차 1~4(문서 파싱 / camelCase 네이밍 / 화면 유형 판별 — `admin-ux-pattern.md` 기준 / API·Mock 존재 확인 — 레이어 경계는 `backend-service-pattern` 기준)를 먼저 수행한다. 이 skill은 그 결과를 이어받아 React 파일을 만든다.

## 절차 5 — FE 파일 생성/수정 (React 전용)
admin/partner 파일 구조 (`.kiro/steering/admin-guide.md` 참조):
```
src/{domain}/{screen-name}/
  {ScreenName}.tsx          ← 현황 화면
  {ScreenName}Detail.tsx    ← 상세 모달/탭
  types.ts                  ← 타입 + 상태→라벨 매핑 (구 mockData.ts — 하드코딩 데이터 제거 후 리네임)
  tabs/
```
mobile 파일 구조: `app/{path}/page.tsx` (+ 상세는 `app/{path}/[id]/page.tsx`) + `components/{domain}/`

**`types.ts`로 명명** — 과거 `mockData.ts`라는 이름으로 하드코딩 데이터 배열과 타입을 함께 두던 관례가 있었으나, 이번부터는 신규 화면 생성 시 처음부터 `types.ts`로 만든다. 내용은 다음 두 가지로 한정:
1. 타입 정의 (`interface Order`, `type OrderStatus` 등) — API 응답의 FE측 계약
2. 상태값→표시 라벨 매핑 (`ORDER_STATUS_LABEL` 등) — 순수 UI 표시 변환 로직, 서버가 안 내려줘도 되는 영역이라 FE에 남아도 됨

**`types.ts`에 두지 않는 것**:
- 하드코딩된 데이터 배열(`MOCK_XXX`) — 두지 않음
- 클라이언트 필터 함수(`filterXxx()`) — 서버 책임이므로 Controller/Service로 이전, FE에서 제거

**기존 화면을 전환할 때**: `mockData.ts`가 남아있는 화면을 이 패턴으로 옮길 경우, 데이터 배열/필터 함수를 제거한 뒤 파일을 `types.ts`로 리네임하고 import 구문도 전부 갱신한다 (단, 이미 별도 작업 지시로 "파일명 유지"가 명시된 범위가 있다면 그 지시를 우선한다).

**백엔드는 해당 없음** — 백엔드에는 `mockData`류의 TS/Kotlin 파일이 존재하지 않는다. Mock 데이터는 `resources/mock/{domain}/*.json` 순수 JSON 파일로 두고 `common/MockLoader.kt`(공용 컴포넌트)가 로딩한다 — 이 구조는 그대로 유지, 변경하지 않는다. 응답 타입을 Kotlin DTO로 명시하고 싶다면(`Map<String,Any>` 대신) `com.runnshop.{domain}/dto/`에 `{Domain}ListResponse.kt` 등으로 추가한다 — Service(`service/`)에는 비즈니스 로직만 두고 요청/응답 데이터 구조는 DTO 패키지 책임으로 분리한다.

**컴포넌트 작성 규칙**:
- 데이터는 전부 `lib/api.ts`를 통해 fetch (하드코딩 금지)
- 필터 변경/페이지 변경/페이지크기 변경 시마다 서버 재요청, 응답을 그대로 state에 반영 (재가공 없음)
- 등록/수정/삭제 버튼: 실제 API 호출하되 결과는 Mock 성공 응답 → Toast로 "저장되었습니다" 안내, 또는 범위 밖 기능이면 "프로토타입에서는 지원하지 않는 기능입니다" 안내
- 유효성 검증은 문서의 "유효성 검증" 섹션 그대로 구현
- "상태별 UI" 섹션(로딩/빈 결과/에러)을 조건 분기로 구현
- "화면 전환" 섹션의 트리거 → 이동 화면을 실제 네비게이션/탭 오픈으로 연결 (목록 row 클릭 시 상세로는 ID만 전달)

## 절차 6 — 검증
```bash
cd api/runNshop-api && ./gradlew build -x test   # API 변경 시
cd apps/runNshop-{app} && npm run build           # FE 빌드 확인
```
- 서버 기동 후 `curl`로 신규/수정 엔드포인트가 쿼리 파라미터에 따라 실제로 다른 결과를 돌려주는지 확인 (고정 JSON 그대로 반환하는 회귀가 없는지)
- 개발 서버는 사용자가 직접 실행 (`npm run dev`), 수동으로 화면 진입·조회·필터·페이지 이동·상세 진입 동작 확인 요청

## 참고 steering/skill
- `design-doc-to-code` — 프레임워크 공통 절차(문서 파싱/네이밍/API확인), **이 skill의 전제**
- `.kiro/steering/admin-ux-pattern.md` — admin/partner 화면 공통 UX 패턴(React+Vue 공통)
- `.kiro/steering/admin-guide.md` — admin/partner React 전용 파일 구조
- `.kiro/steering/nextjs-guide.md` — Next.js 공통 규칙
- `.kiro/steering/mock-data-rules.md` — Mock 파일 네이밍
- `.kiro/steering/api-design-rules.md` — Controller 분리 기준
- `.kiro/steering/kotlin-guide.md` — Controller/Service/dto 패키지 구조
- `.kiro/steering/coding-standards.md` — 공통 코딩 규칙
- `.kiro/steering/work-scope.md` — 도메인 작업 범위, 1차 근거 우선 원칙
