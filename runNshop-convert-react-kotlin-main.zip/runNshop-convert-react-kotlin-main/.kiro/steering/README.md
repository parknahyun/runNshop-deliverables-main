---
inclusion: manual
---
# Steering 파일 가이드 (runNshop-react-kotlin)

이 레포는 `runNshop-docs`를 git submodule로 `docs/`에 연결해 공통(표준) 규칙을 참조한다.
공통 규칙이 바뀌면 `git submodule update --remote docs`로 동기화한다(매번 자동 추적 아님).

## Steering 파일 목록

| 파일 | 분류 | 비고 |
|------|------|------|
| work-scope.md | 공통(stub) | 원본: `docs/.kiro/steering/work-scope.md` |
| api-design-rules.md | 공통(stub) | 원본: `docs/.kiro/steering/api-design-rules.md` |
| mock-data-rules.md | 공통(stub) | 원본: `docs/.kiro/steering/mock-data-rules.md` |
| coding-standards.md | 공통(stub) | 원본: `docs/.kiro/steering/coding-standards.md` |
| screen-definition.md | 공통(stub) | 원본: `docs/.kiro/steering/screen-definition.md` |
| admin-ux-pattern.md | 공통(stub) | 원본: `docs/.kiro/steering/admin-ux-pattern.md` (React+Vue 공통 패턴 중 React만 적용) |
| kotlin-guide.md | 언어별(Kotlin) | 이 레포 고유 |
| nextjs-guide.md | 언어별(Next.js) | 이 레포 고유 |
| admin-guide.md | 언어별(React) | 이 레포 고유, admin-ux-pattern.md의 React 파일구조 보완 |

## 관련 Skill (`.kiro/skills/`)

| Skill | 분류 | 비고 |
|---|---|---|
| design-doc-to-code | 공통(stub) | 원본: `docs/.kiro/skills/design-doc-to-code/SKILL.md` |
| backend-service-pattern | 공통(stub) | 원본: `docs/.kiro/skills/backend-service-pattern/SKILL.md` (Kotlin으로 적용) |
| screen-to-fe-code | 언어별(React) | 이 레포 고유, design-doc-to-code의 절차 5 이후를 담당 |
