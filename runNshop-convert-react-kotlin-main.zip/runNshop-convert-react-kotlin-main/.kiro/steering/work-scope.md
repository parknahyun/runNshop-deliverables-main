---
inclusion: always
---
# 작업 범위 기준 (공통 — docs 허브 참조)

> 이 파일은 stub이다. 원본은 `runNshop-docs`(git submodule, `docs/`)에 있다 — 복사하지 않고
> 참조만 한다. 허브가 바뀌면 `git submodule update --remote docs`로 동기화한다.

#[[file:docs/.kiro/steering/work-scope.md]]
