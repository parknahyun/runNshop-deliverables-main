---
inclusion: fileMatch
fileMatchPattern: "**/runNshop-admin-react/**/*.tsx,**/runNshop-partner/**/*.tsx"
---
# 어드민/파트너 화면 개발 가이드 (React 전용)

> **분류: 언어/프레임워크별(React)** — 화면 유형·Shell 구조·색상·spec.md 규칙 등 공통 UX 패턴은 `.kiro/steering/admin-ux-pattern.md`(공통)에 있다. 이 파일은 그 공통 패턴을 **React/Next.js로 구현할 때의 파일 구조·구현 세부사항만** 다룬다. Vue(`admin-vue`) 구현은 이 파일을 보지 않는다 — 해당 프레임워크 전용 가이드를 따른다.

## 공통 UX 패턴 참조

화면 유형(Dashboard/Table/Detail Modal), Shell 구조(NavBar/TabBar/TabContent), 색상, 코드성 속성 입력방식, spec.md 작성 규칙은 `.kiro/steering/admin-ux-pattern.md`를 따른다 — 여기서 반복하지 않는다.

## 파일 구조 규칙 (React 전용)
```
src/{domain}/{screen-name}/
  {ScreenName}.tsx          ← 현황 화면
  {ScreenName}Detail.tsx    ← 상세 모달
  mockData.ts               ← Mock 데이터
  tabs/                     ← 상세 탭 컴포넌트
```

## 공통 컴포넌트 (src/shell/shared/)
- `Pagination` — 페이지네이션
- `InnerTabs` — 상세 모달 내부 탭
