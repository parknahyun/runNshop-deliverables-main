---
inclusion: manual
---
# 화면정의 참조 (공통 — docs 허브 참조)

> 이 파일은 stub이다. 원본은 `runNshop-docs`(git submodule, `docs/`)에 있다 — 복사하지 않고
> 참조만 한다.

#[[file:docs/.kiro/steering/screen-definition.md]]
