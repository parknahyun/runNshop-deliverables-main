---
inclusion: fileMatch
fileMatchPattern: "**/*.kt"
---
# Kotlin 개발 가이드

## 기술 스택
- Kotlin + Spring Boot 3.3
- JDK 21
- Gradle (Kotlin DSL)

## 패키지 구조
```
com.runnshop.{domain}/
├── controller/     ← REST Controller (URL path로 앱 구분)
├── service/        ← 비즈니스 로직 (프로토타입: Mock 반환 / DB 전환 후: Repository·Mapper·Port 호출)
├── dto/            ← 요청/응답 DTO
├── mock/           ← Mock JSON 로딩 (프로토타입 단계, DB 전환 후에도 Mock 기반 API는 유지)
├── domain/         ← JPA Entity (DB 전환 후, ERD 테이블당 1개)
├── repository/     ← JPA Repository (DB 전환 후, master 계정 — 단건/연관관계 조회)
├── mapper/         ← MyBatis Mapper 인터페이스 + 매핑 DTO(Row) (DB 전환 후, slave 계정 — 목록/집계 동적조건 조회)
└── port/           ← 타 도메인 호출 계약 인터페이스 (이 도메인이 소유, 제공 도메인이 구현)
```
- `domain/repository`는 JPA(단건 조회, 연관관계 탐색), `mapper`는 MyBatis(목록/집계처럼 동적 WHERE가 섞이는 조회) 담당이다. 역할 분리 기준과 작성 규칙은 `backend-service-pattern` skill 참조.
- **비동기 컨슈머/배치 규칙**: 컨슈머와 배치는 **API 서버와 별도 애플리케이션**(`api/runNshop-consumer` 등, 웹 서버 없음)이다. 스케줄 + 이벤트/대상 조회 + 이벤트 상태 변경은 그 앱이 직접 하고, **업무 처리만 API 서버의 내부 API(`/api/internal/v1/...`) 호출**로 진행한다(앱에 업무 로직 금지). API 서버에는 `@Scheduled`/`@EnableScheduling`을 두지 않는다. 상세는 `backend-service-pattern` skill 참조.
- `resources/mapper/{domain}/*.xml`에 MyBatis Mapper의 SQL을 둔다 (Kotlin 인터페이스는 `mapper/` 패키지, XML은 리소스 쪽에 분리).

## 공용 인프라 — DataSource 이원화 (master/slave)

DB 전환된 도메인은 `com.runnshop.common.config`의 공용 설정 2개를 그대로 쓴다. 도메인마다 새 DataSource/TransactionManager를 만들지 않는다.

- **master(JPA, `MasterDataSourceConfig`)**: owner 계정(`runnshop_master`), `@Primary`로 지정된 기본 DataSource/EntityManager/TransactionManager. 단건 조회(연관관계 포함)와 CUD(생성/수정/삭제)는 전부 이 쪽(`repository/`)이 담당한다. `@EnableJpaRepositories(basePackages = ["com.runnshop"])`로 전 도메인의 Repository를 한 번에 스캔하므로, 신규 도메인이 Repository를 추가해도 이 설정은 건드릴 필요 없다.
- **slave(MyBatis, `SlaveDataSourceConfig`)**: 읽기전용 계정(`runnshop_slave`) — DB 권한 자체가 SELECT만 허용돼 애플리케이션 버그로 쓰기 쿼리가 나가도 DB가 막는다(커넥션도 `isReadOnly=true`로 이중 방어). 동적 검색조건이 섞이는 목록·집계 쿼리는 전부 이 쪽(`mapper/`)이 담당한다. **`@MapperScan(basePackages = [...])`에 도메인별 mapper 패키지를 나열하는 구조라, 신규 도메인을 MyBatis로 전환할 때는 이 목록에 그 도메인의 `{domain}.mapper` 패키지를 추가해야 한다** — 추가하지 않으면 Mapper 인터페이스가 Spring Bean으로 등록되지 않아 주입이 실패한다.
- 두 DataSource는 각각 `application.yml`의 `app.datasource.master`/`app.datasource.slave`에서 커넥션 정보를 읽는다. 신규 도메인 전용 DB 계정을 추가로 만들지 않는다 — 전 도메인이 이 2개 커넥션 풀을 공유한다.

## 12개 업무도메인
order, catalog, member, payment, promotion, settlement, vendor, notification, community, search, config, audit

## 프로토타입 단계 Controller 패턴
```kotlin
@RestController
@RequestMapping("/api/v1/products")
class CustomerProductController(private val mockLoader: MockLoader) {

    @GetMapping("/{productId}")
    fun getProduct(@PathVariable productId: Long): ResponseEntity<Any> {
        val data = mockLoader.load("v1", "catalog__GET_products_\${productId}.json")
        return ResponseEntity.ok(data)
    }
}
```

## 코멘트 규칙
- **모든 Controller/Service 메서드(public이든 private이든)는 KDoc(`/** ... */`)을 반드시 작성한다** — 어떤 API(URL/용도)를 처리하는지 한 줄 이상 설명한다. 관련 DL-인터페이스명세 섹션 번호(`(DL §15)` 등)가 있으면 같이 적는다.
- 섹션 구분 주석(`// ── ... ──`)은 메서드별 KDoc을 대체하지 않는다. 둘 다 쓴다 — 섹션 주석은 "이 블록이 어떤 채널/목적인지"의 목차 역할, KDoc은 메서드 하나하나의 상세 설명.

## 섹션 구분 — 서브도메인 통합 Controller/Service
여러 앱(채널)을 하나의 Controller/Service로 통합한 경우(`api-design-rules.md`의 "Controller/Service 분리 단위" 참조), 섹션 주석(`// ── ... ──`)으로 메서드를 채널별로 묶는다.
- **최소 단위는 회원(mobile) / 관리자(admin) / 파트너(partner) 3개 채널**이다. 채널이 섞이지 않도록 각 채널의 메서드를 한 블록에 모은다 (예: "고객 주문서"와 "고객 주문 목록"처럼 같은 채널인데 섹션이 쪼개져 있으면 하나로 합친다).
- 채널 섹션 안에서 더 세분화(예: `my`/마이페이지 전용 하위 섹션)해도 된다 — 다만 상위 채널 섹션 구조를 깨지 않아야 한다.
- **메서드를 추가할 때는 그 메서드가 속하는 섹션 블록 안의 위치에 넣는다.** 파일 맨 끝에 아무 섹션에나 붙이지 않는다 — 어느 채널(및 하위 섹션)에 속하는지 먼저 판단하고 그 블록 안에 삽입한다.

## Controller/Service 분리 기준
- 하나의 Controller(또는 Service) 클래스가 보유하는 메서드는 **최대 30개**까지 허용한다.
- 이 기준에 도달하기 전까지는 섣불리 쪼개지 않는다 — 분리는 실제로 메서드 수가 넘칠 때 그 시점에 검토한다.
- **30개를 넘는 시점에 AI가 임의로 패키지를 분리하지 않는다.** 메서드를 추가하다 30개를 초과하게 되면, 그 자리에서 분리를 진행하지 말고 먼저 사용자에게 알린다 — "현재 {N}개째 메서드를 추가하면 30개를 초과합니다. 하위 업무 기준으로 패키지를 분리할까요?"처럼 초과 사실과 하위업무 분리 후보(예: `order/` 안에 `shipping/`, `claim/`을 별도 패키지로 뺀 전례 참고 — `DP-클래스설계/order.md` §1 패키지 구조)를 제시하고, 분리 여부와 분리 기준(어떤 메서드를 어느 패키지로 옮길지)은 **휴먼이 확정**한 뒤에 진행한다.
- 이 절차는 `api-design-rules.md`의 "Controller/Service 분리 단위 — 휴먼 검토·결정 필수 영역"과 동일한 이유다 — 분리 기준은 업무 특성에 따라 달라서 AI가 보편 규칙으로 기계적으로 적용할 수 없다.

## 도메인 설계 참조
#[[file:docs/3. 도메인/runNshop_bounded_context_v1_0.md]]
