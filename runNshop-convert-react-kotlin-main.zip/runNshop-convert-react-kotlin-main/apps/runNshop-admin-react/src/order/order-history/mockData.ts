// 플랫폼 헤더 status(3종)와 vendor order status(7종, 기존 그대로)를 별개 타입으로 분리한다.
// PlatformOrder.status를 전이시키는 로직이 없어 플랫폼 헤더는 이 3종만 발생 가능하지만,
// vendor order(ord_order)의 status는 전이 로직이 그대로 있어 7종 전부 계속 발생한다
// (items[].vendorStatus, shipping.deliveries[].status) — 하나의 타입으로 합치면 그 차이가 드러나지 않는다.
export type OrderStatus = 'STOCK_REQUESTED' | 'STOCK_DEDUCTED' | 'STOCK_FAILED' | 'DEPOSIT_PENDING' | 'PAYMENT_COMPLETED' | 'CANCELLED'

export const ORDER_STATUS_LABEL: Record<OrderStatus, string> = {
  STOCK_REQUESTED: '재고확인중',
  STOCK_DEDUCTED: '재고차감완료',
  STOCK_FAILED: '재고부족',
  DEPOSIT_PENDING: '입금대기',
  PAYMENT_COMPLETED: '결제완료',
  CANCELLED: '취소',
}

/** vendor order(ord_order) status — 기존 7종 + 결제 확정 흐름(재고차감 → 입금대기)에서 플랫폼주문과 함께 전이되는 4종(2026-10-26). */
export type VendorOrderStatus = 'STOCK_REQUESTED' | 'STOCK_DEDUCTED' | 'STOCK_FAILED' | 'DEPOSIT_PENDING' | 'ORDER_RECEIVED' | 'PAYMENT_COMPLETED' | 'PREPARING' | 'IN_DELIVERY' | 'DELIVERED' | 'CONFIRMED' | 'CANCELLED'

export const VENDOR_ORDER_STATUS_LABEL: Record<VendorOrderStatus, string> = {
  STOCK_REQUESTED: '재고확인중',
  STOCK_DEDUCTED: '재고차감완료',
  STOCK_FAILED: '재고부족',
  DEPOSIT_PENDING: '입금대기',
  ORDER_RECEIVED: '접수',
  PAYMENT_COMPLETED: '결제완료',
  PREPARING: '준비중',
  IN_DELIVERY: '배송중',
  DELIVERED: '배송완료',
  CONFIRMED: '구매확정',
  CANCELLED: '취소',
}

export interface Order {
  orderId: string
  platformOrderNo: string
  productName: string
  customer: string
  status: OrderStatus
  amount: number
  orderDate: string
  vendorName: string
}

export interface OrderFilter {
  keyword: string
  status: OrderStatus | 'ALL'
  from: string
  to: string
}

// ---------------------------------------------------------------------------
// 주문 상세 (GET /api/admin/v1/orders/{orderId}) 응답 타입
// OrderDetail.tsx와 tabs/*.tsx가 공유한다.
// ---------------------------------------------------------------------------

export interface OrderItem {
  productName: string
  optionName: string
  quantity: number
  unitPrice: number
  subtotal: number
}

/** admin 상세 items[] 1개 vendor 그룹 — vendorName+vendorStatus+products[] 구조. */
export interface OrderItemGroup {
  vendorName: string
  vendorStatus: VendorOrderStatus
  products: OrderItem[]
}

export interface OrderPayment {
  method: string
  pgProvider: string
  transactionId: string
  paidAt: string
}

/** vendor order 1건의 배송 정보 — shipping.deliveries[] 1개 항목. */
export interface VendorDelivery {
  vendorName: string
  carrier: string | null
  trackingNumber: string | null
  shippedAt: string | null
  status: VendorOrderStatus
}

export interface OrderShipping {
  recipientName: string
  phone: string
  address: string
  memo: string
  deliveries: VendorDelivery[]
}

export type StatusTargetType = 'ORDER' | 'PAYMENT' | 'DELIVERY' | 'CLAIM'

export const STATUS_TARGET_LABEL: Record<StatusTargetType, string> = {
  ORDER: '주문상태',
  PAYMENT: '결제상태',
  DELIVERY: '배송상태',
  CLAIM: '클레임상태',
}

/** ord_status_history 1건 — fromStatus가 null이면 최초 생성. 상태값은 대상 종류별 코드라 문자열로 둔다. */
export interface OrderHistoryEntry {
  targetType: StatusTargetType
  fromStatus: string | null
  toStatus: string
  changedBy: string
  reason: string | null
  createdAt: string
}

export interface OrderClaim {
  claimId: string
  claimType: string
  status: string
  refundAmount: number
  extraShippingFee: number
  extraShippingFeeStatus: string
  receivedAt: string
  vendorName: string
}

export interface OrderInquiry {
  inquiryId: string
  type: string
  status: string
  writer: string
  createdAt: string
}

export interface OrderLog {
  at: string
  event: string
  detail: string
}

export interface OrderDetailData {
  orderId: string
  platformOrderNo: string
  status: OrderStatus
  customer: string
  vendorName: string
  /** 주문금액 (어드민 목록·상세 헤더의 금액) */
  amount: number
  orderAmount?: number
  /** 결제금액 (주문금액 − 포인트, PG 결제분) */
  paymentAmount?: number
  productAmount: number
  shippingFee: number
  productDiscount: number
  cartDiscount: number
  pointUsedAmount: number
  orderDate: string
  items: OrderItemGroup[]
  payment: OrderPayment
  shipping: OrderShipping
  history: OrderHistoryEntry[]
  claims: OrderClaim[]
  inquiries: OrderInquiry[]
  logs: OrderLog[]
}
