'use client'
import { type OrderDetailData, VENDOR_ORDER_STATUS_LABEL } from '../mockData'

export default function ShippingInfoTab({ order }: { order: OrderDetailData }) {
  return (
    <div className="tab-panel-content">
      <dl className="info-dl">
        <div className="info-row"><dt>수령인</dt><dd>{order.shipping.recipientName}</dd></div>
        <div className="info-row"><dt>연락처</dt><dd>{order.shipping.phone}</dd></div>
        <div className="info-row"><dt>주소</dt><dd>{order.shipping.address}</dd></div>
      </dl>
      {order.shipping.deliveries.map((d, i) => (
        <section className="detail-section" key={d.vendorName}>
          <h2 className="section-title">■ {d.vendorName}</h2>
          <dl className="info-dl">
            <div className="info-row"><dt>배송사</dt><dd>{d.carrier ?? '-'}</dd></div>
            <div className="info-row"><dt>운송장번호</dt><dd>{d.trackingNumber ?? '-'}</dd></div>
            <div className="info-row"><dt>출고일</dt><dd>{d.shippedAt ?? '-'}</dd></div>
            <div className="info-row"><dt>배송상태</dt><dd>{VENDOR_ORDER_STATUS_LABEL[d.status]}</dd></div>
          </dl>
        </section>
      ))}
    </div>
  )
}
