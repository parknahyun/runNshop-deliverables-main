'use client'
import { type OrderDetailData, type OrderItemGroup, VENDOR_ORDER_STATUS_LABEL } from '../mockData'

export default function OrderItemsTab({ order }: { order: OrderDetailData }) {
  return (
    <div className="tab-panel-content">
      {order.items.map((group: OrderItemGroup, gi) => (
        <div key={group.vendorName} className={gi > 0 ? 'pt-4 border-t' : ''}>
          <div className="order-meta">
            <span className="section-title">■ {group.vendorName}</span>
            <span className="badge" data-order-status={group.vendorStatus}>{VENDOR_ORDER_STATUS_LABEL[group.vendorStatus]}</span>
          </div>
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>상품명</th>
                  <th>옵션</th>
                  <th>수량</th>
                  <th>단가</th>
                  <th>소계</th>
                </tr>
              </thead>
              <tbody>
                {group.products.map((item, i) => (
                  <tr key={`${item.productName}-${item.optionName}-${i}`}>
                    <td>{item.productName}</td>
                    <td>{item.optionName}</td>
                    <td>{item.quantity}</td>
                    <td className="amount-cell">{item.unitPrice.toLocaleString()}원</td>
                    <td className="amount-cell">{item.subtotal.toLocaleString()}원</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ))}
    </div>
  )
}
