'use client'
import { ORDER_STATUS_LABEL, type OrderDetailData } from '../mockData'

export default function PaymentInfoTab({ order }: { order: OrderDetailData }) {
  return (
    <div className="tab-panel-content">
      <div className="info-grid">
        <dl className="info-dl">
          <div className="info-row"><dt>상품금액</dt><dd>{order.productAmount.toLocaleString()}원</dd></div>
          <div className="info-row"><dt>배송비</dt><dd>{order.shippingFee.toLocaleString()}원</dd></div>
          <div className="info-row"><dt>상품할인</dt><dd>{order.productDiscount.toLocaleString()}원</dd></div>
          <div className="info-row"><dt>장바구니 할인</dt><dd>-{order.cartDiscount.toLocaleString()}원(쿠폰)</dd></div>
          <div className="info-row info-row--total"><dt>주문금액</dt><dd>{(order.orderAmount ?? order.amount).toLocaleString()}원</dd></div>
          <div className="info-row"><dt>포인트</dt><dd>-{order.pointUsedAmount.toLocaleString()}원</dd></div>
          <div className="info-row info-row--total"><dt>결제금액</dt><dd>{(order.paymentAmount ?? order.amount - order.pointUsedAmount).toLocaleString()}원</dd></div>
        </dl>
        <dl className="info-dl">
          <div className="info-row"><dt>결제상태</dt><dd>{ORDER_STATUS_LABEL[order.status]}</dd></div>
          <div className="info-row"><dt>결제수단</dt><dd>{order.payment.method}</dd></div>
          <div className="info-row"><dt>PG사</dt><dd>{order.payment.pgProvider}</dd></div>
          <div className="info-row"><dt>거래 ID</dt><dd>{order.payment.transactionId}</dd></div>
          <div className="info-row"><dt>결제 일시</dt><dd>{order.payment.paidAt}</dd></div>
        </dl>
      </div>
    </div>
  )
}
