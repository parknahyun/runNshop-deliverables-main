const API_BASE = process.env.NEXT_PUBLIC_API_BASE || 'http://localhost:8080';
const PREFIX = '/api/mobile/v1';

export class ApiError extends Error {
  constructor(public code: string, message: string) {
    super(message);
  }
}

interface ApiOptions {
  method?: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  body?: unknown;
}

export async function api<T>(path: string, options?: ApiOptions): Promise<T> {
  const method = options?.method ?? 'GET';

  const res = await fetch(`${API_BASE}${PREFIX}${path}`, {
    method,
    ...(options?.body !== undefined
      ? {
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(options.body),
        }
      : {}),
  });
  const json = await res.json();

  if (json.code !== 'SUCCESS') {
    throw new ApiError(json.code, json.message);
  }
  return json.data;
}
