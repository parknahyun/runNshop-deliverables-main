'use client';

interface CartItem {
  cart_item_id: number;
  product_id: number;
  product_name: string;
  image_url: string;
  color: string;
  size: string;
  price_original: number;
  price_sale: number;
  quantity: number;
  stock: number;
  status: string;
}

interface VendorData {
  vendor_id: number;
  vendor_name: string;
  shipping_fee: number;
  free_threshold: number;
  items: CartItem[];
}

interface VendorGroupProps {
  vendor: VendorData;
  selected: Set<number>;
  onToggle: (cartItemId: number) => void;
  onDelete: (cartItemId: number) => void;
  onQuantityChange: (cartItemId: number, nextQuantity: number) => void;
  pendingItemId: number | null;
}

export function VendorGroup({
  vendor,
  selected,
  onToggle,
  onDelete,
  onQuantityChange,
  pendingItemId,
}: VendorGroupProps) {
  const vendorTotal = vendor.items.reduce((sum, item) => sum + item.price_sale * item.quantity, 0);
  const isFreeShipping = vendorTotal >= vendor.free_threshold;

  return (
    <div className="mt-3 mx-4 bg-white rounded-lg shadow-sm overflow-hidden">
      {/* 판매자 헤더 */}
      <div className="px-4 py-2.5 border-b border-gray-100 flex items-center justify-between">
        <span className="text-sm font-medium text-gray-900">{vendor.vendor_name}</span>
        <span className="text-xs text-gray-500">
          {isFreeShipping
            ? '무료배송'
            : `배송비 ${vendor.shipping_fee.toLocaleString()}원 (${vendor.free_threshold.toLocaleString()}원 이상 무료)`}
        </span>
      </div>

      {/* 상품 목록 */}
      {vendor.items.map((item) => (
        <div
          key={item.cart_item_id}
          className={`px-4 py-3 border-b border-gray-50 last:border-b-0${item.status !== 'ON_SALE' ? ' bg-gray-50' : ''}`}
        >
          <div className="flex gap-3">
            <input
              type="checkbox"
              checked={item.status === 'ON_SALE' && selected.has(item.cart_item_id)}
              disabled={item.status !== 'ON_SALE'}
              onChange={() => onToggle(item.cart_item_id)}
              className="w-4 h-4 accent-primary mt-1 flex-shrink-0"
            />
            <img
              src={item.image_url}
              alt={item.product_name}
              className="w-20 h-20 rounded-md object-cover flex-shrink-0"
            />
            <div className="flex-1 min-w-0">
              <p className="text-sm text-gray-900 font-medium line-clamp-2">
                {item.product_name}
                {item.status !== 'ON_SALE' && (
                  <span className="ml-1.5 inline-block text-[11px] font-normal text-white bg-gray-400 rounded px-1.5 py-0.5 align-middle">
                    품절
                  </span>
                )}
              </p>
              <p className="text-xs text-gray-500 mt-0.5">{item.color} / {item.size}</p>
              <div className="flex items-center justify-between mt-2">
                <div>
                  {item.price_original !== item.price_sale && (
                    <span className="text-xs text-gray-400 line-through mr-1">
                      {item.price_original.toLocaleString()}원
                    </span>
                  )}
                  <span className="text-sm font-bold text-gray-900">
                    {item.price_sale.toLocaleString()}원
                  </span>
                </div>
              </div>
              {/* 수량 조절 — 1~99 범위·재고초과·품절·요청 진행 중(pendingItemId)인 경우 버튼을 선제
                  비활성화해 정상 흐름에서는 INVALID_QUANTITY/EXCEED_STOCK이 발생하지 않게 한다
                  (design.md 과업2 결정 3). */}
              <div className="flex items-center gap-2 mt-2">
                <button
                  onClick={() => onQuantityChange(item.cart_item_id, item.quantity - 1)}
                  disabled={item.status !== 'ON_SALE' || item.quantity <= 1 || pendingItemId === item.cart_item_id}
                  className="w-7 h-7 border border-gray-200 rounded text-gray-500 text-sm disabled:opacity-40"
                >
                  −
                </button>
                <span className="text-sm font-medium w-6 text-center">{item.quantity}</span>
                <button
                  onClick={() => onQuantityChange(item.cart_item_id, item.quantity + 1)}
                  disabled={
                    item.status !== 'ON_SALE' ||
                    item.quantity >= 99 ||
                    item.quantity >= item.stock ||
                    pendingItemId === item.cart_item_id
                  }
                  className="w-7 h-7 border border-gray-200 rounded text-gray-500 text-sm disabled:opacity-40"
                >
                  +
                </button>
                <button
                  onClick={() => onDelete(item.cart_item_id)}
                  className="ml-auto text-xs text-gray-400"
                >
                  삭제
                </button>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
