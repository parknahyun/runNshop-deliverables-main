'use client';

interface CartBottomBarProps {
  totalPayment: number;
  onOrder: () => void;
  disabled: boolean;
}

export function CartBottomBar({ totalPayment, onOrder, disabled }: CartBottomBarProps) {
  return (
    <div className="fixed bottom-0 left-0 right-0 max-w-[360px] mx-auto bg-white border-t border-gray-200 px-4 py-3">
      <button
        onClick={onOrder}
        disabled={disabled}
        className="w-full h-12 bg-primary text-white font-bold rounded-lg text-sm disabled:opacity-40"
      >
        선택상품 주문하기 · {totalPayment.toLocaleString()}원
      </button>
    </div>
  );
}
