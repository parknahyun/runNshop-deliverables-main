'use client';

import { useRouter } from 'next/navigation';

// /cart는 상품상세·기획전·검색·헤더 장바구니 아이콘 등 여러 진입점에서 들어올 수 있어 고정 href로는
// "이전 화면"을 표현할 수 없다 — 그래서 router.back()으로 브라우저/라우터 히스토리를 따라간다.
// (design.md 과업1, apps/runNshop-mobile/app/my/orders/page.tsx 등의 기존 "←" 버튼과 동일한 시각 스타일)
export function CartBackButton() {
  const router = useRouter();

  return (
    <button onClick={() => router.back()} className="text-gray-400 text-sm" aria-label="이전 화면으로 이동">
      ←
    </button>
  );
}
