'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { api, ApiError } from '@/lib/api';
import { VendorGroup } from '@/components/cart/VendorGroup';
import { CartSummary } from '@/components/cart/CartSummary';
import { CartBottomBar } from '@/components/cart/CartBottomBar';

export interface CartData {
  total_count: number;
  vendors: VendorData[];
  summary: SummaryData;
}

export interface VendorData {
  vendor_id: number;
  vendor_name: string;
  shipping_fee: number;
  free_threshold: number;
  items: CartItem[];
}

export interface CartItem {
  cart_item_id: number;
  product_id: number;
  product_name: string;
  image_url: string;
  color: string;
  size: string;
  price_original: number;
  price_sale: number;
  quantity: number;
  stock: number;
  status: string;
}

export interface SummaryData {
  total_product_price: number;
  total_discount: number;
  cart_discount: number;
  total_shipping_fee: number;
  total_payment: number;
  point_balance: number;
  coupon_benefit_text: string;
}


function initialSelected(cartData: CartData): Set<number> {
  const ids = cartData.vendors.flatMap((vendor) =>
    vendor.items.filter((item) => item.status === 'ON_SALE').map((item) => item.cart_item_id)
  );
  return new Set(ids);
}

// 선택된 상품(status === 'ON_SALE'인 항목만)을 기준으로 CartSummary/CartBottomBar가 공유하는
// 요약 객체를 다시 계산한다. 조건부 할인(cart_discount)은 반영하지 않고 0으로 고정하며,
// 배송비(total_shipping_fee)는 선택 상태와 무관하게 Mock summary 값을 그대로 복사한다
// (design.md "결정 1 — CartSummary 재계산 방식").
function buildSelectedSummary(cartData: CartData, selected: Set<number>): SummaryData {
  const selectedOnSaleItems = cartData.vendors.flatMap((vendor) =>
    vendor.items.filter((item) => selected.has(item.cart_item_id) && item.status === 'ON_SALE')
  );

  const total_product_price = selectedOnSaleItems.reduce(
    (sum, item) => sum + item.price_original * item.quantity,
    0
  );
  const total_discount = -selectedOnSaleItems.reduce(
    (sum, item) => sum + (item.price_original - item.price_sale) * item.quantity,
    0
  );
  const cart_discount = 0;
  const total_shipping_fee = cartData.summary.total_shipping_fee;
  const total_payment = total_product_price + total_discount + cart_discount + total_shipping_fee;

  return {
    total_product_price,
    total_discount,
    cart_discount,
    total_shipping_fee,
    total_payment,
    point_balance: cartData.summary.point_balance,
    coupon_benefit_text: cartData.summary.coupon_benefit_text,
  };
}

// 특정 cart_item_id의 quantity만 불변 업데이트한다 — buildSelectedSummary와 동일한
// "순수 함수를 호출부 파일에 둔다" 패턴 (design.md 과업2 결정 1).
function updateItemQuantity(cartData: CartData, cartItemId: number, quantity: number): CartData {
  return {
    ...cartData,
    vendors: cartData.vendors.map((vendor) => ({
      ...vendor,
      items: vendor.items.map((item) => (item.cart_item_id === cartItemId ? { ...item, quantity } : item)),
    })),
  };
}

export function CartClient({ cartData: initialCartData }: { cartData: CartData }) {
  const router = useRouter();
  const [cartData, setCartData] = useState<CartData>(initialCartData);
  const [selected, setSelected] = useState<Set<number>>(() => initialSelected(initialCartData));
  // 수량 변경 요청이 진행 중인 cart_item_id — 응답 전 같은 버튼 중복 클릭을 막는다 (design.md 과업2 결정 3).
  const [pendingItemId, setPendingItemId] = useState<number | null>(null);

  const toggle = (cartItemId: number) => {
    const next = new Set(selected);
    if (next.has(cartItemId)) next.delete(cartItemId);
    else next.add(cartItemId);
    setSelected(next);
  };

  // 장바구니 삭제 (DL §4: DELETE /my/cart/items/{cartItemId}). Cart 영속 계층이 없어
  // 서버는 항상 성공 Mock만 반환하므로, 실제 화면 반영은 여기서 로컬 state를 갱신해 처리한다.
  const removeItem = async (cartItemId: number) => {
    try {
      await api<null>(`/my/cart/items/${cartItemId}`, { method: 'DELETE' });
    } catch (e) {
      alert(e instanceof ApiError ? e.message : '일시적인 오류로 삭제할 수 없습니다.');
      return;
    }

    setCartData((prev) => ({
      ...prev,
      total_count: prev.total_count - 1,
      vendors: prev.vendors
        .map((vendor) => ({
          ...vendor,
          items: vendor.items.filter((item) => item.cart_item_id !== cartItemId),
        }))
        .filter((vendor) => vendor.items.length > 0),
    }));

    setSelected((prev) => {
      if (!prev.has(cartItemId)) return prev;
      const next = new Set(prev);
      next.delete(cartItemId);
      return next;
    });

    alert('삭제되었습니다.');
  };

  // 장바구니 상품 수량 변경 (DL §3: PATCH /my/cart/items/{cartItemId}/quantity). 1~99 범위·재고초과는
  // VendorGroup이 버튼 disabled로 선제 차단하지만, 서버가 보낸 400/409/404 응답도 방어적으로 처리한다
  // (design.md 과업2 결정 3).
  const handleQuantityChange = async (cartItemId: number, nextQuantity: number) => {
    setPendingItemId(cartItemId);
    try {
      const data = await api<{ cartItemId: string; quantity: number; subtotal: number }>(
        `/my/cart/items/${cartItemId}/quantity`,
        { method: 'PATCH', body: { quantity: nextQuantity } }
      );
      setCartData((prev) => updateItemQuantity(prev, cartItemId, data.quantity));
    } catch (e) {
      alert(e instanceof ApiError ? e.message : '수량 변경 중 오류가 발생했습니다.');
    } finally {
      setPendingItemId(null);
    }
  };

  // 선택된 상품만 기준으로 CartSummary/CartBottomBar에 공유할 요약을 계산한다
  // (design.md "결정 1 — CartSummary 재계산 방식").
  const selectedSummary = buildSelectedSummary(cartData, selected);

  // 주문서 진입 = 선택 상품으로 서버에 임시주문 생성. 주문서 화면은 응답의 order_sheet_id로 저장된 임시주문을 읽는다.
  const handleOrder = async () => {
    const items = cartData.vendors.flatMap((vendor) =>
      vendor.items
        .filter((item) => selected.has(item.cart_item_id) && item.status === 'ON_SALE')
        .map((item) => ({
          vendorId: vendor.vendor_id,
          productId: item.product_id,
          skuId: item.product_id,
          productName: item.product_name,
          priceOriginal: item.price_original,
          priceSale: item.price_sale,
          quantity: item.quantity,
          color: item.color,
          size: item.size,
        }))
    );
    try {
      const sheet = await api<{ order_sheet_id: string }>('/my/orders/sheet', { method: 'POST', body: { items } });
      router.push(`/orders/new?sheet=${encodeURIComponent(sheet.order_sheet_id)}`);
    } catch (e) {
      alert(e instanceof ApiError ? e.message : '주문서를 만들 수 없습니다. 잠시 후 다시 시도해주세요.');
    }
  };

  return (
    <>
      {/* 판매자별 그룹 */}
      {cartData.vendors.map((vendor) => (
        <VendorGroup
          key={vendor.vendor_id}
          vendor={vendor}
          selected={selected}
          onToggle={toggle}
          onDelete={removeItem}
          onQuantityChange={handleQuantityChange}
          pendingItemId={pendingItemId}
        />
      ))}

      {/* 혜택 안내 */}
      <div className="mx-4 mt-4 p-3 bg-blue-50 rounded-lg">
        <p className="text-xs text-blue-700">💡 {cartData.summary.coupon_benefit_text} · 포인트 잔액 {cartData.summary.point_balance.toLocaleString()}P</p>
        <p className="text-xs text-blue-600 mt-0.5">쿠폰·포인트는 주문서에서 적용할 수 있습니다.</p>
      </div>

      {/* 금액 요약 */}
      <CartSummary summary={selectedSummary} />

      {/* 하단 고정 바 */}
      <CartBottomBar totalPayment={selectedSummary.total_payment} onOrder={handleOrder} disabled={selected.size === 0} />
    </>
  );
}
