'use client';

import { useRouter } from 'next/navigation';
import { api, ApiError } from '@/lib/api';
import type { Address, OrderGroup, Term } from '@/components/order/OrderSheetClient';

interface OrderBottomBarProps {
  orderSheetId: string;
  orders: OrderGroup[];
  terms: Term[];
  addressId: number | undefined;
  address: Address | undefined;
  couponId: string | null;
  paymentMethodType: string;
  paymentMethodLabel: string;
  termsAgreed: Set<string>;
  pointUsed: number;
  /** 쿠폰/포인트 저장 진행 중 — 저장이 끝나기 전에는 결제를 막는다. */
  saving?: boolean;
  totalPayment: number;
}

interface PayResponse {
  platformOrderId: string;
  platformOrderNo: string;
  orderId: string;
  totalOrderAmount?: number;
  totalPayment: number;
  status: string;
  message: string;
}

function nowStr() {
  const d = new Date();
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}.${pad(d.getMonth() + 1)}.${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

export function OrderBottomBar({
  orderSheetId,
  orders,
  terms,
  addressId,
  address,
  couponId,
  paymentMethodType,
  paymentMethodLabel,
  termsAgreed,
  pointUsed,
  saving,
  totalPayment,
}: OrderBottomBarProps) {
  const router = useRouter();

  const handlePayment = async () => {
    if (saving) {
      alert('쿠폰/포인트 적용 중입니다. 잠시 후 다시 시도해주세요');
      return;
    }

    if (paymentMethodType === 'CARD') {
      alert('카드 결제는 작업중입니다. 가상계좌로 결제해주세요');
      return;
    }

    if (!addressId) {
      alert('배송지를 선택해주세요');
      return;
    }

    const requiredTerms = terms.filter(t => t.required);
    const isAllRequiredAgreed = requiredTerms.every(t => termsAgreed.has(t.term_id));
    if (!isAllRequiredAgreed) {
      alert('필수 약관에 동의해주세요');
      return;
    }

    try {
      const data = await api<PayResponse>(`/my/orders/${orderSheetId}/pay`, {
        method: 'POST',
        body: {
          addressId,
          couponId,
          pointUsed,
          paymentMethodType,
          termsAgreed: Array.from(termsAgreed),
        },
      });
      sessionStorage.setItem(
        'runnshop:lastOrderComplete',
        JSON.stringify({
          // "주문번호" 표시는 platformOrderNo(PyyMMdd-NNNNN-00)를 쓴다 — /my/orders 등 다른 화면과
          // 동일한 주문번호 표기 형식이다. raw PK(orderId)는 표시용으로 쓰지 않는다.
          platformOrderNo: data.platformOrderNo,
          platformOrderId: data.platformOrderId,
          totalOrderAmount: data.totalOrderAmount ?? data.totalPayment,
          totalPayment: data.totalPayment,
          paymentMethodLabel,
          message: data.message,
          orderedAt: nowStr(),
          recipient: address?.recipient,
          address: address?.address,
          addressDetail: address?.address_detail,
          zipCode: address?.zip_code,
        })
      );
      router.push('/orders/complete');
    } catch (e) {
      sessionStorage.setItem(
        'runnshop:lastOrderFailed',
        JSON.stringify({
          message: e instanceof ApiError ? e.message : '일시적인 오류로 주문을 접수할 수 없습니다.',
          sheetId: orderSheetId,
        })
      );
      router.push('/orders/failed');
    }
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 max-w-[360px] mx-auto bg-white border-t border-gray-200 px-4 py-3">
      <button
        onClick={handlePayment}
        className="w-full h-12 bg-primary text-white font-bold rounded-lg text-sm"
      >
        {totalPayment.toLocaleString()}원 결제하기
      </button>
    </div>
  );
}
