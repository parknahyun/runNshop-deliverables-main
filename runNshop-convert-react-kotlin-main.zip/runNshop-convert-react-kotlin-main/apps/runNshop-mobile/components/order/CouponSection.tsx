'use client';

import { useState } from 'react';
import { CouponDetailModal } from '@/components/order/CouponDetailModal';

interface Coupon {
  coupon_id: string;
  name: string;
  discount_type: string;
  discount_value: number;
  max_discount: number;
  min_order: number;
}

interface CouponSectionProps {
  coupons: { available_count: number; items: Coupon[] };
  orderTotal: number;
  selectedCouponId: string | null;
  onSelect: (couponId: string | null) => void;
}

/** 쿠폰 1건의 할인 예상액을 계산한다. 백엔드 PromotionService.validateCoupon()과 동일한 공식
 *  (RATE: orderTotal*value/100, FIXED: value, 둘 다 max_discount로 cap)을 FE에서 미리 보여주기 위한 것이고,
 *  실제 확정 금액/적용 가능 여부는 결제 요청 시 서버가 다시 검증한다(min_order 미달이면 422 COUPON_NOT_APPLICABLE). */
function estimateDiscount(coupon: Coupon, orderTotal: number): number {
  if (orderTotal < coupon.min_order) return 0;
  if (coupon.discount_type === 'RATE') {
    return Math.min(Math.floor((orderTotal * coupon.discount_value) / 100), coupon.max_discount);
  }
  if (coupon.discount_type === 'FIXED') {
    return Math.min(coupon.discount_value, coupon.max_discount);
  }
  return 0;
}

export function CouponSection({ coupons, orderTotal, selectedCouponId, onSelect }: CouponSectionProps) {
  const [expanded, setExpanded] = useState(false);
  const [openCouponId, setOpenCouponId] = useState<string | null>(null);
  const selected = coupons.items.find((c) => c.coupon_id === selectedCouponId) || null;
  const openCoupon = coupons.items.find((c) => c.coupon_id === openCouponId) || null;

  return (
    <div className="bg-white mt-2 px-4 py-4">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-bold text-gray-900">쿠폰</h2>
        <button onClick={() => setExpanded((v) => !v)} className="text-xs text-primary">
          사용 가능 {coupons.available_count}장 {expanded ? '∧' : '>'}
        </button>
      </div>
      {!expanded && (
        <p className="text-xs text-gray-500 mt-1">
          {selected ? `${selected.name} 적용됨` : '적용된 쿠폰이 없습니다.'}
        </p>
      )}
      {expanded && (
        <div className="mt-2 space-y-2">
          <label className="flex items-center gap-2">
            <input
              type="radio"
              name="coupon"
              checked={selectedCouponId === null}
              onChange={() => onSelect(null)}
              className="w-4 h-4 accent-primary"
            />
            <span className="text-sm text-gray-700">쿠폰 사용 안 함</span>
          </label>
          {coupons.items.map((coupon) => {
            const discount = estimateDiscount(coupon, orderTotal);
            const applicable = orderTotal >= coupon.min_order;
            return (
              <div
                key={coupon.coupon_id}
                className={`flex items-start gap-2 ${!applicable ? 'opacity-40' : ''}`}
              >
                <label className="flex items-start gap-2 flex-1">
                  <input
                    type="radio"
                    name="coupon"
                    checked={selectedCouponId === coupon.coupon_id}
                    disabled={!applicable}
                    onChange={() => onSelect(coupon.coupon_id)}
                    className="w-4 h-4 accent-primary mt-0.5"
                  />
                  <span className="flex-1 text-sm text-gray-700">
                    <span className="block">{coupon.name}</span>
                    <span className="block text-xs text-gray-400">
                      {applicable
                        ? `${discount.toLocaleString()}원 할인`
                        : `${coupon.min_order.toLocaleString()}원 이상 구매 시 사용 가능`}
                    </span>
                  </span>
                </label>
                <button
                  type="button"
                  onClick={() => setOpenCouponId(coupon.coupon_id)}
                  className="text-xs text-gray-400 underline mt-0.5"
                >
                  상세
                </button>
              </div>
            );
          })}
        </div>
      )}
      <CouponDetailModal coupon={openCoupon} onClose={() => setOpenCouponId(null)} />
    </div>
  );
}
