'use client';

import { useEffect, useRef, useState } from 'react';
import { api, ApiError } from '@/lib/api';
import { AddressSection } from '@/components/order/AddressSection';
import { OrderItemList } from '@/components/order/OrderItemList';
import { CouponSection } from '@/components/order/CouponSection';
import { PointSection } from '@/components/order/PointSection';
import { PaymentMethod } from '@/components/order/PaymentMethod';
import { PriceSummary } from '@/components/order/PriceSummary';
import { TermsAgreement } from '@/components/order/TermsAgreement';
import { OrderBottomBar } from '@/components/order/OrderBottomBar';

export interface OrderSheetData {
  order_sheet_id: string;
  orderer: { name: string; phone: string; email: string };
  addresses: Address[];
  orders: OrderGroup[];
  coupons: { available_count: number; items: Coupon[] };
  point: { balance: number; usable: number; min_use: number };
  payment_methods: { type: string; label: string }[];
  price_summary: PriceSummaryData;
  terms: Term[];
  /** 주문서에서 적용해 서버(임시주문)에 저장된 쿠폰/포인트 — 재진입 시 복원한다. */
  selected_coupon_id?: string | null;
  point_used?: number;
}

export interface Address {
  address_id: number;
  recipient: string;
  phone: string;
  zip_code: string;
  address: string;
  address_detail: string;
  is_default: boolean;
}

export interface OrderGroup {
  vendor_id: number;
  vendor_name: string;
  items: OrderItem[];
}

export interface OrderItem {
  product_id: number;
  product_name: string;
  image_url: string;
  color: string;
  size: string;
  price_sale: number;
  quantity: number;
}

export interface Coupon {
  coupon_id: string;
  name: string;
  discount_type: string;
  discount_value: number;
  max_discount: number;
  min_order: number;
}

export interface PriceSummaryData {
  total_product_price: number;
  product_discount: number;
  cart_discount: number;
  coupon_discount: number;
  point_used: number;
  shipping_fee: number;
  order_amount?: number;
  total_payment: number;
}

export interface Term {
  term_id: string;
  title: string;
  required: boolean;
  content: string;
}

export function OrderSheetClient({ sheet }: { sheet: OrderSheetData }) {
  const defaultAddress = sheet.addresses.find(a => a.is_default) || sheet.addresses[0];

  const [addressId, setAddressId] = useState<number | undefined>(defaultAddress?.address_id);
  const [paymentMethodType, setPaymentMethodType] = useState(sheet.payment_methods[0]?.type || '');
  const [termsAgreed, setTermsAgreed] = useState<Set<string>>(new Set());
  const [pointUsed, setPointUsed] = useState(sheet.point_used ?? 0);
  const [couponId, setCouponId] = useState<string | null>(sheet.selected_coupon_id || null);
  const [saving, setSaving] = useState(false);
  // 서버에 마지막으로 저장된 쿠폰/포인트 — 저장 실패 시 이 값으로 되돌린다.
  const saved = useRef({ couponId: sheet.selected_coupon_id || null, pointUsed: sheet.point_used ?? 0 });

  // 쿠폰/포인트 변경은 임시주문에 영속한다(포인트 입력은 debounce). 결제 시점에는 서버가 저장값으로 재검증한다.
  useEffect(() => {
    if (saved.current.couponId === couponId && saved.current.pointUsed === pointUsed) return;
    setSaving(true);
    const timer = setTimeout(async () => {
      try {
        await api(`/my/orders/sheet/${encodeURIComponent(sheet.order_sheet_id)}/discount`, {
          method: 'PUT',
          body: { couponId, pointUsed },
        });
        saved.current = { couponId, pointUsed };
      } catch (e) {
        alert(e instanceof ApiError ? e.message : '쿠폰/포인트 적용에 실패했습니다');
        setCouponId(saved.current.couponId);
        setPointUsed(saved.current.pointUsed);
      } finally {
        setSaving(false);
      }
    }, 400);
    return () => clearTimeout(timer);
  }, [couponId, pointUsed, sheet.order_sheet_id]);

  // 서버가 주문서 진입 시 저장한 임시주문의 상품만 내려주므로 클라이언트 필터링이 필요 없다.
  const filteredOrders = sheet.orders;

  // 주문 상품 합계(price_sale 기준) — 쿠폰 min_order 체크/할인 미리보기 계산에 쓴다. 백엔드 PromotionService.
  // validateCoupon()이 쓰는 orderTotal(items의 priceSale*quantity 합)과 동일한 기준이어야 미리보기가 실제 결과와 맞는다.
  const orderTotal = filteredOrders.reduce(
    (sum, group) => sum + group.items.reduce((s, item) => s + item.price_sale * item.quantity, 0),
    0
  );
  const selectedAddress = sheet.addresses.find((a) => a.address_id === addressId);
  const paymentMethodLabel =
    sheet.payment_methods.find((m) => m.type === paymentMethodType)?.label || paymentMethodType;

  const selectedCoupon = sheet.coupons.items.find((c) => c.coupon_id === couponId) || null;
  const couponDiscount =
    selectedCoupon && orderTotal >= selectedCoupon.min_order
      ? selectedCoupon.discount_type === 'RATE'
        ? Math.min(Math.floor((orderTotal * selectedCoupon.discount_value) / 100), selectedCoupon.max_discount)
        : Math.min(selectedCoupon.discount_value, selectedCoupon.max_discount)
      : 0;

  // 금액 요약 — mock의 price_summary(product_discount/cart_discount 포함)는 장바구니 화면용 장식성
  // 수치일 뿐 실제 결제 계산에 전혀 반영되지 않는다. 백엔드 OrderService.placeOrder()의 실제 공식은
  // paymentAmount = Σ(선택 상품 priceSale×quantity) - couponDiscount - pointUsed(+shippingAmount, 항상 0)
  // 뿐이고 "상품할인"/"장바구니할인" 개념 자체가 PayRequest에 없다 — 그걸 그대로 화면에 보여주면서 쿠폰/
  // 포인트만 추가로 빼면, 실제로 적용되지 않는 할인이 적용된 것처럼 보여 완료 화면의 실결제금액과 어긋난다
  // (버그 리포트: 주문서 397,000원 vs 완료화면 448,000원). 백엔드 공식과 1:1 일치하도록 orderTotal(선택
  // 상품 priceSale 합계) 기준으로 재계산하고, product_discount/cart_discount는 0으로 고정한다(0이면
  // PriceSummary.tsx의 `!== 0` 조건에 의해 해당 줄 자체가 화면에 표시되지 않는다).
  const priceSummary: PriceSummaryData = {
    total_product_price: orderTotal,
    product_discount: 0,
    cart_discount: 0,
    coupon_discount: -couponDiscount,
    point_used: pointUsed,
    shipping_fee: 0,
    order_amount: orderTotal - couponDiscount, // 주문금액 = 상품금액 − 할인금액 + 배송비
    total_payment: orderTotal - couponDiscount - pointUsed, // 결제금액 = 주문금액 − 포인트
  };

  const toggleTerm = (termId: string) => {
    const next = new Set(termsAgreed);
    if (next.has(termId)) next.delete(termId);
    else next.add(termId);
    setTermsAgreed(next);
  };

  const toggleAllTerms = () => {
    const allRequired = sheet.terms.filter(t => t.required);
    const isAllAgreed = allRequired.every(t => termsAgreed.has(t.term_id));
    if (isAllAgreed) {
      setTermsAgreed(new Set());
    } else {
      setTermsAgreed(new Set(sheet.terms.map(t => t.term_id)));
    }
  };

  return (
    <main className="pb-28 bg-gray-50">
      {/* 헤더 */}
      <div className="bg-white px-4 py-3 border-b border-gray-200">
        <h1 className="text-lg font-bold text-gray-900">주문서</h1>
      </div>

      {/* 배송지 */}
      {defaultAddress && <AddressSection address={defaultAddress} />}

      {/* 주문 상품 */}
      <OrderItemList orders={filteredOrders} />

      {/* 쿠폰 */}
      <CouponSection
        coupons={sheet.coupons}
        orderTotal={orderTotal}
        selectedCouponId={couponId}
        onSelect={setCouponId}
      />

      {/* 포인트 */}
      <PointSection point={sheet.point} pointUsed={pointUsed} onChange={setPointUsed} />

      {/* 결제 수단 */}
      <PaymentMethod
        methods={sheet.payment_methods}
        selected={paymentMethodType}
        onSelect={setPaymentMethodType}
      />

      {/* 금액 요약 */}
      <PriceSummary summary={priceSummary} />

      {/* 약관 동의 + 결제하기 */}
      <TermsAgreement
        terms={sheet.terms}
        agreed={termsAgreed}
        onToggle={toggleTerm}
        onToggleAll={toggleAllTerms}
      />
      <OrderBottomBar
        orderSheetId={sheet.order_sheet_id}
        orders={filteredOrders}
        terms={sheet.terms}
        addressId={addressId}
        address={selectedAddress}
        couponId={couponId}
        paymentMethodType={paymentMethodType}
        paymentMethodLabel={paymentMethodLabel}
        termsAgreed={termsAgreed}
        pointUsed={pointUsed}
        saving={saving}
        totalPayment={priceSummary.total_payment}
      />
    </main>
  );
}
