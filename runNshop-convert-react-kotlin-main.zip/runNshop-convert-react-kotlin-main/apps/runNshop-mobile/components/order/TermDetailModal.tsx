'use client';

import type { Term } from '@/components/order/OrderSheetClient';

export function TermDetailModal(props: { term: Term | null; onClose: () => void }) {
  const { term, onClose } = props;
  if (!term) return null;

  return (
    <div
      className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-lg mx-6 w-full max-w-[300px] px-4 py-4"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-bold text-gray-900">
            {term.required && <span className="text-red-500">[필수] </span>}
            {term.title}
          </h3>
          <button onClick={onClose} className="text-gray-400 text-lg leading-none">✕</button>
        </div>
        <p className="text-sm text-gray-700 whitespace-pre-wrap">
          {term.content || '상세 내용이 준비되지 않았습니다.'}
        </p>
      </div>
    </div>
  );
}
