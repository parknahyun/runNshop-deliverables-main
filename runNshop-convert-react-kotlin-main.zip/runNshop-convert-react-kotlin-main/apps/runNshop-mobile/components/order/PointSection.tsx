'use client';

interface PointData {
  balance: number;
  usable: number;
  min_use: number;
}

interface PointSectionProps {
  point: PointData;
  pointUsed: number;
  onChange: (value: number) => void;
}

export function PointSection({ point, pointUsed, onChange }: PointSectionProps) {
  const handleUseAll = () => {
    onChange(point.usable);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const digitsOnly = e.target.value.replace(/[^0-9]/g, '');
    const value = digitsOnly === '' ? 0 : Math.min(Number(digitsOnly), point.usable);
    onChange(value);
  };

  return (
    <div className="bg-white mt-2 px-4 py-4">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-bold text-gray-900">포인트</h2>
        <span className="text-xs text-gray-500">보유 {point.balance.toLocaleString()}P</span>
      </div>
      <div className="flex items-center gap-2 mt-2">
        <input
          type="text"
          inputMode="numeric"
          placeholder="0"
          value={pointUsed === 0 ? '' : String(pointUsed)}
          onChange={handleInputChange}
          className="flex-1 h-9 border border-gray-200 rounded px-3 text-sm"
        />
        <button
          onClick={handleUseAll}
          className="h-9 px-3 border border-gray-300 rounded text-xs text-gray-700"
        >
          전액 사용
        </button>
      </div>
      <p className="text-xs text-gray-400 mt-1">
        {point.usable.toLocaleString()}P 사용 가능 (최소 {point.min_use.toLocaleString()}P)
      </p>
    </div>
  );
}
