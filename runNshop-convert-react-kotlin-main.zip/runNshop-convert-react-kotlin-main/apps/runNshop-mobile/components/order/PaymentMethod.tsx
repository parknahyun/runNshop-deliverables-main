'use client';

interface Method {
  type: string;
  label: string;
}

interface PaymentMethodProps {
  methods: Method[];
  selected: string;
  onSelect: (type: string) => void;
}

export function PaymentMethod({ methods, selected, onSelect }: PaymentMethodProps) {
  return (
    <div className="bg-white mt-2 px-4 py-4">
      <h2 className="text-sm font-bold text-gray-900 mb-2">결제 수단</h2>
      <div className="flex gap-2">
        {methods.map((m) => (
          <button
            key={m.type}
            onClick={() => onSelect(m.type)}
            className={`px-4 py-2 text-sm rounded border ${
              selected === m.type
                ? 'border-primary text-primary font-medium'
                : 'border-gray-200 text-gray-600'
            }`}
          >
            {m.label}
          </button>
        ))}
      </div>
      {/* 카드 결제는 작업중 — 현재 가상계좌만 진행 가능(OrderBottomBar에서도 결제 요청을 막는다) */}
      {selected === 'CARD' ? (
        <p className="text-xs text-red-500 mt-2">
          🚧 카드 결제는 작업중입니다. 가상계좌를 선택해주세요.
        </p>
      ) : (
        <p className="text-xs text-gray-400 mt-2">
          ℹ️ 프로토타입 환경에서는 가상계좌 발급 후 입금대기 상태로 진행됩니다.
        </p>
      )}
    </div>
  );
}
