'use client';

import type { Coupon } from '@/components/order/OrderSheetClient';

/** 쿠폰 사용 조건을 사람이 읽기 쉬운 문구로 조립한다. discount_type별 포맷이 다르고,
 *  현재 Mock엔 RATE/FIXED 두 타입만 있지만 알 수 없는 타입이 들어와도 undefined를 반환하지
 *  않도록 기본 분기를 둔다(CouponSection.tsx의 estimateDiscount()가 쓰는 기본값 0 패턴과 동일 취지). */
function formatCouponCondition(coupon: Coupon): string {
  const minOrder = coupon.min_order.toLocaleString();
  if (coupon.discount_type === 'RATE') {
    return `최소 상품금액 ${minOrder}원 이상 구매 시 ${coupon.discount_value}% 할인, 최대 ${coupon.max_discount.toLocaleString()}원까지`;
  }
  if (coupon.discount_type === 'FIXED') {
    return `최소 상품금액 ${minOrder}원 이상 구매 시 ${coupon.discount_value.toLocaleString()}원 할인`;
  }
  return '할인 조건 정보가 없습니다.';
}

export function CouponDetailModal(props: { coupon: Coupon | null; onClose: () => void }) {
  const { coupon, onClose } = props;
  if (!coupon) return null;

  return (
    <div
      className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-lg mx-6 w-full max-w-[300px] px-4 py-4"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-bold text-gray-900">{coupon.name}</h3>
          <button onClick={onClose} className="text-gray-400 text-lg leading-none">✕</button>
        </div>
        <p className="text-sm text-gray-700">{formatCouponCondition(coupon)}</p>
      </div>
    </div>
  );
}
