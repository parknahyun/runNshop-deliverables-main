'use client';

import { useState } from 'react';
import { TermDetailModal } from '@/components/order/TermDetailModal';

interface Term {
  term_id: string;
  title: string;
  required: boolean;
  content: string;
}

interface TermsAgreementProps {
  terms: Term[];
  agreed: Set<string>;
  onToggle: (termId: string) => void;
  onToggleAll: () => void;
}

export function TermsAgreement({ terms, agreed, onToggle, onToggleAll }: TermsAgreementProps) {
  const allRequired = terms.filter(t => t.required);
  const isAllAgreed = allRequired.every(t => agreed.has(t.term_id));
  const [openTermId, setOpenTermId] = useState<string | null>(null);
  const openTerm = terms.find((t) => t.term_id === openTermId) || null;

  return (
    <div className="bg-white mt-2 px-4 py-4">
      <label className="flex items-center gap-2 mb-3">
        <input
          type="checkbox"
          checked={isAllAgreed}
          onChange={onToggleAll}
          className="w-5 h-5 accent-primary"
        />
        <span className="text-sm font-bold text-gray-900">전체 동의</span>
      </label>
      <div className="space-y-2 pl-1">
        {terms.map((term) => (
          <div key={term.term_id} className="flex items-center gap-2">
            <label className="flex items-center gap-2 flex-1">
              <input
                type="checkbox"
                checked={agreed.has(term.term_id)}
                onChange={() => onToggle(term.term_id)}
                className="w-4 h-4 accent-primary"
              />
              <span className="text-xs text-gray-600">
                {term.required && <span className="text-red-500">[필수] </span>}
                {term.title}
              </span>
            </label>
            <button
              type="button"
              onClick={() => setOpenTermId(term.term_id)}
              className="text-xs text-gray-400 underline"
            >
              보기
            </button>
          </div>
        ))}
      </div>
      <TermDetailModal term={openTerm} onClose={() => setOpenTermId(null)} />
    </div>
  );
}
