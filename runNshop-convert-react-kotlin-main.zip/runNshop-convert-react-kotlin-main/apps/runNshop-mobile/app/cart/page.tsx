import { api } from '@/lib/api';
import { CartClient, CartData } from '@/components/cart/CartClient';
import { CartBackButton } from '@/components/cart/CartBackButton';

export default async function CartPage() {
  let cartData: CartData | null = null;

  try {
    cartData = await api<CartData>('/my/cart');
  } catch (e) {
    // fallback
  }

  if (!cartData) {
    return (
      <main className="p-4">
        <p className="text-sm text-gray-500">장바구니 정보를 불러올 수 없습니다.</p>
      </main>
    );
  }

  return (
    <main className="pb-24 bg-gray-50">
      {/* 헤더 */}
      <div className="bg-white px-4 py-3 border-b border-gray-200 flex items-center gap-2">
        <CartBackButton />
        <h1 className="text-lg font-bold text-gray-900">
          장바구니 <span className="text-primary">{cartData.total_count}</span>
        </h1>
      </div>

      <CartClient cartData={cartData} />
    </main>
  );
}
