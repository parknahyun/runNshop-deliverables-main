'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Header } from '@/components/layout/Header';
import { BottomNav } from '@/components/layout/BottomNav';

interface OrderCompleteData {
  platformOrderNo: string;
  platformOrderId: string;
  /** 주문금액 (포인트 사용 전 금액) */
  totalOrderAmount?: number;
  /** 결제금액 (주문금액 − 포인트) */
  totalPayment: number;
  paymentMethodLabel: string;
  message: string;
  orderedAt: string;
  recipient?: string;
  address?: string;
  addressDetail?: string;
  zipCode?: string;
}

const STORAGE_KEY = 'runnshop:lastOrderComplete';

export default function OrderCompletePage() {
  const router = useRouter();
  const [data, setData] = useState<OrderCompleteData | null>(null);

  useEffect(() => {
    const raw = sessionStorage.getItem(STORAGE_KEY);
    if (!raw) {
      router.replace('/');
      return;
    }
    try {
      setData(JSON.parse(raw));
    } catch {
      router.replace('/');
    }
  }, [router]);

  if (!data) {
    return null;
  }

  return (
    <main className="pb-16 bg-gray-50 min-h-screen">
      <Header />

      <div className="flex flex-col items-center px-4 pt-10 pb-6 text-center">
        <span className="text-5xl">✅</span>
        <h1 className="text-lg font-bold text-gray-900 mt-4">주문이 접수되었습니다</h1>
      </div>

      <div className="mx-4 bg-white rounded-lg shadow-sm px-4 py-4 space-y-1.5 text-sm">
        <InfoRow label="주문번호" value={data.platformOrderNo} />
        <InfoRow label="주문금액" value={`${(data.totalOrderAmount ?? data.totalPayment).toLocaleString()}원`} />
        <InfoRow label="결제금액" value={`${data.totalPayment.toLocaleString()}원`} />
        <InfoRow label="결제수단" value={data.paymentMethodLabel} />
        <InfoRow label="접수일시" value={data.orderedAt} />
      </div>

      {data.address && (
        <div className="mx-4 mt-3 bg-white rounded-lg shadow-sm px-4 py-4 text-sm">
          <p className="text-gray-500">배송지</p>
          <p className="text-gray-900 font-medium mt-1">{data.recipient}</p>
          <p className="text-gray-600 mt-0.5">
            [{data.zipCode}] {data.address} {data.addressDetail}
          </p>
        </div>
      )}

      <div className="mx-4 mt-4 p-3 bg-blue-50 rounded-lg text-xs text-blue-700">
        ⏳ 재고 확인 및 결제가 진행 중입니다. 잠시만 기다려 주세요.
      </div>

      <p className="text-xs text-gray-400 text-center mt-3 px-4">
        ※ 결제가 완료되면 카카오톡으로 주문 확인 안내가 발송됩니다.
      </p>

      <div className="px-4 mt-6 space-y-2">
        <Link
          href={`/my/orders/${data.platformOrderId}`}
          className="block w-full h-12 bg-primary text-white font-bold rounded-lg text-sm text-center leading-[48px]"
        >
          주문 상세 보기
        </Link>
        <Link
          href="/"
          className="block w-full h-12 bg-white border border-gray-300 text-gray-700 font-bold rounded-lg text-sm text-center leading-[48px]"
        >
          쇼핑 계속하기
        </Link>
      </div>

      <BottomNav />
    </main>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between">
      <span className="text-gray-500">{label}</span>
      <span className="text-gray-900">{value}</span>
    </div>
  );
}
