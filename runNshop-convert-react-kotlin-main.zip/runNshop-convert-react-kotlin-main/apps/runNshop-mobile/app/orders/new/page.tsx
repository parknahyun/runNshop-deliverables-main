import { api } from '@/lib/api';
import { OrderSheetClient, OrderSheetData } from '@/components/order/OrderSheetClient';

export default async function OrderNewPage({ searchParams }: { searchParams: { sheet?: string } }) {
  let sheet: OrderSheetData | null = null;

  // 주문서는 장바구니에서 진입할 때 만든 임시주문(sheet=order_sheet_id)을 읽어 보여준다 — 새로고침해도 같은 주문서.
  try {
    if (searchParams.sheet) {
      sheet = await api<OrderSheetData>(`/my/orders/sheet/${encodeURIComponent(searchParams.sheet)}`);
    }
  } catch (e) {
    // fallback
  }

  if (!sheet) {
    return (
      <main className="p-4">
        <p className="text-sm text-gray-500">주문서 정보를 불러올 수 없습니다. 장바구니에서 다시 주문해주세요.</p>
      </main>
    );
  }

  return <OrderSheetClient sheet={sheet} />;
}
