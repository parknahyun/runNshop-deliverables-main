'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Header } from '@/components/layout/Header';
import { BottomNav } from '@/components/layout/BottomNav';

interface OrderFailedData {
  message: string;
  sheetId?: string;
}

const STORAGE_KEY = 'runnshop:lastOrderFailed';

export default function OrderFailedPage() {
  const router = useRouter();
  const [data, setData] = useState<OrderFailedData | null>(null);

  useEffect(() => {
    const raw = sessionStorage.getItem(STORAGE_KEY);
    if (!raw) {
      router.replace('/cart');
      return;
    }
    try {
      setData(JSON.parse(raw));
    } catch {
      router.replace('/cart');
    }
  }, [router]);

  if (!data) {
    return null;
  }

  return (
    <main className="pb-16 bg-gray-50 min-h-screen">
      <Header />

      <div className="flex flex-col items-center px-4 pt-10 pb-6 text-center">
        <span className="text-5xl">❌</span>
        <h1 className="text-lg font-bold text-gray-900 mt-4">주문 접수에 실패했습니다</h1>
      </div>

      <div className="mx-4 bg-white rounded-lg shadow-sm px-4 py-4 text-sm">
        <p className="text-gray-500">실패 사유</p>
        <p className="text-gray-900 mt-1">{data.message}</p>
      </div>

      <div className="mx-4 mt-3 p-3 bg-amber-50 rounded-lg text-xs text-amber-700">
        💡 잠시 후 다시 시도해 주세요. 장바구니 상품은 그대로 유지됩니다.
      </div>

      <div className="px-4 mt-6 space-y-2">
        <Link
          href={data.sheetId ? `/orders/new?sheet=${encodeURIComponent(data.sheetId)}` : '/cart'}
          className="block w-full h-12 bg-primary text-white font-bold rounded-lg text-sm text-center leading-[48px]"
        >
          다시 결제하기
        </Link>
        <Link
          href="/cart"
          className="block w-full h-12 bg-white border border-gray-300 text-gray-700 font-bold rounded-lg text-sm text-center leading-[48px]"
        >
          장바구니로 이동
        </Link>
      </div>

      <p className="text-xs text-gray-400 text-center mt-6 px-4">
        문의가 필요하시면 고객센터(1588-0000)로 연락해 주세요.
      </p>

      <BottomNav />
    </main>
  );
}
