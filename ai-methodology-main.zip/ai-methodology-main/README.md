# ai-dev-methodology

AI 활용 개발방법론 — **프로젝트 무관**, 재사용 가능한 방법론 자산. `runNshop-docs`에서
`methodology/`·`onboarding.md`·방법론 관련 review-alignment·weekly-report를
커밋 이력 보존한 채 분리했다(2026-11-06, `git filter-repo`).

## 이 레포에 있는 것

| 경로 | 내용 |
|---|---|
| `methodology/` | 방법론 본문(v2.4), 적용가이드, 산출물 표준양식·흐름·프롬프트 라이브러리(`appendix/`), 단계별 실증 샘플(`artifacts-sample/`), 파생 프로젝트 가이드, 옛 버전(`archive/`) |
| `onboarding.md` | 신규 참여자가 이 방법론을 실제 프로젝트에 적용하는 절차 가이드 |
| `review-alignment/methodology/` | 방법론·공정자산 자체에 대한 점검/검토 기록 |
| `weekly-report/` | 방법론 교육자료·보고 PPT/시나리오, WBS 작성 샘플(`tmp/`) |

## 이 레포에 없는 것 (runNshop-docs에 있음)

실제 프로젝트(runNshop)의 산출물(S0~S6, `deliverables/`)·참조자료(`reference/`)·프로젝트별
리뷰(`review-alignment/개발`·`설계`)·진행 중 주간보고·`.kiro/steering·skills`·`docs-viewer/`는
`runNshop-docs`(deliverables 레포)에 그대로 있다. 이 레포는 "어떻게 작성하는가"만 다루고,
"실제로 무엇을 만들었는가"는 다루지 않는다.

## 왜 분리했나

`methodology/`는 runNshop 말고 다른 프로젝트에도 그대로 재사용할 수 있는 성격이라, 특정
프로젝트의 실 산출물과 한 레포에 있을 이유가 없었다. 분리 이후 파생 구현 레포(예:
`runNshop-vue-java`)는 여전히 `runNshop-docs`만 submodule로 참조한다 — 코드 구현에 직접
필요한 건 deliverables(S0~S3 설계)뿐이고 methodology(작성 방법론 자체)는 아니기 때문이다.
